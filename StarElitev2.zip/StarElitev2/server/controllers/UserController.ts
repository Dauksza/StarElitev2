
import { Request, Response } from 'express';
import { db } from '../db';
import { users, userModuleProgress } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import { getAuthUser } from '../replitAuth';

export const getUserProgress = async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    
    const progress = await db
      .select()
      .from(userModuleProgress)
      .where(eq(userModuleProgress.userId, userId));
    
    res.json(progress);
  } catch (error) {
    console.error('Error getting user progress:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateUserProgress = async (req: Request, res: Response) => {
  try {
    const user = await getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { moduleId, progress, completed } = req.body;

    await db
      .insert(userModuleProgress)
      .values({
        userId: user.id,
        moduleId,
        progress,
        completed,
        completedAt: completed ? new Date() : null
      })
      .onConflictDoUpdate({
        target: [userModuleProgress.userId, userModuleProgress.moduleId],
        set: {
          progress,
          completed,
          completedAt: completed ? new Date() : null,
          updatedAt: new Date()
        }
      });

    res.json({ message: 'Progress updated', progress });
  } catch (error) {
    console.error('Error updating user progress:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getUserProfile = async (req: Request, res: Response) => {
  try {
    const user = await getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    res.json(user);
  } catch (error) {
    console.error('Error getting user profile:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateUserProfile = async (req: Request, res: Response) => {
  try {
    const user = await getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { displayName, bio, skills, avatar } = req.body;
    
    const [updatedUser] = await db
      .update(users)
      .set({
        displayName,
        bio,
        skills,
        avatar,
        updatedAt: new Date()
      })
      .where(eq(users.id, user.id))
      .returning();

    res.json(updatedUser);
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
