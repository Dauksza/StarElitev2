
import { Request, Response } from 'express';

export interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  issueDate: string;
  certNumber: string;
  printableUrl?: string;
}

let certificates: Certificate[] = [];

export const listCertificates = (req: Request, res: Response) => {
  res.json(certificates);
};

export const issueCertificate = (req: Request, res: Response) => {
  try {
    const cert: Certificate = {
      id: Date.now().toString(),
      ...req.body,
      issueDate: new Date().toISOString(),
      certNumber: `CERT-${Date.now()}`
    };
    
    certificates.push(cert);
    res.status(201).json({ message: 'Certificate issued', cert });
  } catch (error) {
    console.error('Error issuing certificate:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const listCertificatesByUser = (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const userCertificates = certificates.filter(c => c.userId === userId);
    res.json(userCertificates);
  } catch (error) {
    console.error('Error listing user certificates:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
