
import { Request, Response } from 'express';
import { db } from '../db';
import { learningPaths } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const listCourses = async (req: Request, res: Response) => {
  try {
    const courses = await db.select().from(learningPaths);
    res.json(courses);
  } catch (error) {
    console.error('Error listing courses:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createCourse = async (req: Request, res: Response) => {
  try {
    const { title, description, difficulty, estimatedDuration, tags } = req.body;
    
    const [course] = await db
      .insert(learningPaths)
      .values({
        title,
        description,
        difficulty: difficulty || 'Beginner',
        estimatedDuration: estimatedDuration || '4 weeks',
        tags: tags || []
      })
      .returning();
    
    res.status(201).json({ message: 'Course created', course });
  } catch (error) {
    console.error('Error creating course:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getCourse = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const [course] = await db
      .select()
      .from(learningPaths)
      .where(eq(learningPaths.id, id))
      .limit(1);
    
    if (course) {
      res.json(course);
    } else {
      res.status(404).json({ message: 'Course not found' });
    }
  } catch (error) {
    console.error('Error getting course:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
