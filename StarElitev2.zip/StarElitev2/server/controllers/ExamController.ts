
import { Request, Response } from 'express';

export interface ExamQuestion {
  id: string;
  lessonId: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
}

export interface Exam {
  id: string;
  courseId: string;
  questions: ExamQuestion[];
  version: number;
}

let exams: Exam[] = [];

export const listExams = (req: Request, res: Response) => {
  res.json(exams);
};

export const createExam = (req: Request, res: Response) => {
  try {
    const exam: Exam = {
      id: Date.now().toString(),
      version: 1,
      ...req.body
    };
    
    exams.push(exam);
    res.status(201).json({ message: 'Exam created', exam });
  } catch (error) {
    console.error('Error creating exam:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getExamByCourse = (req: Request, res: Response) => {
  try {
    const { courseId } = req.params;
    const exam = exams.find(e => e.courseId === courseId);
    
    if (exam) {
      res.json(exam);
    } else {
      res.status(404).json({ message: 'Exam not found' });
    }
  } catch (error) {
    console.error('Error getting exam:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
