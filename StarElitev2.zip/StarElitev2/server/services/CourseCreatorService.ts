
import { db } from '../db';
import { learningPaths, modules, quizzes, exams } from '@shared/schema';
import { mistralService } from '../ai/mistralService';

export interface CourseStructure {
  title: string;
  description: string;
  duration: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  prerequisites: string[];
  learningOutcomes: string[];
  modules: ModuleStructure[];
  finalExam: ExamStructure;
}

export interface ModuleStructure {
  title: string;
  description: string;
  content: string;
  estimatedDuration: string;
  order: number;
  quiz: QuizStructure;
}

export interface QuizStructure {
  questions: QuestionStructure[];
}

export interface ExamStructure {
  questions: QuestionStructure[];
  passingScore: number;
  timeLimit: number;
}

export interface QuestionStructure {
  question: string;
  type: 'multiple_choice' | 'true_false' | 'short_answer';
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export class CourseCreatorService {
  async researchCourseTopic(topic: string, level: string): Promise<any> {
    const prompt = `Research and analyze current university coursework for "${topic}" at ${level} level.

    Please provide a comprehensive analysis including:
    1. Current industry standards and best practices
    2. Common curriculum structures from top universities
    3. Essential topics and learning progression
    4. Prerequisite knowledge required
    5. Learning outcomes and competencies
    6. Assessment methods typically used
    
    Format as detailed research report with specific recommendations for course structure.`;

    return await mistralService.generateContent(prompt);
  }

  async generateCourseStructure(topic: string, level: string, duration: string): Promise<CourseStructure> {
    const research = await this.researchCourseTopic(topic, level);
    
    const prompt = `Based on this research: ${research}
    
    Create a comprehensive university-level course structure for "${topic}" at ${level} level, ${duration} duration.
    
    Requirements:
    - Follow established university guidelines
    - Include 8-12 modules with progressive difficulty
    - Each module should have 3-5 quiz questions
    - Final exam with 20-30 questions
    - Clear learning outcomes
    - Proper prerequisite identification
    - Industry-relevant content
    
    Return JSON format:
    {
      "title": "Course Title",
      "description": "Course description",
      "duration": "${duration}",
      "difficulty": "${level}",
      "prerequisites": ["prerequisite1", "prerequisite2"],
      "learningOutcomes": ["outcome1", "outcome2"],
      "modules": [
        {
          "title": "Module Title",
          "description": "Module description",
          "content": "Detailed module content",
          "estimatedDuration": "2 weeks",
          "order": 1,
          "quiz": {
            "questions": [
              {
                "question": "Question text",
                "type": "multiple_choice",
                "options": ["A", "B", "C", "D"],
                "correctAnswer": "A",
                "explanation": "Explanation"
              }
            ]
          }
        }
      ],
      "finalExam": {
        "questions": [...],
        "passingScore": 70,
        "timeLimit": 120
      }
    }`;

    const response = await mistralService.generateContent(prompt);
    return JSON.parse(response);
  }

  async createCourse(courseStructure: CourseStructure, createdBy: string): Promise<string> {
    try {
      // Create learning path
      const [learningPath] = await db
        .insert(learningPaths)
        .values({
          title: courseStructure.title,
          description: courseStructure.description,
          difficulty: courseStructure.difficulty,
          estimatedDuration: courseStructure.duration,
          tags: [],
          createdBy
        })
        .returning();

      // Create modules with quizzes
      for (const moduleData of courseStructure.modules) {
        const [module] = await db
          .insert(modules)
          .values({
            learningPathId: learningPath.id,
            title: moduleData.title,
            description: moduleData.description,
            content: moduleData.content,
            estimatedDuration: moduleData.estimatedDuration,
            order: moduleData.order
          })
          .returning();

        // Create quiz for module
        if (moduleData.quiz.questions.length > 0) {
          await db
            .insert(quizzes)
            .values({
              moduleId: module.id,
              title: `${moduleData.title} Quiz`,
              questions: moduleData.quiz.questions,
              timeLimit: 30,
              passingScore: 70
            });
        }
      }

      // Create final exam
      if (courseStructure.finalExam.questions.length > 0) {
        await db
          .insert(exams)
          .values({
            learningPathId: learningPath.id,
            title: `${courseStructure.title} Final Exam`,
            questions: courseStructure.finalExam.questions,
            timeLimit: courseStructure.finalExam.timeLimit,
            passingScore: courseStructure.finalExam.passingScore
          });
      }

      return learningPath.id;
    } catch (error) {
      console.error('Error creating course:', error);
      throw new Error('Failed to create course');
    }
  }

  async validateCourseQuality(courseStructure: CourseStructure): Promise<any> {
    const prompt = `Validate this course structure against university standards:
    
    ${JSON.stringify(courseStructure, null, 2)}
    
    Check for:
    1. Appropriate learning progression
    2. Sufficient content depth
    3. Proper assessment coverage
    4. Industry relevance
    5. Academic rigor
    
    Provide detailed feedback and recommendations for improvement.`;

    return await mistralService.generateContent(prompt);
  }
}

export const courseCreatorService = new CourseCreatorService();
