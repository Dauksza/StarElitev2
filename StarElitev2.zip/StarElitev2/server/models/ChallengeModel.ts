
import { db } from '../db';
import { challenges } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface Challenge {
  id: string;
  title: string;
  description: string;
  participants: string[];
}

// Get all challenges
export const getChallenges = async () => {
  return await db.select().from(challenges);
};

// Add a new challenge
export const addChallenge = async (challenge: Omit<Challenge, 'id'>) => {
  const [newChallenge] = await db
    .insert(challenges)
    .values({
      title: challenge.title,
      description: challenge.description,
      type: 'individual',
      difficulty: 'intermediate',
      estimatedTime: '2 hours',
      points: 100
    })
    .returning();
  return newChallenge;
};

// Remove a challenge
export const removeChallenge = async (id: string) => {
  await db.delete(challenges).where(eq(challenges.id, id));
};
