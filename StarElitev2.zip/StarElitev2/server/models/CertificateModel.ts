
export interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  issueDate: string;
  certNumber: string;
  printableUrl?: string;
}

let certificates: Certificate[] = [];

// Get all certificates
export const getCertificates = (): Certificate[] => certificates;

// Add a new certificate
export const addCertificate = (cert: Certificate) => {
  certificates.push(cert);
};

// Get certificates by user ID
export const getCertificatesByUserId = (userId: string): Certificate[] =>
  certificates.filter((c) => c.userId === userId);
