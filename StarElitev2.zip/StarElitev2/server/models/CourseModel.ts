
import { db } from '../db';
import { learningPaths, modules } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface Course {
  id: string;
  title: string;
  syllabus: string;
  lessonIds: string[];
}

// Get all courses (using learning paths)
export const getCourses = async () => {
  return await db.select().from(learningPaths);
};

// Add a new course
export const addCourse = async (course: Omit<Course, 'id'>) => {
  const [newCourse] = await db
    .insert(learningPaths)
    .values({
      title: course.title,
      description: course.syllabus,
      difficulty: 'Beginner',
      estimatedDuration: '4 weeks',
      tags: []
    })
    .returning();
  return newCourse;
};

// Get course by ID
export const getCourseById = async (id: string) => {
  const [course] = await db
    .select()
    .from(learningPaths)
    .where(eq(learningPaths.id, id))
    .limit(1);
  return course;
};
