
import { db } from '../db';
import { modules } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  content: string;
  version: number;
}

// Get all lessons (using modules)
export const getLessons = async () => {
  return await db.select().from(modules);
};

// Add a new lesson
export const addLesson = async (lesson: Omit<Lesson, 'id'>) => {
  const [newLesson] = await db
    .insert(modules)
    .values({
      learningPathId: lesson.courseId,
      title: lesson.title,
      description: lesson.content,
      content: lesson.content,
      estimatedDuration: '30 minutes',
      order: 1
    })
    .returning();
  return newLesson;
};

// Get lessons by course ID
export const getLessonsByCourseId = async (courseId: string) => {
  return await db
    .select()
    .from(modules)
    .where(eq(modules.learningPathId, courseId));
};
