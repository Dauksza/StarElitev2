export async function getAuthUser(req: any) {
  // Get user info from Replit Auth headers
  const userId = req.headers['x-replit-user-id'];
  const userName = req.headers['x-replit-user-name'];
  const userEmail = req.headers['x-replit-user-email'] || `${userName}@replit.com`;
  const profileImage = req.headers['x-replit-user-profile-image'];
  const userBio = req.headers['x-replit-user-bio'];

  if (!userId || !userName) {
    return null; // User not authenticated
  }

  // Import storage here to avoid circular dependency
  const { storage } = await import("./storage");

  // Check if user exists, if not create them
  let user = await storage.getUser(userId);

  if (!user) {
    try {
      // Set admin status for chrisdauksza@gmail.com
      const isAdmin = userEmail === 'chrisdauksza@gmail.com';

      user = await storage.upsertUser({
        id: userId,
        email: userEmail,
        firstName: userName.split(' ')[0] || userName,
        lastName: userName.split(' ')[1] || '',
        profileImageUrl: profileImage || null,
        onboardingCompleted: false,
        currentLevel: 1,
        experiencePoints: 0,
        currentStreak: 0,
        longestStreak: 0,
        lastActivityDate: new Date(),
        skillsMastered: 0,
        learningHours: "0",
        globalRank: null,
        totalXp: 0,
        level: 1,
        displayName: userName,
        avatar: profileImage || null,
        bio: userBio || null,
        skills: [],
        isAdmin: isAdmin
      });
    } catch (error) {
      console.error('Error creating user:', error);
      // Try to get the user again in case of race condition
      user = await storage.getUser(userId);
    }
  }

  return user;
}