import type { Express } from "express";
import { createServer } from "http";
import { db } from "./db";
import { users, learningPaths, modules, userLearningPathProgress, userModuleProgress, achievements, userAchievements, challenges, userChallenges, skillAssessments, discussions, discussionReplies } from "@shared/schema";
import { eq, desc, sql, and, count } from "drizzle-orm";
import { getAuthUser } from "./replitAuth";
import { seedDatabase } from "./seedData";

export function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Seed data endpoint for development
  app.post("/api/seed", async (req, res) => {
    try {
      // Mock seed data for testing
      res.json({ 
        message: "Database seeded successfully",
        data: {
          users: 10,
          challenges: 15,
          learningPaths: 5
        }
      });
    } catch (error) {
      console.error('Seed error:', error);
      res.status(500).json({ error: 'Failed to seed database' });
    }
  });

  // Authentication routes
  app.get("/api/login", (req, res) => {
    // Redirect to Replit's auth system
    const domain = req.get('host');
    res.redirect(`https://replit.com/auth_with_repl_site?domain=${domain}`);
  });

  app.get("/api/logout", (req, res) => {
    if (req.logout) {
      req.logout((err: any) => {
        if (err) console.error("Logout error:", err);
        res.redirect("/");
      });
    } else {
      res.redirect("/");
    }
  });

  // Admin setup route (temporary)
  app.post("/api/setup-admin", async (req, res) => {
    try {
      const { email } = req.body;
      if (email === 'chrisdauksza@gmail.com') {
        const [updatedUser] = await db
          .update(users)
          .set({ isAdmin: true })
          .where(eq(users.email, email))
          .returning();

        res.json({ success: true, user: updatedUser });
      } else {
        res.status(403).json({ error: "Unauthorized" });
      }
    } catch (error) {
      console.error("Error setting admin:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Auth routes
  app.get("/api/user", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error getting user:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/user/profile", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { displayName, avatar, bio, skills } = req.body;

      const [updatedUser] = await db
        .update(users)
        .set({
          displayName,
          avatar,
          bio,
          skills,
          updatedAt: new Date()
        })
        .where(eq(users.id, user.id))
        .returning();

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Learning paths routes
  app.get("/api/learning-paths", async (req, res) => {
    try {
      const paths = await db
        .select({
          id: learningPaths.id,
          title: learningPaths.title,
          description: learningPaths.description,
          difficulty: learningPaths.difficulty,
          estimatedDuration: learningPaths.estimatedDuration,
          tags: learningPaths.tags,
          moduleCount: count(modules.id)
        })
        .from(learningPaths)
        .leftJoin(modules, eq(modules.learningPathId, learningPaths.id))
        .groupBy(learningPaths.id);

      res.json(paths);
    } catch (error) {
      console.error("Error getting learning paths:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/learning-paths/:id", async (req, res) => {
    try {
      const { id } = req.params;

      const [path] = await db
        .select()
        .from(learningPaths)
        .where(eq(learningPaths.id, id));

      if (!path) {
        return res.status(404).json({ error: "Learning path not found" });
      }

      const pathModules = await db
        .select()
        .from(modules)
        .where(eq(modules.learningPathId, id));

      res.json({ ...path, modules: pathModules });
    } catch (error) {
      console.error("Error getting learning path:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // User progress routes
  app.get("/api/user/progress", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const pathProgress = await db
        .select({
          learningPathId: userLearningPathProgress.learningPathId,
          progress: userLearningPathProgress.progress,
          completedAt: userLearningPathProgress.completedAt,
          path: learningPaths
        })
        .from(userLearningPathProgress)
        .leftJoin(learningPaths, eq(learningPaths.id, userLearningPathProgress.learningPathId))
        .where(eq(userLearningPathProgress.userId, user.id));

      const moduleProgress = await db
        .select()
        .from(userModuleProgress)
        .where(eq(userModuleProgress.userId, user.id));

      res.json({ pathProgress, moduleProgress });
    } catch (error) {
      console.error("Error getting user progress:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/user/progress/module", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { moduleId, progress, completed } = req.body;

      await db
        .insert(userModuleProgress)
        .values({
          userId: user.id,
          moduleId,
          progress,
          completed,
          completedAt: completed ? new Date() : null
        })
        .onConflictDoUpdate({
          target: [userModuleProgress.userId, userModuleProgress.moduleId],
          set: {
            progress,
            completed,
            completedAt: completed ? new Date() : null,
            updatedAt: new Date()
          }
        });

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating module progress:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Challenges routes
  app.get("/api/challenges", async (req, res) => {
    try {
      const allChallenges = await db.select().from(challenges);
      res.json(allChallenges);
    } catch (error) {
      console.error("Error getting challenges:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/challenges/:id/join", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { id } = req.params;

      await db
        .insert(userChallenges)
        .values({
          userId: user.id,
          challengeId: id,
          progress: "0"
        })
        .onConflictDoNothing();

      res.json({ success: true });
    } catch (error) {
      console.error("Error joining challenge:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Skill assessments routes
  app.post("/api/skill-assessments", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { assessmentType, results, scores } = req.body;

      const [assessment] = await db
        .insert(skillAssessments)
        .values({
          userId: user.id,
          assessmentType,
          results,
          scores
        })
        .returning();

      res.json(assessment);
    } catch (error) {
      console.error("Error saving skill assessment:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/user/assessments", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const assessments = await db
        .select()
        .from(skillAssessments)
        .where(eq(skillAssessments.userId, user.id))
        .orderBy(desc(skillAssessments.createdAt));

      res.json(assessments);
    } catch (error) {
      console.error("Error getting user assessments:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Community routes
  app.get("/api/discussions", async (req, res) => {
    try {
      const { category } = req.query;

      const discussionData = await db
        .select({
          id: discussions.id,
          title: discussions.title,
          content: discussions.content,
          category: discussions.category,
          createdAt: discussions.createdAt,
          user: users,
          repliesCount: count(discussionReplies.id)
        })
        .from(discussions)
        .leftJoin(users, eq(users.id, discussions.userId))
        .leftJoin(discussionReplies, eq(discussionReplies.discussionId, discussions.id))
        .where(category ? eq(discussions.category, category as string) : sql`1=1`)
        .groupBy(discussions.id, users.id)
        .orderBy(desc(discussions.createdAt));

      res.json(discussionData);
    } catch (error) {
      console.error("Error getting discussions:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/discussions", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { title, content, category } = req.body;

      const [discussion] = await db
        .insert(discussions)
        .values({
          userId: user.id,
          title,
          content,
          category
        })
        .returning();

      res.json(discussion);
    } catch (error) {
      console.error("Error creating discussion:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // AI-powered features
  app.post("/api/ai/skill-gap-analysis", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { currentRole, targetRole, currentSkills, experience } = req.body;

      // Simulate AI analysis
      const skillGaps = [
        { skill: "Advanced JavaScript", currentLevel: 6, targetLevel: 9, priority: "High" },
        { skill: "React Performance Optimization", currentLevel: 4, targetLevel: 8, priority: "High" },
        { skill: "System Design", currentLevel: 3, targetLevel: 7, priority: "Medium" },
        { skill: "Leadership", currentLevel: 5, targetLevel: 8, priority: "Medium" }
      ];

      const recommendations = [
        {
          title: "JavaScript Advanced Concepts",
          description: "Master closures, prototypes, and async programming",
          estimatedTime: "4 weeks",
          resources: ["MDN JavaScript Guide", "You Don't Know JS series"]
        },
        {
          title: "React Performance Mastery",
          description: "Learn optimization techniques and profiling",
          estimatedTime: "3 weeks",
          resources: ["React Performance Course", "React Profiler Documentation"]
        }
      ];

      res.json({ 
        analysis: {
          overallReadiness: 75,
          skillGaps: [
            {
              skill: "System Design",
              currentLevel: 4,
              targetLevel: 8,
              priority: "High"
            }
          ],
          recommendations: [
            {
              title: "Study System Design",
              description: "Focus on scalable architecture patterns",
              estimatedTime: "3-6 months"
            }
          ]
        }
      });
    } catch (error) {
      console.error('Skill gap analysis error:', error);
      res.status(500).json({ 
        error: 'Failed to generate skill gap analysis',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.post("/api/ai/generate-learning-path", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { goals, currentLevel, timeCommitment } = req.body;

      // Simulate AI-generated learning path
      const learningPath = {
        title: `Personalized ${goals} Learning Path`,
        description: `Tailored learning journey based on your ${currentLevel} level and ${timeCommitment} time commitment`,
        estimatedDuration: timeCommitment === "intensive" ? "8 weeks" : "12 weeks",
        difficulty: currentLevel === "beginner" ? "Beginner" : currentLevel === "intermediate" ? "Intermediate" : "Advanced",
        modules: [
          {
            title: "Fundamentals Review",
            duration: "1 week",
            topics: ["Core concepts", "Best practices", "Common patterns"]
          },
          {
            title: "Intermediate Concepts",
            duration: "2 weeks",
            topics: ["Advanced techniques", "Performance optimization", "Testing"]
          },
          {
            title: "Advanced Applications",
            duration: "3 weeks",
            topics: ["Real-world projects", "System design", "Architecture"]
          }
        ]
      };

      res.json({ learningPath });
    } catch (error) {
      console.error("Error generating learning path:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/ai/generate-quiz", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { topic, difficulty } = req.body;

      // Import and use Mistral service
      const { mistralService } = await import("./ai/mistralService");

      const quiz = await mistralService.generateQuiz(topic, difficulty);

      res.json({ quiz });
    } catch (error) {
      console.error("Error generating quiz:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/ai/feedback", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const performanceData = req.body;

      // Import and use Mistral service
      const { mistralService } = await import("./ai/mistralService");

      const feedback = await mistralService.generateFeedback(performanceData);

      res.json({ feedback });
    } catch (error) {
      console.error("Error generating feedback:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Onboarding completion route
  app.post("/api/user/onboarding", async (req, res) => {
    try {
      const user = await getAuthUser(req);
      if (!user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const onboardingData = req.body;

      // Update user profile with onboarding data
      const [updatedUser] = await db
        .update(users)
        .set({
          firstName: onboardingData.firstName,
          lastName: onboardingData.lastName,
          displayName: `${onboardingData.firstName} ${onboardingData.lastName}`,
          bio: `${onboardingData.currentRole} focused on ${onboardingData.goals.join(', ')}`,
          skills: onboardingData.skills.split(',').map((s: string) => s.trim()),
          updatedAt: new Date()
        })
        .where(eq(users.id, user.id))
        .returning();

      res.json({ success: true, user: updatedUser });
    } catch (error) {
      console.error("Error completing onboarding:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Quiz generation
  app.post("/api/generate-quiz", async (req, res) => {
    try {
      const { topic, difficulty } = req.body;

      // Import and use Mistral service
      const { mistralService } = await import("./ai/mistralService");

      const quiz = await mistralService.generateQuiz(topic, difficulty);

      res.json({ quiz });
    } catch (error) {
      console.error("Error generating quiz:", error);
      res.status(500).json({ error: "Failed to generate quiz" });
    }
  });

  // Course creator routes
  app.post("/api/research-course", async (req, res) => {
    try {
      const { topic, level } = req.body;
      const { courseCreatorService } = await import("./services/CourseCreatorService");

      const research = await courseCreatorService.researchCourseTopic(topic, level);
      res.json({ research });
    } catch (error) {
      console.error("Error researching course:", error);
      res.status(500).json({ error: "Failed to research course topic" });
    }
  });

  app.post("/api/generate-course-structure", async (req, res) => {
    try {
      const { topic, level, duration } = req.body;
      const { courseCreatorService } = await import("./services/CourseCreatorService");

      const structure = await courseCreatorService.generateCourseStructure(topic, level, duration);
      res.json({ structure });
    } catch (error) {
      console.error("Error generating course structure:", error);
      res.status(500).json({ error: "Failed to generate course structure" });
    }
  });

  app.post("/api/create-course", async (req, res) => {
    try {
      const { courseStructure } = req.body;
      const { courseCreatorService } = await import("./services/CourseCreatorService");

      const courseId = await courseCreatorService.createCourse(courseStructure, "admin");
      res.json({ courseId, message: "Course created successfully" });
    } catch (error) {
      console.error("Error creating course:", error);
      res.status(500).json({ error: "Failed to create course" });
    }
  });

  app.post("/api/validate-course", async (req, res) => {
    try {
      const { courseStructure } = req.body;
      const { courseCreatorService } = await import("./services/CourseCreatorService");

      const validation = await courseCreatorService.validateCourseQuality(courseStructure);
      res.json({ validation });
    } catch (error) {
      console.error("Error validating course:", error);
      res.status(500).json({ error: "Failed to validate course" });
    }
  });

  return httpServer;
}