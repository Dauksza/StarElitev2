import { db } from "./db";
import { users, learningPaths, modules, challenges, achievements } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  console.log("🌱 Seeding database...");

  try {
    // Create demo user if not exists
    const existingUser = await db.select().from(users).where(eq(users.email, "demo@example.com")).limit(1);

    let userId = existingUser[0]?.id;

    if (existingUser.length === 0) {
      const [newUser] = await db.insert(users).values({
        email: "demo@example.com",
        passwordHash: "demo-hash",
        displayName: "Demo User",
        isAdmin: true,
        subscription: "Premium",
        totalXp: 1250,
        level: 5,
        currentStreak: 7,
        bio: "AI enthusiast and lifelong learner",
        skills: ["JavaScript", "Python", "React", "Machine Learning"]
      }).returning();
      userId = newUser.id;
      console.log("✅ Demo user created");
    }

    // Create sample learning paths
    const existingPaths = await db.select().from(learningPaths).limit(1);

    if (existingPaths.length === 0) {
      const pathsToInsert = [
        {
          title: "Full-Stack Web Development",
          description: "Master modern web development with React, Node.js, and databases",
          difficulty: "Intermediate" as const,
          estimatedDuration: "12 weeks",
          tags: ["web", "javascript", "react", "nodejs"]
        },
        {
          title: "Data Science Fundamentals",
          description: "Learn Python, statistics, and machine learning basics",
          difficulty: "Beginner" as const,
          estimatedDuration: "8 weeks", 
          tags: ["python", "data-science", "statistics", "ml"]
        },
        {
          title: "AI & Machine Learning",
          description: "Deep dive into artificial intelligence and ML algorithms",
          difficulty: "Advanced" as const,
          estimatedDuration: "16 weeks",
          tags: ["ai", "machine-learning", "python", "tensorflow"]
        },
        {
          title: "Cloud Computing Essentials",
          description: "Learn AWS, Azure, and cloud-native development",
          difficulty: "Intermediate" as const,
          estimatedDuration: "10 weeks",
          tags: ["cloud", "aws", "devops", "kubernetes"]
        },
        {
          title: "Mobile App Development",
          description: "Build mobile apps with React Native and Flutter",
          difficulty: "Intermediate" as const,
          estimatedDuration: "14 weeks",
          tags: ["mobile", "react-native", "flutter", "ios", "android"]
        }
      ];

      const insertedPaths = await db.insert(learningPaths).values(pathsToInsert).returning();
      console.log("✅ Sample learning paths created");

      // Create sample modules for each learning path
      const modulesToInsert = [];

      for (const path of insertedPaths) {
        if (path.title === "Full-Stack Web Development") {
          modulesToInsert.push(
            {
              learningPathId: path.id,
              title: "HTML & CSS Fundamentals",
              description: "Learn the building blocks of web development",
              content: "Comprehensive introduction to HTML5 and CSS3, including semantic HTML, CSS Grid, Flexbox, and responsive design principles.",
              estimatedDuration: "2 weeks",
              order: 1
            },
            {
              learningPathId: path.id,
              title: "JavaScript Essentials",
              description: "Master JavaScript programming concepts",
              content: "Deep dive into JavaScript including ES6+ features, async/await, closures, prototypes, and DOM manipulation.",
              estimatedDuration: "3 weeks",
              order: 2
            },
            {
              learningPathId: path.id,
              title: "React Development",
              description: "Build modern UIs with React",
              content: "Learn React hooks, state management, component lifecycle, and building scalable React applications.",
              estimatedDuration: "4 weeks",
              order: 3
            },
            {
              learningPathId: path.id,
              title: "Backend with Node.js",
              description: "Create robust server-side applications",
              content: "Express.js, RESTful APIs, authentication, database integration, and deployment strategies.",
              estimatedDuration: "3 weeks",
              order: 4
            }
          );
        } else if (path.title === "Data Science Fundamentals") {
          modulesToInsert.push(
            {
              learningPathId: path.id,
              title: "Python for Data Science",
              description: "Master Python programming for data analysis",
              content: "Python basics, NumPy, Pandas, data manipulation, and visualization with Matplotlib and Seaborn.",
              estimatedDuration: "3 weeks",
              order: 1
            },
            {
              learningPathId: path.id,
              title: "Statistics & Probability",
              description: "Essential statistical concepts",
              content: "Descriptive statistics, probability distributions, hypothesis testing, and statistical inference.",
              estimatedDuration: "2 weeks",
              order: 2
            },
            {
              learningPathId: path.id,
              title: "Machine Learning Basics",
              description: "Introduction to ML algorithms",
              content: "Supervised learning, unsupervised learning, model evaluation, and scikit-learn implementation.",
              estimatedDuration: "3 weeks",
              order: 3
            }
          );
        }
      }

      if (modulesToInsert.length > 0) {
        await db.insert(modules).values(modulesToInsert);
        console.log("✅ Sample modules created");
      }
    }

    // Create sample achievements
    const existingAchievements = await db.select().from(achievements).limit(1);

    if (existingAchievements.length === 0) {
      const achievementsToInsert = [
        {
          title: "First Steps",
          description: "Complete your first lesson",
          icon: "baby-steps",
          type: "milestone" as const,
          criteria: "Complete 1 lesson"
        },
        {
          title: "Quick Learner", 
          description: "Complete 5 lessons in one day",
          icon: "lightning",
          type: "achievement" as const,
          criteria: "Complete 5 lessons in 24 hours"
        },
        {
          title: "Knowledge Seeker",
          description: "Complete an entire learning path",
          icon: "graduation-cap",
          type: "milestone" as const,
          criteria: "Complete all modules in a learning path"
        },
        {
          title: "Streak Master",
          description: "Maintain a 30-day learning streak",
          icon: "fire",
          type: "achievement" as const,
          criteria: "Learn for 30 consecutive days"
        },
        {
          title: "Challenge Champion",
          description: "Complete 10 coding challenges",
          icon: "trophy",
          type: "achievement" as const,
          criteria: "Complete 10 challenges with 80%+ score"
        },
        {
          title: "Community Helper",
          description: "Help 5 fellow learners in discussions",
          icon: "helping-hand",
          type: "social" as const,
          criteria: "Receive 5+ helpful votes on answers"
        }
      ];

      await db.insert(achievements).values(achievementsToInsert);
      console.log("✅ Sample achievements created");
    }

    // Create sample challenges
    const existingChallenges = await db.select().from(challenges).limit(1);

    if (existingChallenges.length === 0) {
      const challengesToInsert = [
        {
          title: "JavaScript Array Mastery",
          description: "Master array methods with practical coding challenges",
          type: "coding" as const,
          difficulty: "beginner" as const,
          estimatedTime: "45 minutes",
          points: 150
        },
        {
          title: "React Component Design",
          description: "Build reusable React components following best practices",
          type: "project" as const,
          difficulty: "intermediate" as const,
          estimatedTime: "2 hours",
          points: 300
        },
        {
          title: "API Integration Challenge",
          description: "Connect to external APIs and handle data efficiently",
          type: "coding" as const,
          difficulty: "intermediate" as const,
          estimatedTime: "90 minutes",
          points: 250
        },
        {
          title: "Database Design Sprint",
          description: "Design and implement a normalized database schema",
          type: "project" as const,
          difficulty: "advanced" as const,
          estimatedTime: "3 hours",
          points: 500
        },
        {
          title: "Algorithm Optimization",
          description: "Optimize algorithms for time and space complexity",
          type: "coding" as const,
          difficulty: "advanced" as const,
          estimatedTime: "2 hours",
          points: 400
        }
      ];

      await db.insert(challenges).values(challengesToInsert);
      console.log("✅ Sample challenges created");
    }

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}