
import Database from 'better-sqlite3';

const db = new Database('./starElite.db');

try {
  // Add isAdmin column if it doesn't exist
  try {
    db.exec(`ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT FALSE`);
    console.log('Added isAdmin column');
  } catch (e) {
    if (!e.message.includes('duplicate column name')) {
      console.error('Error adding column:', e.message);
    }
  }

  // Set chrisdauksza@gmail.com as admin
  const result = db.prepare(`
    UPDATE users 
    SET is_admin = TRUE 
    WHERE email = ?
  `).run('chrisdauksza@gmail.com');
  
  console.log(`Updated ${result.changes} rows`);
  
  // Verify the update
  const user = db.prepare(`SELECT * FROM users WHERE email = ?`).get('chrisdauksza@gmail.com');
  console.log('User after update:', user);
  
} catch (error) {
  console.error('Error:', error);
} finally {
  db.close();
}
