import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { AchievementCard } from "@/components/AchievementCard";
import { ChallengeCard } from "@/components/ChallengeCard";
import { ProgressRing } from "@/components/ProgressRing";
import { 
  Star, 
  Flame, 
  CheckCircle, 
  Clock, 
  Trophy, 
  Zap, 
  Users, 
  BookOpen,
  TrendingUp,
  Target,
  Brain,
  Award
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    retry: 1,
  });

  const { data: discussions } = useQuery({
    queryKey: ["/api/discussions"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  const userData = dashboardData?.user || user;
  const learningProgress = dashboardData?.learningProgress || [];
  const achievements = dashboardData?.achievements || [];
  const challenges = dashboardData?.challenges || [];
  const recentDiscussions = discussions?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-cosmic-white">
      {/* Navigation Header */}
      <nav className="bg-starfleet-blue text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-galaxy-gold rounded-full flex items-center justify-center">
                  <Star className="w-5 h-5 text-starfleet-blue" />
                </div>
                <span className="text-xl font-bold">STARElite</span>
                <Badge className="bg-galaxy-gold text-starfleet-blue hover:bg-galaxy-gold/90">
                  SUPERCHARGED
                </Badge>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link href="/dashboard" className="hover:text-galaxy-gold transition-colors duration-200">
                Dashboard
              </Link>
              <Link href="/learning-paths" className="hover:text-galaxy-gold transition-colors duration-200">
                Learning Paths
              </Link>
              <Link href="/challenges" className="hover:text-galaxy-gold transition-colors duration-200">
                Challenges
              </Link>
              <Link href="/community" className="hover:text-galaxy-gold transition-colors duration-200">
                Community
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-white bg-opacity-10 rounded-full px-3 py-1">
                <Flame className="w-4 h-4 text-galaxy-gold" />
                <span className="text-sm font-medium">{userData?.currentStreak || 0} days</span>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-galaxy-gold to-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-starfleet-blue font-bold text-sm">
                  {userData?.firstName?.[0]}{userData?.lastName?.[0]}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                className="text-white hover:text-galaxy-gold"
                onClick={() => window.location.href = "/api/logout"}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section with AI Integration */}
        <div className="mb-8 animate-fade-in">
          <div className="bg-gradient-to-r from-starfleet-blue to-blue-700 rounded-2xl p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-galaxy-gold opacity-10 rounded-full transform translate-x-32 -translate-y-32"></div>
            <div className="relative z-10">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-3xl font-bold mb-2">
                    Welcome back, {userData?.firstName || "Learner"}!
                  </h1>
                  <p className="text-blue-100 mb-4">
                    Your AI learning companion StarForce has some exciting insights for you today.
                  </p>
                  <div className="flex items-center space-x-2 bg-white bg-opacity-10 rounded-lg px-4 py-2 inline-flex">
                    <div className="w-2 h-2 bg-galaxy-gold rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">StarForce AI is analyzing your progress...</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold text-galaxy-gold">
                    Level {userData?.currentLevel || 1}
                  </div>
                  <div className="text-sm text-blue-200">Elite Learner</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* AI Insights Banner */}
        <div className="mb-8 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="bg-gradient-to-r from-galaxy-gold to-yellow-400 rounded-xl p-6 text-starfleet-blue">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-starfleet-blue rounded-full flex items-center justify-center">
                  <Zap className="w-6 h-6 text-galaxy-gold" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">StarForce AI Recommendation</h3>
                  <p className="text-sm opacity-80">
                    Based on your recent progress, you're ready to tackle advanced concepts. 
                    This could boost your skill rating by 15%!
                  </p>
                </div>
              </div>
              <Link href="/skill-gap-analysis">
                <Button className="bg-starfleet-blue text-galaxy-gold hover:bg-blue-900">
                  Start Learning
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <Card className="hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Current Streak</p>
                  <p className="text-3xl font-bold text-starfleet-blue">
                    {userData?.currentStreak || 0}
                  </p>
                  <p className="text-galaxy-gold text-sm font-medium">🔥 Keep it up!</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-starfleet-blue to-blue-600 rounded-lg flex items-center justify-center">
                  <Flame className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Skills Mastered</p>
                  <p className="text-3xl font-bold text-starfleet-blue">
                    {userData?.skillsMastered || 0}
                  </p>
                  <p className="text-green-600 text-sm font-medium">+1 this week</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Learning Hours</p>
                  <p className="text-3xl font-bold text-starfleet-blue">
                    {parseFloat(userData?.learningHours || "0").toFixed(0)}
                  </p>
                  <p className="text-blue-600 text-sm font-medium">12h this week</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">XP Points</p>
                  <p className="text-3xl font-bold text-starfleet-blue">
                    {userData?.experiencePoints || 0}
                  </p>
                  <p className="text-galaxy-gold text-sm font-medium">Top 5% globally</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-galaxy-gold to-yellow-500 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-starfleet-blue" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Progress & Learning Path */}
          <div className="lg:col-span-2 space-y-8">
            {/* Current Learning Path */}
            <Card className="animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-bold text-gray-900">Your Learning Journey</CardTitle>
                  <Link href="/learning-paths">
                    <Button variant="ghost" size="sm" className="text-starfleet-blue hover:text-blue-700">
                      View All Paths
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {learningProgress.length > 0 ? (
                  <div className="space-y-4">
                    {learningProgress.slice(0, 2).map((progress: any) => (
                      <div key={progress.id} className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-100">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-starfleet-blue">Learning Path Progress</h3>
                          <Badge variant="secondary" className="bg-galaxy-gold text-starfleet-blue">
                            {progress.status?.toUpperCase() || "IN PROGRESS"}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex-1">
                            <Progress value={parseFloat(progress.progress || "0")} className="h-2" />
                          </div>
                          <span className="text-sm font-medium text-gray-700">
                            {parseFloat(progress.progress || "0").toFixed(0)}%
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <span>Progress updated recently</span>
                          <span>Keep going!</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Start Your Learning Journey</h3>
                    <p className="text-gray-600 mb-4">Take a skill assessment to get personalized learning paths.</p>
                    <Link href="/skill-gap-analysis">
                      <Button className="bg-starfleet-blue text-white hover:bg-blue-700">
                        Take Assessment
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Skill Gap Analysis */}
            <Card className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900">AI Skill Gap Analysis</CardTitle>
                  </div>
                  <Link href="/skill-gap-analysis">
                    <Button className="bg-starfleet-blue text-white hover:bg-blue-700">
                      Run Analysis
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Discover Your Skill Gaps</h3>
                  <p className="text-gray-600 mb-4">
                    Get AI-powered insights into your strengths and areas for improvement.
                  </p>
                  <Link href="/skill-gap-analysis">
                    <Button variant="outline" className="border-starfleet-blue text-starfleet-blue hover:bg-starfleet-blue hover:text-white">
                      Start Analysis
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Achievements, Challenges, Community */}
          <div className="space-y-8">
            {/* Recent Achievements */}
            <Card className="animate-fade-in" style={{ animationDelay: "0.5s" }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-bold text-gray-900">Recent Achievements</CardTitle>
                  <Button variant="ghost" size="sm" className="text-starfleet-blue hover:text-blue-700">
                    View All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.length > 0 ? (
                    achievements.map((achievement: any) => (
                      <AchievementCard key={achievement.id} achievement={achievement} />
                    ))
                  ) : (
                    <div className="text-center py-4">
                      <Award className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">No achievements yet. Start learning to earn your first badge!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Active Challenges */}
            <Card className="animate-fade-in" style={{ animationDelay: "0.6s" }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-bold text-gray-900">Active Challenges</CardTitle>
                  <Link href="/challenges">
                    <Button variant="ghost" size="sm" className="text-starfleet-blue hover:text-blue-700">
                      Browse All
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {challenges.length > 0 ? (
                    challenges.map((challenge: any) => (
                      <ChallengeCard key={challenge.id} challenge={challenge} />
                    ))
                  ) : (
                    <div className="text-center py-4">
                      <Trophy className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">No active challenges. Join one to compete with peers!</p>
                      <Link href="/challenges">
                        <Button variant="outline" size="sm" className="mt-2">
                          Explore Challenges
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Community Activity */}
            <Card className="animate-fade-in" style={{ animationDelay: "0.7s" }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-bold text-gray-900">Community Activity</CardTitle>
                  <Link href="/community">
                    <Button variant="ghost" size="sm" className="text-starfleet-blue hover:text-blue-700">
                      Join Discussion
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentDiscussions.length > 0 ? (
                    recentDiscussions.map((discussion: any) => (
                      <div key={discussion.id} className="border-l-4 border-starfleet-blue bg-blue-50 p-4 rounded-r-lg">
                        <div className="flex items-start space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-bold text-xs">
                              {discussion.user?.firstName?.[0]}{discussion.user?.lastName?.[0]}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-gray-900 text-sm">
                              {discussion.user?.firstName} {discussion.user?.lastName}
                            </h4>
                            <p className="text-xs text-gray-600 mb-1">{discussion.title}</p>
                            <div className="flex items-center space-x-4 text-xs text-gray-500">
                              <span>{new Date(discussion.createdAt).toLocaleDateString()}</span>
                              <span>❤️ {discussion.likesCount} likes</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4">
                      <Users className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">No recent discussions. Be the first to start a conversation!</p>
                      <Link href="/community">
                        <Button variant="outline" size="sm" className="mt-2">
                          Start Discussion
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Quick Actions Footer */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in" style={{ animationDelay: "0.8s" }}>
          <Link href="/skill-gap-analysis">
            <Button className="bg-starfleet-blue text-white p-6 rounded-xl hover:bg-blue-700 transition-colors duration-200 text-left group h-auto w-full">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform duration-200">→</div>
              </div>
              <h3 className="text-lg font-bold mb-2">Quick Assessment</h3>
              <p className="text-blue-100 text-sm">Take a 5-minute skill assessment to get personalized recommendations</p>
            </Button>
          </Link>

          <Link href="/learning-paths">
            <Button className="bg-galaxy-gold text-starfleet-blue p-6 rounded-xl hover:bg-yellow-400 transition-colors duration-200 text-left group h-auto w-full">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-starfleet-blue bg-opacity-20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                  <BookOpen className="w-6 h-6 text-starfleet-blue" />
                </div>
                <div className="w-5 h-5 text-starfleet-blue group-hover:translate-x-1 transition-transform duration-200">→</div>
              </div>
              <h3 className="text-lg font-bold mb-2">Explore New Paths</h3>
              <p className="text-starfleet-blue opacity-80 text-sm">Discover cutting-edge courses in AI, blockchain, and emerging technologies</p>
            </Button>
          </Link>

          <Link href="/challenges">
            <Button variant="outline" className="border-2 border-starfleet-blue text-starfleet-blue p-6 rounded-xl hover:bg-starfleet-blue hover:text-white transition-colors duration-200 text-left group h-auto w-full">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-starfleet-blue bg-opacity-10 rounded-lg flex items-center justify-center group-hover:bg-white group-hover:bg-opacity-20 group-hover:scale-110 transition-all duration-200">
                  <Users className="w-6 h-6 text-starfleet-blue group-hover:text-white" />
                </div>
                <div className="w-5 h-5 text-starfleet-blue group-hover:text-white group-hover:translate-x-1 transition-all duration-200">→</div>
              </div>
              <h3 className="text-lg font-bold mb-2">Join Team Challenge</h3>
              <p className="text-starfleet-blue group-hover:text-white opacity-80 text-sm">Connect with peers and tackle collaborative projects together</p>
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
