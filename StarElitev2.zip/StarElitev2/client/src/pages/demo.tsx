import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  BookOpen, 
  Trophy, 
  Users, 
  Target, 
  Brain, 
  Star, 
  Play,
  CheckCircle,
  TrendingUp,
  Award,
  GraduationCap,
  Clock,
  BarChart
} from "lucide-react";
import { Link } from "wouter";
import { SkillAssessment } from "@/components/SkillAssessment";

export default function Demo() {
  const [currentTab, setCurrentTab] = useState("overview");
  const [skillLevel, setSkillLevel] = useState("");
  const [currentGoal, setCurrentGoal] = useState("");
  const [showFullAssessment, setShowFullAssessment] = useState(false);

  const demoLearningPath = {
    title: "AI-Curated Data Science Path",
    description: "Personalized based on your beginner level and career goals",
    estimatedDuration: "12 weeks",
    modules: [
      { title: "Python Fundamentals", duration: "2 weeks", status: "recommended" },
      { title: "Statistics & Data Analysis", duration: "3 weeks", status: "core" },
      { title: "Machine Learning Basics", duration: "4 weeks", status: "core" },
      { title: "Real-world Projects", duration: "3 weeks", status: "capstone" }
    ]
  };

  const handleAssessmentComplete = (score: number, results: any) => {
    console.log('Assessment completed:', { score, results });
    // You can handle the results here, perhaps redirect to enrollment or show detailed results
  };

  if (showFullAssessment) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        {/* Navigation */}
        <nav className="bg-white shadow-lg border-b-4 border-blue-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
              </Link>
              <div className="flex items-center space-x-3">
                <Button variant="outline" onClick={() => setShowFullAssessment(false)}>
                  ← Back to Demo
                </Button>
                <Button asChild>
                  <Link href="/api/login">Sign Up Free</Link>
                </Button>
              </div>
            </div>
          </div>
        </nav>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <SkillAssessment onComplete={handleAssessmentComplete} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-blue-800">StarElite</span>
            </Link>
            <div className="flex items-center space-x-3">
              <Button variant="outline" asChild>
                <Link href="/">← Back to Home</Link>
              </Button>
              <Button asChild>
                <Link href="/api/login">Sign Up Free</Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Experience StarElite's AI-Powered Learning
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Try our interactive demo to see how our platform personalizes your learning journey
          </p>
        </div>

        <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Platform Overview</TabsTrigger>
            <TabsTrigger value="assessment">Skill Assessment</TabsTrigger>
            <TabsTrigger value="learning">Learning Paths</TabsTrigger>
            <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="border-2 border-blue-100 hover:border-blue-300 transition-colors">
                <CardHeader className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-3 mx-auto">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">AI-Powered Assessment</CardTitle>
                  <CardDescription>
                    Intelligent skill evaluation that adapts to your knowledge level
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => setCurrentTab("assessment")}
                  >
                    Try Assessment
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-100 hover:border-purple-300 transition-colors">
                <CardHeader className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-3 mx-auto">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">Personalized Learning</CardTitle>
                  <CardDescription>
                    Custom learning paths based on your goals and skill level
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => setCurrentTab("learning")}
                  >
                    View Learning Paths
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-2 border-green-100 hover:border-green-300 transition-colors">
                <CardHeader className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mb-3 mx-auto">
                    <BarChart className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">Progress Tracking</CardTitle>
                  <CardDescription>
                    Real-time analytics and achievement tracking
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => setCurrentTab("progress")}
                  >
                    See Progress Demo
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">Ready to Start Your Journey?</h3>
                <p className="text-blue-100 mb-6">
                  Join thousands of learners who've accelerated their careers with StarElite
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" variant="secondary" asChild>
                    <Link href="/api/login">Start Learning Free</Link>
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" asChild>
                    <Link href="/skills">View All Courses</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  AI Skill Assessment Demo
                </CardTitle>
                <CardDescription>
                  Experience our full assessment wizard with course selection and AI analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Assessment Features:</h3>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Choose from 25+ high-demand courses
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Experience-based question difficulty
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        AI-powered analysis and recommendations
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Personalized learning path suggestions
                      </li>
                    </ul>
                  </div>
                  <div className="flex items-center justify-center">
                    <Button 
                      size="lg" 
                      onClick={() => setShowFullAssessment(true)}
                      className="w-full"
                    >
                      Start Full Assessment
                      <Play className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="learning" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personalized Learning Path Generator</CardTitle>
                  <CardDescription>
                    See how our AI creates custom learning experiences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="skill-level">Current Skill Level</Label>
                    <Select value={skillLevel} onValueChange={setSkillLevel}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="goal">Learning Goal</Label>
                    <Select value={currentGoal} onValueChange={setCurrentGoal}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your goal" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="career-change">Career Change</SelectItem>
                        <SelectItem value="skill-upgrade">Skill Upgrade</SelectItem>
                        <SelectItem value="promotion">Get Promoted</SelectItem>
                        <SelectItem value="freelance">Start Freelancing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full" disabled={!skillLevel || !currentGoal}>
                    Generate My Learning Path
                  </Button>
                </CardContent>
              </Card>

              {skillLevel && currentGoal && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="w-5 h-5 text-yellow-500" />
                      {demoLearningPath.title}
                    </CardTitle>
                    <CardDescription>{demoLearningPath.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Estimated Duration:</span>
                        <Badge variant="outline">{demoLearningPath.estimatedDuration}</Badge>
                      </div>

                      <div className="space-y-3">
                        {demoLearningPath.modules.map((module, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                              <div className="font-medium">{module.title}</div>
                              <div className="text-sm text-gray-600">{module.duration}</div>
                            </div>
                            <Badge 
                              variant={module.status === 'recommended' ? 'default' : 'secondary'}
                            >
                              {module.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Learning Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Overall Progress</span>
                        <span className="text-sm text-gray-600">68%</span>
                      </div>
                      <Progress value={68} />
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Python Fundamentals</span>
                        <span className="text-sm text-gray-600">95%</span>
                      </div>
                      <Progress value={95} />
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Data Analysis</span>
                        <span className="text-sm text-gray-600">72%</span>
                      </div>
                      <Progress value={72} />
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Machine Learning</span>
                        <span className="text-sm text-gray-600">23%</span>
                      </div>
                      <Progress value={23} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5" />
                    Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                      <Trophy className="w-8 h-8 text-yellow-600" />
                      <div>
                        <div className="font-medium">Python Master</div>
                        <div className="text-sm text-gray-600">Completed all Python modules</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                      <Star className="w-8 h-8 text-blue-600" />
                      <div>
                        <div className="font-medium">Quick Learner</div>
                        <div className="text-sm text-gray-600">Finished 5 lessons in one day</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                      <CheckCircle className="w-8 h-8 text-green-600" />
                      <div>
                        <div className="font-medium">Consistent</div>
                        <div className="text-sm text-gray-600">7-day learning streak</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}