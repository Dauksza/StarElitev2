import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Trophy, 
  Users, 
  Target, 
  Brain, 
  Star, 
  Play,
  CheckCircle,
  TrendingUp,
  Award,
  GraduationCap,
  Clock,
  BarChart,
  ArrowRight,
  Zap,
  Shield,
  Globe
} from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleGetStarted = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-lg border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-blue-800">StarElite</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/skills" className="text-gray-700 hover:text-blue-600 font-medium">
                Courses
              </Link>
              <Link href="/demo" className="text-gray-700 hover:text-blue-600 font-medium">
                Demo
              </Link>
              <Button variant="outline" onClick={handleLogin}>
                Sign In
              </Button>
              <Button onClick={handleGetStarted}>
                Get Started Free
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Master the
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Top 25 </span>
              High-Demand Skills
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-4xl mx-auto leading-relaxed">
              AI-powered learning paths designed to get you job-ready in weeks, not years. 
              Walk into six-figure roles with confidence.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16">
              <Button size="lg" className="text-lg px-8 py-4" onClick={handleGetStarted}>
                Start Learning Free
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-4" asChild>
                <Link href="/skills">
                  See All 25 In-Demand Courses
                </Link>
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">92%</div>
                <div className="text-gray-600">Job Placement Rate</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-600 mb-2">$115k</div>
                <div className="text-gray-600">Average Starting Salary</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-2">8-16</div>
                <div className="text-gray-600">Weeks to Job Ready</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why StarElite Gets Results
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform adapts to your learning style and career goals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-2 hover:border-blue-300 transition-all duration-300 hover:shadow-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl">AI-Powered Assessment</CardTitle>
                <CardDescription>
                  Smart skill evaluation that adapts to your knowledge level and creates personalized learning paths
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline" asChild>
                  <Link href="/demo">Try Assessment</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-purple-300 transition-all duration-300 hover:shadow-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl">Job-Ready Curriculum</CardTitle>
                <CardDescription>
                  Industry-aligned courses that teach exactly what employers are hiring for in 2025
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline" asChild>
                  <Link href="/skills">View Courses</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-green-300 transition-all duration-300 hover:shadow-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl">Career Acceleration</CardTitle>
                <CardDescription>
                  From learning to landing - our graduates walk into six-figure roles within months
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline" onClick={handleGetStarted}>
                  Start Journey
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Top Skills Preview */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              2025's Most In-Demand Skills
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Master these high-paying skills and accelerate your career
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              { icon: Brain, title: "AI & Machine Learning", salary: "$130k+", demand: "Critical" },
              { icon: Shield, title: "Cybersecurity", salary: "$95k+", demand: "Very High" },
              { icon: Globe, title: "Cloud Computing", salary: "$115k+", demand: "Very High" },
              { icon: BarChart, title: "Data Science", salary: "$120k+", demand: "Critical" }
            ].map((skill, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center mb-3 mx-auto">
                    <skill.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{skill.title}</h3>
                  <Badge variant="outline" className="mb-2">{skill.demand}</Badge>
                  <p className="text-green-600 font-bold">{skill.salary}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button size="lg" asChild>
              <Link href="/skills">
                View All 25 High-Demand Courses
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Transform Your Career?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of professionals who've accelerated their careers with StarElite
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" onClick={handleGetStarted}>
              Start Learning Free
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" asChild>
              <Link href="/demo">Try Interactive Demo</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">StarElite</span>
            </div>
            <p className="text-gray-400">
              Accelerating careers through AI-powered learning
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}