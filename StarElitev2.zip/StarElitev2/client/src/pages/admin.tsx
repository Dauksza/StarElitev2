import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, BookOpen, Target, Trophy } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Admin() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && (!user || !user.isAdmin)) {
      setLocation("/dashboard");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!user || !user.isAdmin) {
    return <div>Unauthorized</div>;
  }
  const queryClient = useQueryClient();
  const [newAchievement, setNewAchievement] = useState({
    title: "",
    description: "",
    icon: "trophy",
    type: "milestone",
    criteria: ""
  });

  const [newCourse, setNewCourse] = useState({
    title: "",
    description: "",
    difficulty: "Beginner",
    estimatedDuration: "4 weeks"
  });

  const [newLesson, setNewLesson] = useState({
    learningPathId: "",
    title: "",
    description: "",
    content: "",
    estimatedDuration: "30 minutes"
  });

  // Queries
  const achievementsQuery = useQuery({
    queryKey: ["/api/achievements"],
    queryFn: () => api.get("/api/achievements").then(res => res.json())
  });

  const usersQuery = useQuery({
    queryKey: ["/api/admin/users"],
    queryFn: () => api.get("/api/admin/users").then(res => res.json())
  });

  const coursesQuery = useQuery({
    queryKey: ["/api/admin/courses"],
    queryFn: () => api.get("/api/admin/courses").then(res => res.json())
  });

  const lessonsQuery = useQuery({
    queryKey: ["/api/admin/lessons"],
    queryFn: () => api.get("/api/admin/lessons").then(res => res.json())
  });

  // Mutations
  const createCourseMutation = useMutation({
    mutationFn: (course: typeof newCourse) => api.post("/api/admin/courses", course),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/courses"] });
      setNewCourse({ title: "", description: "", difficulty: "Beginner", estimatedDuration: "4 weeks" });
    }
  });

  const createLessonMutation = useMutation({
    mutationFn: (lesson: typeof newLesson) => api.post("/api/admin/lessons", lesson),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lessons"] });
      setNewLesson({ learningPathId: "", title: "", description: "", content: "", estimatedDuration: "30 minutes" });
    }
  });

  const createAchievementMutation = useMutation({
    mutationFn: (achievement: typeof newAchievement) => api.post("/api/admin/achievements", achievement),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
      setNewAchievement({ title: "", description: "", icon: "trophy", type: "milestone", criteria: "" });
    }
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your StarElite platform</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{usersQuery.data?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Learning Paths</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{coursesQuery.data?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Lessons</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{lessonsQuery.data?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Achievements</CardTitle>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{achievementsQuery.data?.length || 0}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="courses">Learning Paths</TabsTrigger>
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage registered users and their subscriptions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {usersQuery.data?.map((user: any) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold">{user.displayName || user.email}</h4>
                        <p className="text-sm text-gray-600">{user.email}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant={user.isAdmin ? "default" : "secondary"}>
                            {user.isAdmin ? "Admin" : "User"}
                          </Badge>
                          <Badge variant="outline">{user.subscription || "Freemium"}</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="courses" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create Learning Path</CardTitle>
                <CardDescription>Add new learning paths to the platform</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="course-title">Title</Label>
                    <Input
                      id="course-title"
                      value={newCourse.title}
                      onChange={(e) => setNewCourse(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter course title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="course-duration">Duration</Label>
                    <Input
                      id="course-duration"
                      value={newCourse.estimatedDuration}
                      onChange={(e) => setNewCourse(prev => ({ ...prev, estimatedDuration: e.target.value }))}
                      placeholder="e.g., 4 weeks"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="course-difficulty">Difficulty</Label>
                  <Select value={newCourse.difficulty} onValueChange={(value) => setNewCourse(prev => ({ ...prev, difficulty: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="course-description">Description</Label>
                  <Textarea
                    id="course-description"
                    value={newCourse.description}
                    onChange={(e) => setNewCourse(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter course description"
                    rows={4}
                  />
                </div>
                <Button 
                  onClick={() => createCourseMutation.mutate(newCourse)}
                  disabled={!newCourse.title || !newCourse.description}
                >
                  Create Learning Path
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Learning Paths</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {coursesQuery.data?.map((course: any) => (
                    <div key={course.id} className="p-4 border rounded-lg">
                      <h4 className="font-semibold">{course.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{course.description}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="outline">{course.difficulty}</Badge>
                        <Badge variant="secondary">{course.estimatedDuration}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="lessons" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create Lesson</CardTitle>
                <CardDescription>Add new lessons to existing learning paths</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="lesson-path">Learning Path</Label>
                  <Select value={newLesson.learningPathId} onValueChange={(value) => setNewLesson(prev => ({ ...prev, learningPathId: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a learning path" />
                    </SelectTrigger>
                    <SelectContent>
                      {coursesQuery.data?.map((course: any) => (
                        <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="lesson-title">Title</Label>
                    <Input
                      id="lesson-title"
                      value={newLesson.title}
                      onChange={(e) => setNewLesson(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter lesson title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lesson-duration">Duration</Label>
                    <Input
                      id="lesson-duration"
                      value={newLesson.estimatedDuration}
                      onChange={(e) => setNewLesson(prev => ({ ...prev, estimatedDuration: e.target.value }))}
                      placeholder="e.g., 30 minutes"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="lesson-description">Description</Label>
                  <Textarea
                    id="lesson-description"
                    value={newLesson.description}
                    onChange={(e) => setNewLesson(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter lesson description"
                    rows={2}
                  />
                </div>
                <div>
                  <Label htmlFor="lesson-content">Content</Label>
                  <Textarea
                    id="lesson-content"
                    value={newLesson.content}
                    onChange={(e) => setNewLesson(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Enter lesson content (supports Markdown)"
                    rows={6}
                  />
                </div>
                <Button 
                  onClick={() => createLessonMutation.mutate(newLesson)}
                  disabled={!newLesson.title || !newLesson.learningPathId}
                >
                  Create Lesson
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create Achievement</CardTitle>
                <CardDescription>Add new achievements and badges</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="achievement-title">Title</Label>
                    <Input
                      id="achievement-title"
                      value={newAchievement.title}
                      onChange={(e) => setNewAchievement(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter achievement title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="achievement-icon">Icon</Label>
                    <Input
                      id="achievement-icon"
                      value={newAchievement.icon}
                      onChange={(e) => setNewAchievement(prev => ({ ...prev, icon: e.target.value }))}
                      placeholder="e.g., trophy"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="achievement-type">Type</Label>
                  <Select value={newAchievement.type} onValueChange={(value) => setNewAchievement(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="milestone">Milestone</SelectItem>
                      <SelectItem value="progress">Progress</SelectItem>
                      <SelectItem value="special">Special</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="achievement-description">Description</Label>
                  <Textarea
                    id="achievement-description"
                    value={newAchievement.description}
                    onChange={(e) => setNewAchievement(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter achievement description"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="achievement-criteria">Criteria</Label>
                  <Textarea
                    id="achievement-criteria"
                    value={newAchievement.criteria}
                    onChange={(e) => setNewAchievement(prev => ({ ...prev, criteria: e.target.value }))}
                    placeholder="Enter criteria for earning this achievement"
                    rows={2}
                  />
                </div>
                <Button 
                  onClick={() => createAchievementMutation.mutate(newAchievement)}
                  disabled={!newAchievement.title || !newAchievement.description}
                >
                  Create Achievement
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievementsQuery.data?.map((achievement: any) => (
                    <div key={achievement.id} className="p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Trophy className="h-6 w-6 text-yellow-500" />
                        <div className="flex-1">
                          <h4 className="font-semibold">{achievement.title}</h4>
                          <p className="text-sm text-gray-600">{achievement.description}</p>
                          <Badge variant="outline" className="mt-1">{achievement.type}</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}