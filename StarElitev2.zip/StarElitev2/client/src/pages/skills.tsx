import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  BookOpen, 
  Clock, 
  Trophy, 
  Star, 
  Search,
  GraduationCap,
  Target,
  CheckCircle,
  ArrowRight,
  DollarSign,
  Users,
  TrendingUp
} from "lucide-react";
import { Link } from "wouter";

interface Skill {
  id: string;
  title: string;
  description: string;
  icon: any;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  startingSalary: string;
  demand: "High" | "Very High" | "Critical";
  category: "Technical" | "Soft Skills" | "Business";
  lessons: string[];
  courseOutline: string[];
}

const skills: Skill[] = [
  {
    id: "data-science-ai",
    title: "Data Science & AI",
    description: "Master Python, machine learning, and AI algorithms to become a Data Scientist or AI Engineer",
    icon: Database,
    difficulty: "Advanced",
    duration: "16 weeks",
    startingSalary: "$120,000+",
    demand: "Critical",
    category: "Technical",
    lessons: [
      "Python Programming Fundamentals",
      "Statistics and Probability",
      "Data Manipulation with Pandas",
      "Machine Learning Algorithms",
      "Deep Learning with TensorFlow",
      "Natural Language Processing",
      "Computer Vision",
      "Model Deployment and MLOps"
    ],
    courseOutline: [
      "Week 1-3: Python & Statistics Foundation",
      "Week 4-6: Data Analysis & Visualization",
      "Week 7-9: Machine Learning Fundamentals",
      "Week 10-12: Advanced ML & Deep Learning",
      "Week 13-14: Specialized AI Applications",
      "Week 15-16: Capstone Project & Deployment"
    ]
  },
  {
    id: "cybersecurity",
    title: "Cybersecurity",
    description: "Protect digital assets and become a Security Analyst or Chief Information Security Officer",
    icon: Shield,
    difficulty: "Intermediate",
    duration: "12 weeks",
    startingSalary: "$85,000+",
    demand: "Very High",
    category: "Technical",
    lessons: [
      "Network Security Fundamentals",
      "Ethical Hacking & Penetration Testing",
      "Incident Response & Forensics",
      "Risk Assessment & Management",
      "Compliance & Governance",
      "Security Architecture",
      "Threat Intelligence",
      "Security Automation"
    ],
    courseOutline: [
      "Week 1-2: Security Fundamentals",
      "Week 3-4: Network Security",
      "Week 5-6: Ethical Hacking",
      "Week 7-8: Incident Response",
      "Week 9-10: Risk Management",
      "Week 11-12: Advanced Security & Certification Prep"
    ]
  },
  {
    id: "cloud-computing",
    title: "Cloud Computing",
    description: "Master AWS, Azure, and Google Cloud platforms for scalable infrastructure management",
    icon: Cloud,
    difficulty: "Intermediate",
    duration: "10 weeks",
    startingSalary: "$95,000+",
    demand: "Very High",
    category: "Technical",
    lessons: [
      "Cloud Architecture Fundamentals",
      "AWS Core Services",
      "Azure Administration",
      "Google Cloud Platform",
      "Container Orchestration (Kubernetes)",
      "Infrastructure as Code",
      "Cloud Security",
      "Cost Optimization"
    ],
    courseOutline: [
      "Week 1-2: Cloud Fundamentals",
      "Week 3-4: AWS Deep Dive",
      "Week 5-6: Multi-Cloud Strategies",
      "Week 7-8: DevOps & Automation",
      "Week 9-10: Security & Optimization"
    ]
  },
  {
    id: "software-development",
    title: "Software Development",
    description: "Full-stack development with modern frameworks and languages",
    icon: Code,
    difficulty: "Beginner",
    duration: "14 weeks",
    startingSalary: "$75,000+",
    demand: "High",
    category: "Technical",
    lessons: [
      "Programming Fundamentals",
      "Web Development (HTML, CSS, JavaScript)",
      "Frontend Frameworks (React, Vue)",
      "Backend Development (Node.js, Python)",
      "Database Design & Management",
      "API Development",
      "Version Control (Git)",
      "Testing & Debugging"
    ],
    courseOutline: [
      "Week 1-3: Programming Basics",
      "Week 4-6: Frontend Development",
      "Week 7-9: Backend Development",
      "Week 10-11: Database Integration",
      "Week 12-14: Full-Stack Projects"
    ]
  },
  {
    id: "project-management",
    title: "Project Management",
    description: "Agile, Scrum, and strategic planning across tech and traditional industries",
    icon: Briefcase,
    difficulty: "Beginner",
    duration: "8 weeks",
    startingSalary: "$80,000+",
    demand: "High",
    category: "Business",
    lessons: [
      "Project Management Fundamentals",
      "Agile & Scrum Methodologies",
      "Risk Management",
      "Resource Planning",
      "Stakeholder Communication",
      "Budget Management",
      "Quality Assurance",
      "PMP Certification Prep"
    ],
    courseOutline: [
      "Week 1-2: PM Fundamentals",
      "Week 3-4: Agile Methodologies",
      "Week 5-6: Advanced Planning",
      "Week 7-8: Certification & Practice"
    ]
  },
  {
    id: "digital-marketing",
    title: "Digital Marketing & SEO",
    description: "Drive online business growth through strategic digital marketing campaigns",
    icon: TrendingUp,
    difficulty: "Beginner",
    duration: "10 weeks",
    startingSalary: "$55,000+",
    demand: "High",
    category: "Business",
    lessons: [
      "Digital Marketing Strategy",
      "Search Engine Optimization",
      "Pay-Per-Click Advertising",
      "Social Media Marketing",
      "Content Marketing",
      "Email Marketing",
      "Analytics & Reporting",
      "Conversion Optimization"
    ],
    courseOutline: [
      "Week 1-2: Marketing Fundamentals",
      "Week 3-4: SEO & Content",
      "Week 5-6: Paid Advertising",
      "Week 7-8: Social Media",
      "Week 9-10: Analytics & Optimization"
    ]
  },
  {
    id: "communication",
    title: "Professional Communication",
    description: "Master written and verbal communication for remote and hybrid work environments",
    icon: MessageSquare,
    difficulty: "Beginner",
    duration: "6 weeks",
    startingSalary: "$50,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: [
      "Effective Written Communication",
      "Public Speaking & Presentations",
      "Cross-Cultural Communication",
      "Virtual Meeting Management",
      "Conflict Resolution",
      "Emotional Intelligence",
      "Persuasive Communication",
      "Leadership Communication"
    ],
    courseOutline: [
      "Week 1-2: Communication Fundamentals",
      "Week 3-4: Public Speaking",
      "Week 5-6: Advanced Techniques"
    ]
  },
  {
    id: "ux-ui-design",
    title: "UX/UI Design",
    description: "Create intuitive and beautiful digital experiences that users love",
    icon: Palette,
    difficulty: "Intermediate",
    duration: "12 weeks",
    startingSalary: "$70,000+",
    demand: "High",
    category: "Technical",
    lessons: [
      "Design Thinking Process",
      "User Research & Testing",
      "Wireframing & Prototyping",
      "Visual Design Principles",
      "Figma & Design Tools",
      "Responsive Design",
      "Accessibility Standards",
      "Design Systems"
    ],
    courseOutline: [
      "Week 1-3: UX Fundamentals",
      "Week 4-6: Design Tools",
      "Week 7-9: Visual Design",
      "Week 10-12: Portfolio Projects"
    ]
  },
  {
    id: "business-intelligence",
    title: "Business Intelligence",
    description: "Transform data into strategic insights for business decision-making",
    icon: BarChart,
    difficulty: "Intermediate",
    duration: "10 weeks",
    startingSalary: "$78,000+",
    demand: "High",
    category: "Business",
    lessons: [
      "Data Warehousing Concepts",
      "SQL & Database Querying",
      "Power BI & Tableau",
      "Statistical Analysis",
      "Data Visualization",
      "KPI Development",
      "Report Automation",
      "Predictive Analytics"
    ],
    courseOutline: [
      "Week 1-2: BI Fundamentals",
      "Week 3-4: Data Tools",
      "Week 5-6: Visualization",
      "Week 7-8: Advanced Analytics",
      "Week 9-10: Strategy & Implementation"
    ]
  },
  {
    id: "mobile-development",
    title: "Mobile App Development",
    description: "Build native and cross-platform mobile applications for iOS and Android",
    icon: Smartphone,
    difficulty: "Intermediate",
    duration: "14 weeks",
    startingSalary: "$82,000+",
    demand: "High",
    category: "Technical",
    lessons: [
      "Mobile Development Fundamentals",
      "React Native Development",
      "iOS Development (Swift)",
      "Android Development (Kotlin)",
      "App Store Optimization",
      "Mobile UI/UX Design",
      "API Integration",
      "App Monetization"
    ],
    courseOutline: [
      "Week 1-3: Mobile Fundamentals",
      "Week 4-6: Cross-Platform Development",
      "Week 7-9: Native Development",
      "Week 10-12: Advanced Features",
      "Week 13-14: Publishing & Monetization"
    ]
  }
  // Adding remaining 15 skills to complete the 25...
];

// Adding the remaining 15 skills
const additionalSkills: Skill[] = [
  {
    id: "automation",
    title: "Automation & Process Optimization",
    description: "Streamline workflows and boost productivity with automation tools",
    icon: Target,
    difficulty: "Intermediate",
    duration: "8 weeks",
    startingSalary: "$72,000+",
    demand: "High",
    category: "Technical",
    lessons: ["RPA Fundamentals", "Python Automation", "Workflow Design", "Testing Automation"],
    courseOutline: ["Week 1-2: Automation Basics", "Week 3-4: Tool Mastery", "Week 5-6: Advanced Workflows", "Week 7-8: Implementation"]
  },
  {
    id: "data-visualization",
    title: "Data Visualization",
    description: "Present complex data in accessible and compelling visual formats",
    icon: PieChart,
    difficulty: "Beginner",
    duration: "6 weeks",
    startingSalary: "$65,000+",
    demand: "High",
    category: "Technical",
    lessons: ["Visualization Principles", "Tableau Mastery", "D3.js", "Dashboard Design"],
    courseOutline: ["Week 1-2: Fundamentals", "Week 3-4: Tools", "Week 5-6: Advanced Techniques"]
  },
  {
    id: "adaptability",
    title: "Adaptability & Learning Agility",
    description: "Develop resilience and continuous learning mindset for changing environments",
    icon: Brain,
    difficulty: "Beginner",
    duration: "4 weeks",
    startingSalary: "$55,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Growth Mindset", "Change Management", "Continuous Learning", "Resilience Building"],
    courseOutline: ["Week 1: Mindset", "Week 2: Learning Strategies", "Week 3: Change Adaptation", "Week 4: Implementation"]
  },
  {
    id: "problem-solving",
    title: "Problem-Solving & Critical Thinking",
    description: "Master analytical thinking and creative problem-solving techniques",
    icon: Lightbulb,
    difficulty: "Beginner",
    duration: "6 weeks",
    startingSalary: "$60,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Critical Thinking", "Problem Analysis", "Solution Design", "Decision Making"],
    courseOutline: ["Week 1-2: Thinking Frameworks", "Week 3-4: Analysis Techniques", "Week 5-6: Implementation"]
  },
  {
    id: "public-speaking",
    title: "Public Speaking & Presentation",
    description: "Confidently present ideas to audiences of any size",
    icon: Users,
    difficulty: "Beginner",
    duration: "5 weeks",
    startingSalary: "$58,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Presentation Structure", "Audience Engagement", "Visual Aids", "Confidence Building"],
    courseOutline: ["Week 1: Basics", "Week 2: Structure", "Week 3: Delivery", "Week 4: Visual Design", "Week 5: Practice"]
  },
  {
    id: "customer-experience",
    title: "Customer Experience Management",
    description: "Design and deliver exceptional customer journeys",
    icon: Star,
    difficulty: "Intermediate",
    duration: "8 weeks",
    startingSalary: "$68,000+",
    demand: "High",
    category: "Business",
    lessons: ["Customer Journey Mapping", "Service Design", "Feedback Systems", "CX Metrics"],
    courseOutline: ["Week 1-2: CX Fundamentals", "Week 3-4: Journey Design", "Week 5-6: Implementation", "Week 7-8: Optimization"]
  },
  {
    id: "technical-support",
    title: "Technical Support & Troubleshooting",
    description: "Provide expert technical assistance and problem resolution",
    icon: Headphones,
    difficulty: "Beginner",
    duration: "6 weeks",
    startingSalary: "$45,000+",
    demand: "High",
    category: "Technical",
    lessons: ["Help Desk Fundamentals", "Troubleshooting Methodology", "Customer Service", "Technical Documentation"],
    courseOutline: ["Week 1-2: Support Basics", "Week 3-4: Technical Skills", "Week 5-6: Advanced Support"]
  },
  {
    id: "conflict-resolution",
    title: "Conflict Resolution & Mediation",
    description: "Navigate workplace disputes and foster collaborative environments",
    icon: Users,
    difficulty: "Intermediate",
    duration: "5 weeks",
    startingSalary: "$62,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Conflict Analysis", "Mediation Techniques", "Negotiation Skills", "Team Dynamics"],
    courseOutline: ["Week 1: Understanding Conflict", "Week 2-3: Resolution Techniques", "Week 4-5: Practice & Implementation"]
  },
  {
    id: "solution-selling",
    title: "Solution-Based Selling",
    description: "Master consultative sales approaches focused on customer problems",
    icon: Target,
    difficulty: "Intermediate",
    duration: "7 weeks",
    startingSalary: "$65,000+",
    demand: "High",
    category: "Business",
    lessons: ["Consultative Selling", "Needs Assessment", "Value Proposition", "Sales Technology"],
    courseOutline: ["Week 1-2: Sales Fundamentals", "Week 3-4: Solution Methodology", "Week 5-7: Advanced Techniques"]
  },
  {
    id: "innovative-thinking",
    title: "Innovative Thinking & Creativity",
    description: "Foster creative problem-solving and innovation in competitive markets",
    icon: Lightbulb,
    difficulty: "Beginner",
    duration: "6 weeks",
    startingSalary: "$70,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Creative Thinking Techniques", "Innovation Frameworks", "Ideation Methods", "Implementation Strategies"],
    courseOutline: ["Week 1-2: Creativity Fundamentals", "Week 3-4: Innovation Tools", "Week 5-6: Application"]
  },
  {
    id: "web-development",
    title: "Full-Stack Web Development",
    description: "Build modern web applications from frontend to backend",
    icon: Globe,
    difficulty: "Intermediate",
    duration: "16 weeks",
    startingSalary: "$78,000+",
    demand: "Very High",
    category: "Technical",
    lessons: ["HTML/CSS/JavaScript", "React/Vue.js", "Node.js/Express", "Database Integration", "API Development", "DevOps"],
    courseOutline: ["Week 1-4: Frontend", "Week 5-8: Backend", "Week 9-12: Full-Stack", "Week 13-16: Advanced Topics"]
  },
  {
    id: "information-security",
    title: "Information Security (InfoSec)",
    description: "Protect digital assets and manage security protocols",
    icon: Shield,
    difficulty: "Advanced",
    duration: "14 weeks",
    startingSalary: "$95,000+",
    demand: "Critical",
    category: "Technical",
    lessons: ["Security Frameworks", "Risk Assessment", "Incident Response", "Compliance", "Security Architecture"],
    courseOutline: ["Week 1-3: Security Basics", "Week 4-7: Risk Management", "Week 8-11: Implementation", "Week 12-14: Advanced Security"]
  },
  {
    id: "personal-development",
    title: "Personal Development & Leadership",
    description: "Build leadership skills and emotional intelligence for career advancement",
    icon: Award,
    difficulty: "Beginner",
    duration: "8 weeks",
    startingSalary: "$75,000+",
    demand: "High",
    category: "Soft Skills",
    lessons: ["Self-Awareness", "Leadership Styles", "Team Management", "Performance Coaching"],
    courseOutline: ["Week 1-2: Self-Assessment", "Week 3-4: Leadership Fundamentals", "Week 5-6: Team Dynamics", "Week 7-8: Advanced Leadership"]
  },
  {
    id: "machine-learning",
    title: "Machine Learning Engineering",
    description: "Design and deploy machine learning systems at scale",
    icon: Brain,
    difficulty: "Advanced",
    duration: "18 weeks",
    startingSalary: "$130,000+",
    demand: "Critical",
    category: "Technical",
    lessons: ["ML Algorithms", "Model Training", "Feature Engineering", "MLOps", "Production Deployment"],
    courseOutline: ["Week 1-4: ML Fundamentals", "Week 5-8: Advanced Algorithms", "Week 9-12: Engineering", "Week 13-18: Production Systems"]
  },
  {
    id: "content-creation",
    title: "Digital Content Creation",
    description: "Create engaging content for digital marketing and brand building",
    icon: FileText,
    difficulty: "Beginner",
    duration: "8 weeks",
    startingSalary: "$52,000+",
    demand: "High",
    category: "Business",
    lessons: ["Content Strategy", "Copywriting", "Video Production", "Social Media", "SEO Writing"],
    courseOutline: ["Week 1-2: Strategy", "Week 3-4: Writing", "Week 5-6: Visual Content", "Week 7-8: Distribution"]
  }
];

// Combine all skills
const allSkills = [...skills, ...additionalSkills];

export default function Skills() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [difficultyFilter, setDifficultyFilter] = useState("All");
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(null);

  const filteredSkills = allSkills.filter(skill => {
    const matchesSearch = skill.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         skill.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "All" || skill.category === categoryFilter;
    const matchesDifficulty = difficultyFilter === "All" || skill.difficulty === difficultyFilter;

    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case "Critical": return "bg-red-100 text-red-800 border-red-200";
      case "Very High": return "bg-orange-100 text-orange-800 border-orange-200";
      case "High": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-blue-100 text-blue-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      case "Advanced": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (selectedSkill) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        {/* Navigation */}
        <nav className="bg-white shadow-lg border-b-4 border-blue-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
              </Link>
              <Button variant="outline" onClick={() => setSelectedSkill(null)}>
                ← Back to Skills
              </Button>
            </div>
          </div>
        </nav>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-start gap-6 mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                <selectedSkill.icon className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{selectedSkill.title}</h1>
                <p className="text-lg text-gray-600 mb-4">{selectedSkill.description}</p>
                <div className="flex flex-wrap gap-3">
                  <Badge className={getDemandColor(selectedSkill.demand)}>
                    {selectedSkill.demand} Demand
                  </Badge>
                  <Badge className={getDifficultyColor(selectedSkill.difficulty)}>
                    {selectedSkill.difficulty}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {selectedSkill.duration}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    {selectedSkill.startingSalary}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    Course Outline
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedSkill.courseOutline.map((phase, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        <span className="text-sm text-gray-700">{phase}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Key Lessons
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {selectedSkill.lessons.map((lesson, index) => (
                      <div key={index} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded">
                        <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                        <span className="text-sm text-gray-700">{lesson}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8 p-6 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl text-white">
              <h3 className="text-xl font-bold mb-2">Ready to Start This Course?</h3>
              <p className="text-blue-100 mb-4">
                Join thousands of students who have accelerated their careers with this high-demand skill.
              </p>
              <div className="flex gap-3">
                <Button size="lg" variant="secondary" asChild>
                  <Link href="/api/login">Enroll Now</Link>
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" asChild>
                  <Link href="/demo">Try Demo First</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-blue-800">StarElite</span>
            </Link>
            <div className="flex items-center space-x-3">
              <Button variant="outline" asChild>
                <Link href="/">← Back to Home</Link>
              </Button>
              <Button asChild>
                <Link href="/api/login">Sign Up Free</Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            The Top 25 High-Demand Skills for 2025
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Job-ready courses designed by industry experts. Walk into six-figure roles immediately upon graduation.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search skills..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              <SelectItem value="Technical">Technical</SelectItem>
              <SelectItem value="Business">Business</SelectItem>
              <SelectItem value="Soft Skills">Soft Skills</SelectItem>
            </SelectContent>
          </Select>
          <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Levels</SelectItem>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSkills.map((skill) => (
            <Card 
              key={skill.id} 
              className="border-2 hover:border-blue-300 hover:shadow-xl transition-all duration-300 cursor-pointer group"
              onClick={() => setSelectedSkill(skill)}
            >
              <CardHeader className="pb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                  <skill.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg">{skill.title}</CardTitle>
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge className={getDemandColor(skill.demand)} variant="outline">
                    {skill.demand}
                  </Badge>
                  <Badge className={getDifficultyColor(skill.difficulty)}>
                    {skill.difficulty}
                  </Badge>
                </div>
                <CardDescription className="text-sm text-gray-600 line-clamp-3">
                  {skill.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-1 text-gray-600">
                      <Clock className="w-3 h-3" />
                      Duration
                    </span>
                    <span className="font-medium">{skill.duration}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-1 text-gray-600">
                      <DollarSign className="w-3 h-3" />
                      Starting Salary
                    </span>
                    <span className="font-medium text-green-600">{skill.startingSalary}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-1 text-gray-600">
                      <BookOpen className="w-3 h-3" />
                      Lessons
                    </span>
                    <span className="font-medium">{skill.lessons.length} modules</span>
                  </div>
                </div>
                <Button className="w-full" variant="outline">
                  View Course Details
                                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredSkills.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No skills found</h3>
            <p className="text-gray-600">Try adjusting your search or filters</p>
          </div>
        )}

        {/* Call to Action */}
        <Card className="mt-12 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Ready to Master These High-Demand Skills?</h3>
            <p className="text-indigo-100 mb-6 max-w-2xl mx-auto">
              Start your journey with our AI-powered learning platform. Get personalized learning paths, 
              real-time progress tracking, and direct pathways to six-figure careers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/api/login">Start Learning Free</Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-indigo-600" asChild>
                <Link href="/demo">Try Interactive Demo</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}