
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  BookOpen, 
  Search, 
  Wand2, 
  CheckCircle, 
  AlertCircle,
  Clock,
  Users,
  Award,
  FileText
} from "lucide-react";

interface CourseRequest {
  topic: string;
  level: string;
  duration: string;
  specialRequirements: string;
}

interface ModuleData {
  title: string;
  description: string;
  content: string;
  estimatedDuration: string;
  order: number;
  quiz: {
    questions: QuestionData[];
  };
}

interface QuestionData {
  question: string;
  type: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

interface CourseStructure {
  title: string;
  description: string;
  duration: string;
  difficulty: string;
  prerequisites: string[];
  learningOutcomes: string[];
  modules: ModuleData[];
  finalExam: {
    questions: QuestionData[];
    passingScore: number;
    timeLimit: number;
  };
}

export default function CourseCreator() {
  const [currentStep, setCurrentStep] = useState(1);
  const [courseRequest, setCourseRequest] = useState<CourseRequest>({
    topic: "",
    level: "",
    duration: "",
    specialRequirements: ""
  });
  const [research, setResearch] = useState("");
  const [courseStructure, setCourseStructure] = useState<CourseStructure | null>(null);
  const [validation, setValidation] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleResearchCourse = async () => {
    setIsLoading(true);
    setProgress(25);
    try {
      const response = await fetch('/api/research-course', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: courseRequest.topic,
          level: courseRequest.level
        })
      });
      const data = await response.json();
      setResearch(data.research);
      setProgress(50);
      setCurrentStep(2);
    } catch (error) {
      console.error('Research failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateStructure = async () => {
    setIsLoading(true);
    setProgress(75);
    try {
      const response = await fetch('/api/generate-course-structure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: courseRequest.topic,
          level: courseRequest.level,
          duration: courseRequest.duration
        })
      });
      const data = await response.json();
      setCourseStructure(data.structure);
      setProgress(100);
      setCurrentStep(3);
    } catch (error) {
      console.error('Structure generation failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleValidateCourse = async () => {
    if (!courseStructure) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/validate-course', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseStructure })
      });
      const data = await response.json();
      setValidation(data.validation);
      setCurrentStep(4);
    } catch (error) {
      console.error('Validation failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateCourse = async () => {
    if (!courseStructure) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/create-course', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseStructure })
      });
      const data = await response.json();
      alert(`Course created successfully! ID: ${data.courseId}`);
      setCurrentStep(5);
    } catch (error) {
      console.error('Course creation failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AI Course Creator</h1>
        <p className="text-muted-foreground">
          Create comprehensive university-level courses with integrated assessments
        </p>
      </div>

      <Progress value={progress} className="mb-6" />

      <Tabs value={currentStep.toString()} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="1">Define Course</TabsTrigger>
          <TabsTrigger value="2">Research</TabsTrigger>
          <TabsTrigger value="3">Structure</TabsTrigger>
          <TabsTrigger value="4">Validate</TabsTrigger>
          <TabsTrigger value="5">Create</TabsTrigger>
        </TabsList>

        <TabsContent value="1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Course Definition
              </CardTitle>
              <CardDescription>
                Define the core parameters for your course
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="topic">Course Topic</Label>
                <Input
                  id="topic"
                  value={courseRequest.topic}
                  onChange={(e) => setCourseRequest(prev => ({ ...prev, topic: e.target.value }))}
                  placeholder="e.g., Introduction to Machine Learning"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="level">Academic Level</Label>
                  <Select value={courseRequest.level} onValueChange={(value) => setCourseRequest(prev => ({ ...prev, level: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="undergraduate">Undergraduate</SelectItem>
                      <SelectItem value="graduate">Graduate</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="duration">Course Duration</Label>
                  <Select value={courseRequest.duration} onValueChange={(value) => setCourseRequest(prev => ({ ...prev, duration: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="4 weeks">4 weeks</SelectItem>
                      <SelectItem value="8 weeks">8 weeks</SelectItem>
                      <SelectItem value="12 weeks">12 weeks</SelectItem>
                      <SelectItem value="16 weeks">16 weeks</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="requirements">Special Requirements</Label>
                <Textarea
                  id="requirements"
                  value={courseRequest.specialRequirements}
                  onChange={(e) => setCourseRequest(prev => ({ ...prev, specialRequirements: e.target.value }))}
                  placeholder="Any specific industry certifications, tools, or outcomes required..."
                />
              </div>
              
              <Button 
                onClick={handleResearchCourse}
                disabled={!courseRequest.topic || !courseRequest.level || !courseRequest.duration || isLoading}
                className="w-full"
              >
                <Search className="mr-2 h-4 w-4" />
                Research Course Topic
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Research Results
              </CardTitle>
              <CardDescription>
                AI analysis of current university coursework and industry standards
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <pre className="whitespace-pre-wrap text-sm">{research}</pre>
              </div>
              
              <Button 
                onClick={handleGenerateStructure}
                disabled={!research || isLoading}
                className="w-full"
              >
                <Wand2 className="mr-2 h-4 w-4" />
                Generate Course Structure
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Course Structure
              </CardTitle>
              <CardDescription>
                Generated course with modules, quizzes, and final exam
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {courseStructure && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold">{courseStructure.title}</h3>
                    <p className="text-muted-foreground mt-2">{courseStructure.description}</p>
                    
                    <div className="flex gap-2 mt-4">
                      <Badge variant="secondary">
                        <Clock className="mr-1 h-3 w-3" />
                        {courseStructure.duration}
                      </Badge>
                      <Badge variant="secondary">
                        {courseStructure.difficulty}
                      </Badge>
                      <Badge variant="secondary">
                        <Users className="mr-1 h-3 w-3" />
                        {courseStructure.modules.length} modules
                      </Badge>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Prerequisites</h4>
                    <div className="flex flex-wrap gap-2">
                      {courseStructure.prerequisites.map((prereq, index) => (
                        <Badge key={index} variant="outline">{prereq}</Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Learning Outcomes</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {courseStructure.learningOutcomes.map((outcome, index) => (
                        <li key={index}>{outcome}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Course Modules</h4>
                    <div className="space-y-3">
                      {courseStructure.modules.map((module, index) => (
                        <Card key={index} className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h5 className="font-medium">Module {module.order}: {module.title}</h5>
                            <Badge variant="outline">{module.estimatedDuration}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{module.description}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <CheckCircle className="h-3 w-3" />
                            {module.quiz.questions.length} quiz questions
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <Alert>
                    <Award className="h-4 w-4" />
                    <AlertDescription>
                      Final Exam: {courseStructure.finalExam.questions.length} questions, 
                      {courseStructure.finalExam.timeLimit} minutes, 
                      {courseStructure.finalExam.passingScore}% passing score
                    </AlertDescription>
                  </Alert>
                </div>
              )}
              
              <Button 
                onClick={handleValidateCourse}
                disabled={!courseStructure || isLoading}
                className="w-full"
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Validate Course Quality
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                Quality Validation
              </CardTitle>
              <CardDescription>
                AI assessment against university standards
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <pre className="whitespace-pre-wrap text-sm">{validation}</pre>
              </div>
              
              <Button 
                onClick={handleCreateCourse}
                disabled={!validation || isLoading}
                className="w-full"
              >
                <Award className="mr-2 h-4 w-4" />
                Create Course
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="5">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Course Created Successfully
              </CardTitle>
              <CardDescription>
                Your course has been created and is ready for students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  Course created with all modules, quizzes, and final exam. 
                  Students can now enroll and begin learning.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
