import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, 
  Target, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  ArrowRight,
  Clock,
  Star,
  GraduationCap,
  BookOpen,
  BarChart3
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";

interface SkillGap {
  skill: string;
  currentScore: number;
  targetScore: number;
  priority: "high" | "medium" | "low";
  recommendations: string[];
}

interface AnalysisResult {
  currentLevel: string;
  targetLevel: string;
  timeToTarget: string;
  skillGaps: SkillGap[];
  nextSteps: string[];
  strengths: string[];
  areasForImprovement: string[];
  overallReadiness: number;
}

export default function SkillGapAnalysis() {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    currentRole: '',
    targetRole: '',
    currentSkills: '',
    experience: '',
    goals: ''
  });
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  const analyzeSkillGaps = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch('/api/ai/skill-gap-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      return response.json();
    },
    onSuccess: (result) => {
      setAnalysisResult(result.analysis);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    analyzeSkillGaps.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 border-red-200";
      case "medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-black text-blue-800 mb-4">
            🎯 AI Skill Gap Analysis
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get precision insights into your skill gaps with StarForce AI. 
            Identify exactly what you need to learn to reach your career goals.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Analysis Form */}
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <Brain className="w-6 h-6" />
                Career Analysis Input
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Role/Position
                  </label>
                  <Input
                    placeholder="e.g., Junior Developer, Marketing Analyst"
                    value={formData.currentRole}
                    onChange={(e) => handleInputChange('currentRole', e.target.value)}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Role/Position
                  </label>
                  <Input
                    placeholder="e.g., Senior Full-Stack Developer, Product Manager"
                    value={formData.targetRole}
                    onChange={(e) => handleInputChange('targetRole', e.target.value)}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Skills (comma-separated)
                  </label>
                  <Textarea
                    placeholder="e.g., JavaScript, React, Node.js, Git, SQL, Project Management"
                    value={formData.currentSkills}
                    onChange={(e) => handleInputChange('currentSkills', e.target.value)}
                    rows={3}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Years of Experience
                  </label>
                  <Input
                    placeholder="e.g., 2-3 years, 5+ years"
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Career Goals & Timeline
                  </label>
                  <Textarea
                    placeholder="Describe your career aspirations and when you'd like to achieve them"
                    value={formData.goals}
                    onChange={(e) => handleInputChange('goals', e.target.value)}
                    rows={3}
                    className="w-full"
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                  disabled={analyzeSkillGaps.isPending}
                >
                  {analyzeSkillGaps.isPending ? (
                    <>
                      <Brain className="mr-2 h-4 w-4 animate-spin" />
                      AI Analyzing...
                    </>
                  ) : (
                    <>
                      <Target className="mr-2 h-4 w-4" />
                      Analyze My Skills
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Analysis Results */}
          <div className="space-y-6">
            {analysisResult ? (
              <>
                {/* Overall Readiness */}
                <Card className="shadow-xl border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-800">
                      <BarChart3 className="w-6 h-6" />
                      Career Readiness Score
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl font-black text-blue-800 mb-2">
                        {analysisResult.overallReadiness}%
                      </div>
                      <Progress value={analysisResult.overallReadiness} className="h-4 mb-4" />
                      <p className="text-gray-600">
                        {analysisResult.overallReadiness >= 80 
                          ? "You're well-prepared for your target role!" 
                          : analysisResult.overallReadiness >= 60 
                          ? "You're on the right track with some gaps to fill."
                          : "Significant development needed - but you can do it!"}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Skill Gaps */}
                <Card className="shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-800">
                      <AlertCircle className="w-6 h-6" />
                      Critical Skill Gaps
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisResult.skillGaps?.map((gap: any, index: number) => (
                        <div key={index} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex justify-between items-center mb-2">
                            <h4 className="font-semibold text-gray-900">{gap.skill}</h4>
                            <Badge 
                              className={getPriorityColor(gap.priority)}
                            >
                              {gap.priority?.toUpperCase()} PRIORITY
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>Current: {gap.currentScore}/10</span>
                            <ArrowRight className="w-4 h-4" />
                            <span>Target: {gap.targetScore}/10</span>
                          </div>
                          <Progress 
                            value={(gap.currentScore / gap.targetScore) * 100} 
                            className="h-2 mt-2" 
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Learning Recommendations */}
                <Card className="shadow-xl border-2 border-green-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-800">
                      <Star className="w-6 h-6" />
                      AI Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisResult.nextSteps?.map((rec: string, index: number) => (
                        <div key={index} className="p-4 bg-green-50 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-6 h-6 bg-green-100 text-green-800 rounded-full flex items-center justify-center text-sm font-semibold mr-3">
                              {index + 1}
                            </div>
                            <span className="text-green-700">{rec}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Action Plan */}
                <Card className="shadow-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 flex items-center">
                      <CheckCircle className="mr-2" />
                      Your Next Steps
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-blue-800 font-bold text-sm mr-3">1</div>
                        <span>Focus on high-priority skill gaps first</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-blue-800 font-bold text-sm mr-3">2</div>
                        <span>Create a personalized learning path</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-blue-800 font-bold text-sm mr-3">3</div>
                        <span>Set weekly learning goals and track progress</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full mt-6 bg-yellow-400 text-blue-800 hover:bg-yellow-300 font-semibold"
                      onClick={() => window.location.href = '/learning-paths'}
                    >
                      Generate My Learning Path
                    </Button>
                  </CardContent>
                </Card>
              </>
            ) : (
              /* Placeholder Content */
              <Card className="shadow-xl">
                <CardContent className="p-12 text-center">
                  <Brain className="w-16 h-16 mx-auto mb-6 text-gray-400" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-4">
                    AI Analysis Ready
                  </h3>
                  <p className="text-gray-500">
                    Fill out the form to get your personalized skill gap analysis powered by StarForce AI.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardContent className="p-6">
              <Target className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="font-bold text-gray-900 mb-2">Precision Analysis</h3>
              <p className="text-sm text-gray-600">
                AI-powered analysis identifies exact skill gaps with industry benchmarks
              </p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <TrendingUp className="w-12 h-12 mx-auto mb-4 text-green-600" />
              <h3 className="font-bold text-gray-900 mb-2">Career Trajectory</h3>
              <p className="text-sm text-gray-600">
                Clear roadmap from where you are to where you want to be
              </p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <BookOpen className="w-12 h-12 mx-auto mb-4 text-purple-600" />
              <h3 className="font-bold text-gray-900 mb-2">Industry Insights</h3>
              <p className="text-sm text-gray-600">
                Recommendations based on real market demands and trends
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}