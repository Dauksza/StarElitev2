import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const API_BASE = "/api";

async function apiCall(endpoint: string, options: RequestInit = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(errorData.error || `API call failed: ${response.statusText}`);
    }

    return response.json();
  } catch (error) {
    console.error(`API call to ${endpoint} failed:`, error);
    throw error;
  }
}

// User hooks
export function useUser() {
  return useQuery({
    queryKey: ["user"],
    queryFn: () => apiCall("/user"),
    retry: false,
  });
}

export function useUpdateProfile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (updates: any) => apiCall("/user/profile", {
      method: "PUT",
      body: JSON.stringify(updates),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user"] });
    },
  });
}

// Learning paths hooks
export function useLearningPaths() {
  return useQuery({
    queryKey: ["learning-paths"],
    queryFn: () => apiCall("/learning-paths"),
  });
}

export function useLearningPath(id: string) {
  return useQuery({
    queryKey: ["learning-path", id],
    queryFn: () => apiCall(`/learning-paths/${id}`),
    enabled: !!id,
  });
}

// Progress hooks
export function useUserProgress() {
  return useQuery({
    queryKey: ["user-progress"],
    queryFn: () => apiCall("/user/progress"),
  });
}

export function useUpdateModuleProgress() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: { moduleId: string; progress: number; completed: boolean }) =>
      apiCall("/user/progress/module", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-progress"] });
    },
  });
}

// Challenges hooks
export function useChallenges() {
  return useQuery({
    queryKey: ["challenges"],
    queryFn: () => apiCall("/challenges"),
  });
}

export function useJoinChallenge() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (challengeId: string) => apiCall(`/challenges/${challengeId}/join`, {
      method: "POST",
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["challenges"] });
    },
  });
}

// Skill assessments hooks
export function useSkillAssessments() {
  return useQuery({
    queryKey: ["user-assessments"],
    queryFn: () => apiCall("/user/assessments"),
  });
}

export function useSaveSkillAssessment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (assessment: any) => apiCall("/skill-assessments", {
      method: "POST",
      body: JSON.stringify(assessment),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-assessments"] });
    },
  });
}

// Community hooks
export function useDiscussions(category?: string) {
  return useQuery({
    queryKey: ["discussions", category],
    queryFn: () => apiCall(`/discussions${category ? `?category=${category}` : ""}`),
  });
}

export function useCreateDiscussion() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (discussion: { title: string; content: string; category: string }) =>
      apiCall("/discussions", {
        method: "POST",
        body: JSON.stringify(discussion),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["discussions"] });
    },
  });
}

// AI-powered features hooks
export function useSkillGapAnalysis() {
  return useMutation({
    mutationFn: (data: {
      currentRole: string;
      targetRole: string;
      currentSkills: string[];
      experience: string;
    }) => apiCall("/ai/skill-gap-analysis", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  });
}

export function useGenerateLearningPath() {
  return useMutation({
    mutationFn: (data: {
      goals: string;
      currentLevel: string;
      timeCommitment: string;
    }) => apiCall("/ai/generate-learning-path", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  });
}

// Analytics hooks
export function useAnalyticsDashboard() {
  return useQuery({
    queryKey: ["analytics-dashboard"],
    queryFn: () => apiCall("/analytics/dashboard"),
  });
}

// Export the api object that's being imported
export const api = {
  // User endpoints
  getUser: () => apiCall("/user"),
  updateProfile: (updates: any) => apiCall("/user/profile", {
    method: "PUT",
    body: JSON.stringify(updates),
  }),
  
  // Learning paths
  getLearningPaths: () => apiCall("/learning-paths"),
  getLearningPath: (id: string) => apiCall(`/learning-paths/${id}`),
  
  // Progress
  getUserProgress: () => apiCall("/user/progress"),
  updateModuleProgress: (data: { moduleId: string; progress: number; completed: boolean }) =>
    apiCall("/user/progress/module", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  
  // Challenges
  getChallenges: () => apiCall("/challenges"),
  joinChallenge: (challengeId: string) => apiCall(`/challenges/${challengeId}/join`, {
    method: "POST",
  }),
  
  // Skill assessments
  getSkillAssessments: () => apiCall("/user/assessments"),
  saveSkillAssessment: (assessment: any) => apiCall("/skill-assessments", {
    method: "POST",
    body: JSON.stringify(assessment),
  }),
  
  // Community
  getDiscussions: (category?: string) => apiCall(`/discussions${category ? `?category=${category}` : ""}`),
  createDiscussion: (discussion: { title: string; content: string; category: string }) =>
    apiCall("/discussions", {
      method: "POST",
      body: JSON.stringify(discussion),
    }),
  
  // AI features
  skillGapAnalysis: (data: {
    currentRole: string;
    targetRole: string;
    currentSkills: string[];
    experience: string;
  }) => apiCall("/ai/skill-gap-analysis", {
    method: "POST",
    body: JSON.stringify(data),
  }),
  
  generateLearningPath: (data: {
    goals: string;
    currentLevel: string;
    timeCommitment: string;
  }) => apiCall("/ai/generate-learning-path", {
    method: "POST",
    body: JSON.stringify(data),
  }),
  
  // Analytics
  getAnalyticsDashboard: () => apiCall("/analytics/dashboard"),
};