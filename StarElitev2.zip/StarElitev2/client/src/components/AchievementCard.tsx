import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Award, Zap } from "lucide-react";

interface Achievement {
  id: string;
  name: string;
  description: string;
  iconUrl?: string;
  category?: string;
  points?: number;
  rarity?: string;
  earnedAt?: string;
}

interface AchievementCardProps {
  achievement: Achievement;
  isEarned?: boolean;
}

export function AchievementCard({ achievement, isEarned = true }: AchievementCardProps) {
  const getRarityColor = (rarity: string = "common") => {
    switch (rarity) {
      case "legendary":
        return "from-galaxy-gold to-yellow-400";
      case "epic":
        return "from-purple-500 to-purple-600";
      case "rare":
        return "from-blue-500 to-blue-600";
      default:
        return "from-gray-500 to-gray-600";
    }
  };

  const getIcon = (category: string = "") => {
    switch (category.toLowerCase()) {
      case "learning":
        return <Star className="w-6 h-6 text-white" />;
      case "challenge":
        return <Trophy className="w-6 h-6 text-white" />;
      case "streak":
        return <Zap className="w-6 h-6 text-white" />;
      default:
        return <Award className="w-6 h-6 text-white" />;
    }
  };

  return (
    <div className={`flex items-center space-x-3 p-3 rounded-lg ${
      isEarned 
        ? `bg-gradient-to-r ${getRarityColor(achievement.rarity)}` 
        : "bg-gray-50 border border-gray-200"
    }`}>
      <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
        isEarned 
          ? "bg-starfleet-blue" 
          : "bg-gray-300"
      }`}>
        {achievement.iconUrl ? (
          <img 
            src={achievement.iconUrl} 
            alt={achievement.name}
            className="w-6 h-6"
          />
        ) : (
          getIcon(achievement.category)
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className={`font-semibold text-sm ${
          isEarned ? "text-starfleet-blue" : "text-gray-900"
        }`}>
          {achievement.name}
        </h3>
        <p className={`text-xs mb-1 ${
          isEarned ? "text-starfleet-blue opacity-80" : "text-gray-600"
        }`}>
          {achievement.description}
        </p>
        <div className="flex items-center justify-between">
          {isEarned && achievement.earnedAt && (
            <span className={`text-xs font-medium ${
              isEarned ? "text-starfleet-blue" : "text-gray-500"
            }`}>
              {new Date(achievement.earnedAt).toLocaleDateString()}
            </span>
          )}
          {achievement.points && (
            <Badge variant="secondary" className="text-xs">
              {achievement.points} XP
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
