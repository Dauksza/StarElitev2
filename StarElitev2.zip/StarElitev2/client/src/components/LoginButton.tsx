
import { Button } from "@/components/ui/button";

export function LoginButton() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <Button onClick={handleLogin} className="bg-blue-600 hover:bg-blue-700">
      Login with Replit
    </Button>
  );
}
