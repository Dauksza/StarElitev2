
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { 
  Brain, 
  Clock, 
  Trophy, 
  CheckCircle, 
  AlertCircle,
  Target,
  BookOpen,
  Star,
  TrendingUp
} from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

interface SkillAssessmentProps {
  onComplete?: (score: number, results: any) => void;
}

// Course data based on the 25 high-demand skills
const courses = [
  { id: 'data-science', name: 'Data Science & AI', difficulty: 'Advanced', duration: '16 weeks' },
  { id: 'cybersecurity', name: 'Cybersecurity', difficulty: 'Intermediate', duration: '12 weeks' },
  { id: 'cloud-computing', name: 'Cloud Computing', difficulty: 'Intermediate', duration: '10 weeks' },
  { id: 'software-development', name: 'Software Development', difficulty: 'Beginner', duration: '14 weeks' },
  { id: 'digital-marketing', name: 'Digital Marketing & SEO', difficulty: 'Beginner', duration: '10 weeks' },
  { id: 'project-management', name: 'Project Management', difficulty: 'Beginner', duration: '8 weeks' },
  { id: 'ux-ui-design', name: 'UX/UI Design', difficulty: 'Intermediate', duration: '12 weeks' },
  { id: 'business-intelligence', name: 'Business Intelligence', difficulty: 'Intermediate', duration: '10 weeks' },
  { id: 'mobile-development', name: 'Mobile App Development', difficulty: 'Intermediate', duration: '14 weeks' },
  { id: 'automation', name: 'Automation & Process Optimization', difficulty: 'Intermediate', duration: '8 weeks' }
];

function SkillAssessment({ onComplete }: SkillAssessmentProps) {
  const [step, setStep] = useState<'course-selection' | 'experience' | 'assessment' | 'results'>('course-selection');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('');
  const [priorExperience, setPriorExperience] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);

  // Generate questions based on course and experience level
  const generateQuestions = (courseId: string, experience: string): Question[] => {
    const questionSets: Record<string, Question[]> = {
      'data-science': [
        {
          id: 1,
          question: "What is the primary purpose of exploratory data analysis (EDA)?",
          options: [
            "To clean the data",
            "To understand data patterns and relationships",
            "To build machine learning models",
            "To visualize the final results"
          ],
          correct: 1,
          explanation: "EDA helps understand data structure, patterns, and relationships before modeling.",
          difficulty: 'easy'
        },
        {
          id: 2,
          question: "Which algorithm is best suited for classification problems with non-linear decision boundaries?",
          options: [
            "Linear Regression",
            "Logistic Regression", 
            "Random Forest",
            "K-means Clustering"
          ],
          correct: 2,
          explanation: "Random Forest can handle non-linear relationships and complex decision boundaries.",
          difficulty: 'medium'
        },
        {
          id: 3,
          question: "What is overfitting in machine learning?",
          options: [
            "When a model performs poorly on training data",
            "When a model memorizes training data but fails to generalize",
            "When a model has too few parameters",
            "When training takes too long"
          ],
          correct: 1,
          explanation: "Overfitting occurs when a model learns training data too well, including noise.",
          difficulty: 'medium'
        },
        {
          id: 4,
          question: "Which evaluation metric is most appropriate for imbalanced classification datasets?",
          options: [
            "Accuracy",
            "F1-Score",
            "Mean Squared Error",
            "R-squared"
          ],
          correct: 1,
          explanation: "F1-Score balances precision and recall, making it ideal for imbalanced datasets.",
          difficulty: 'hard'
        },
        {
          id: 5,
          question: "What is the purpose of cross-validation?",
          options: [
            "To increase model accuracy",
            "To reduce training time",
            "To assess model performance and generalization",
            "To clean the data"
          ],
          correct: 2,
          explanation: "Cross-validation helps evaluate how well a model generalizes to unseen data.",
          difficulty: 'medium'
        }
      ],
      'cybersecurity': [
        {
          id: 1,
          question: "What is the principle of least privilege?",
          options: [
            "Give users maximum access for convenience",
            "Grant users only the minimum access necessary for their role",
            "Restrict all access by default",
            "Allow access based on seniority"
          ],
          correct: 1,
          explanation: "Least privilege minimizes security risks by limiting access to what's necessary.",
          difficulty: 'easy'
        },
        {
          id: 2,
          question: "Which type of attack involves tricking users into revealing sensitive information?",
          options: [
            "DDoS Attack",
            "SQL Injection",
            "Social Engineering",
            "Buffer Overflow"
          ],
          correct: 2,
          explanation: "Social engineering manipulates people to divulge confidential information.",
          difficulty: 'easy'
        },
        {
          id: 3,
          question: "What is the primary purpose of a firewall?",
          options: [
            "To encrypt data",
            "To control network traffic based on security rules",
            "To detect malware",
            "To backup data"
          ],
          correct: 1,
          explanation: "Firewalls monitor and control incoming and outgoing network traffic.",
          difficulty: 'medium'
        },
        {
          id: 4,
          question: "Which encryption standard is currently recommended for securing sensitive data?",
          options: [
            "DES",
            "3DES",
            "AES-256",
            "MD5"
          ],
          correct: 2,
          explanation: "AES-256 is the current gold standard for symmetric encryption.",
          difficulty: 'medium'
        },
        {
          id: 5,
          question: "What is a zero-day vulnerability?",
          options: [
            "A vulnerability that was discovered today",
            "A vulnerability with no known exploits",
            "A previously unknown vulnerability with no available patch",
            "A vulnerability that affects zero systems"
          ],
          correct: 2,
          explanation: "Zero-day vulnerabilities are unknown to vendors and have no patches available.",
          difficulty: 'hard'
        }
      ],
      'cloud-computing': [
        {
          id: 1,
          question: "What is the main advantage of cloud computing?",
          options: [
            "Lower initial costs and scalability",
            "Faster internet speeds",
            "Better graphics performance",
            "Increased storage capacity only"
          ],
          correct: 0,
          explanation: "Cloud computing offers cost efficiency and easy scalability.",
          difficulty: 'easy'
        },
        {
          id: 2,
          question: "Which cloud service model provides the most control over the underlying infrastructure?",
          options: [
            "SaaS (Software as a Service)",
            "PaaS (Platform as a Service)",
            "IaaS (Infrastructure as a Service)",
            "FaaS (Function as a Service)"
          ],
          correct: 2,
          explanation: "IaaS provides virtual machines and infrastructure components you can control.",
          difficulty: 'medium'
        },
        {
          id: 3,
          question: "What is the purpose of load balancing in cloud architecture?",
          options: [
            "To increase storage capacity",
            "To distribute incoming requests across multiple servers",
            "To encrypt data transmission",
            "To backup data automatically"
          ],
          correct: 1,
          explanation: "Load balancing distributes traffic to prevent server overload and ensure availability.",
          difficulty: 'medium'
        },
        {
          id: 4,
          question: "Which AWS service is primarily used for object storage?",
          options: [
            "EC2",
            "RDS",
            "S3",
            "Lambda"
          ],
          correct: 2,
          explanation: "Amazon S3 (Simple Storage Service) is designed for object storage.",
          difficulty: 'easy'
        },
        {
          id: 5,
          question: "What is the main benefit of containerization with Docker?",
          options: [
            "Faster network speeds",
            "Application portability and consistency across environments",
            "Increased storage capacity",
            "Better user interface design"
          ],
          correct: 1,
          explanation: "Containers ensure applications run consistently across different environments.",
          difficulty: 'medium'
        }
      ]
    };

    const baseQuestions = questionSets[courseId] || questionSets['data-science'];
    
    // Adjust questions based on experience level
    if (experience === 'beginner') {
      return baseQuestions.filter(q => q.difficulty === 'easy').slice(0, 10);
    } else if (experience === 'intermediate') {
      return baseQuestions.filter(q => q.difficulty !== 'hard').slice(0, 15);
    } else {
      return baseQuestions.slice(0, 20);
    }
  };

  const handleCourseSelect = (courseId: string) => {
    setSelectedCourse(courseId);
    setStep('experience');
  };

  const handleExperienceSubmit = () => {
    setLoading(true);
    const generatedQuestions = generateQuestions(selectedCourse, experienceLevel);
    setQuestions(generatedQuestions);
    setLoading(false);
    setStep('assessment');
  };

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      completeAssessment();
    }
  };

  const completeAssessment = () => {
    let correctAnswers = 0;
    const questionResults = questions.map((question, index) => {
      const isCorrect = answers[index] === question.correct;
      if (isCorrect) correctAnswers++;
      return {
        question: question.question,
        userAnswer: question.options[answers[index]],
        correctAnswer: question.options[question.correct],
        isCorrect,
        explanation: question.explanation
      };
    });

    const finalScore = Math.round((correctAnswers / questions.length) * 100);
    const selectedCourseInfo = courses.find(c => c.id === selectedCourse);
    
    const analysisResults = {
      score: finalScore,
      course: selectedCourseInfo?.name || 'Unknown Course',
      experienceLevel,
      priorExperience,
      totalQuestions: questions.length,
      correctAnswers,
      questionResults,
      analysis: generateAnalysis(finalScore, experienceLevel, selectedCourse),
      recommendations: generateRecommendations(finalScore, experienceLevel, selectedCourse)
    };

    setResults(analysisResults);
    setStep('results');
    
    if (onComplete) {
      onComplete(finalScore, analysisResults);
    }
  };

  const generateAnalysis = (score: number, experience: string, course: string) => {
    if (score >= 90) {
      return `Excellent! You demonstrate strong expertise in ${course}. Your ${experience} experience level is well-validated by your performance.`;
    } else if (score >= 80) {
      return `Great work! You have solid knowledge in ${course}. Your understanding aligns well with your stated ${experience} experience level.`;
    } else if (score >= 70) {
      return `Good foundation! You understand key concepts in ${course}, though there are areas for improvement. This is typical for your ${experience} level.`;
    } else if (score >= 60) {
      return `You have basic knowledge in ${course}, but significant gaps remain. Consider starting with foundational courses before advancing.`;
    } else {
      return `Your current knowledge in ${course} indicates you would benefit from starting with beginner-level fundamentals.`;
    }
  };

  const generateRecommendations = (score: number, experience: string, course: string) => {
    const selectedCourseInfo = courses.find(c => c.id === course);
    
    if (score >= 80) {
      return [
        `You're ready for our ${selectedCourseInfo?.name} advanced track`,
        'Consider specialization modules in your areas of interest',
        'Explore related advanced courses to broaden your expertise'
      ];
    } else if (score >= 60) {
      return [
        `Start with our ${selectedCourseInfo?.name} intermediate track`,
        'Focus on strengthening fundamental concepts first',
        'Take advantage of our AI tutoring for personalized help'
      ];
    } else {
      return [
        `Begin with our ${selectedCourseInfo?.name} foundations course`,
        'Complete prerequisite modules before advancing',
        'Utilize our beginner-friendly resources and community support'
      ];
    }
  };

  const resetAssessment = () => {
    setStep('course-selection');
    setSelectedCourse('');
    setExperienceLevel('');
    setPriorExperience('');
    setQuestions([]);
    setCurrentQuestion(0);
    setAnswers([]);
    setResults(null);
  };

  // Course Selection Step
  if (step === 'course-selection') {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mb-4 mx-auto">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl">AI Skill Assessment Wizard</CardTitle>
          <CardDescription className="text-lg">
            Choose a course to assess your current skill level and get personalized recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {courses.map((course) => (
              <Card 
                key={course.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-300 border-2 hover:border-blue-300"
                onClick={() => handleCourseSelect(course.id)}
              >
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{course.name}</h3>
                  <div className="flex justify-between items-center">
                    <Badge variant="outline">{course.difficulty}</Badge>
                    <span className="text-sm text-gray-600 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {course.duration}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Experience Level Step
  if (step === 'experience') {
    const selectedCourseInfo = courses.find(c => c.id === selectedCourse);
    
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-xl">Tell Us About Your Experience</CardTitle>
          <CardDescription>
            Assessment for: {selectedCourseInfo?.name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-base font-medium mb-3 block">What's your experience level with {selectedCourseInfo?.name}?</Label>
            <Select value={experienceLevel} onValueChange={setExperienceLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Select your experience level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner - New to this field</SelectItem>
                <SelectItem value="intermediate">Intermediate - Some experience/education</SelectItem>
                <SelectItem value="advanced">Advanced - Professional experience</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-base font-medium mb-3 block">Do you have related experience in similar fields?</Label>
            <Select value={priorExperience} onValueChange={setPriorExperience}>
              <SelectTrigger>
                <SelectValue placeholder="Select closest match" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No related experience</SelectItem>
                <SelectItem value="academic">Academic study or coursework</SelectItem>
                <SelectItem value="hobbyist">Personal projects or hobbyist level</SelectItem>
                <SelectItem value="professional">Professional work in related field</SelectItem>
                <SelectItem value="certified">Certified or formally trained</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            onClick={handleExperienceSubmit}
            disabled={!experienceLevel || !priorExperience || loading}
            className="w-full"
          >
            {loading ? 'Generating Assessment...' : 'Start Assessment'}
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Assessment Step
  if (step === 'assessment') {
    const question = questions[currentQuestion];
    const progress = ((currentQuestion + 1) / questions.length) * 100;

    return (
      <Card className="w-full max-w-3xl mx-auto">
        <CardHeader>
          <div className="flex justify-between items-center mb-4">
            <CardTitle>Question {currentQuestion + 1} of {questions.length}</CardTitle>
            <Badge variant="outline">{question?.difficulty}</Badge>
          </div>
          <Progress value={progress} className="w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <h3 className="text-lg font-medium leading-relaxed">{question?.question}</h3>

            <RadioGroup
              value={answers[currentQuestion]?.toString() || ''}
              onValueChange={(value) => handleAnswer(parseInt(value))}
              className="space-y-3"
            >
              {question?.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>

            <Button 
              onClick={nextQuestion}
              disabled={answers[currentQuestion] === undefined}
              className="w-full"
            >
              {currentQuestion === questions.length - 1 ? 'Complete Assessment' : 'Next Question'}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Results Step
  if (step === 'results' && results) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-4 mx-auto">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl">Assessment Complete!</CardTitle>
          <CardDescription className="text-lg">
            Your {results.course} assessment results
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Score Overview */}
          <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
            <div className="text-4xl font-bold text-blue-600 mb-2">
              {results.score}%
            </div>
            <p className="text-gray-600 mb-4">
              You answered {results.correctAnswers} out of {results.totalQuestions} questions correctly
            </p>
            <Progress value={results.score} className="w-full max-w-md mx-auto" />
          </div>

          {/* Analysis */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Analysis
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-700">{results.analysis}</p>
            </div>
          </div>

          {/* Recommendations */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              <Target className="w-5 h-5" />
              Personalized Recommendations
            </h3>
            <div className="space-y-2">
              {results.recommendations.map((rec: string, index: number) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-blue-800">{rec}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="flex-1" onClick={() => window.location.href = '/api/login'}>
              Enroll in Recommended Course
            </Button>
            <Button variant="outline" className="flex-1" onClick={resetAssessment}>
              Take Another Assessment
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return null;
}

export default SkillAssessment;
export { SkillAssessment };
