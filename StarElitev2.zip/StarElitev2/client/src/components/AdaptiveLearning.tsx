
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { BookOpen, ChevronRight, Lightbulb, Award, TrendingUp } from 'lucide-react';

interface LearningModule {
  id: string;
  title: string;
  content: string;
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: number;
  skills: string[];
  completed: boolean;
}

interface UserProgress {
  currentModule: number;
  completedModules: string[];
  performanceScore: number;
  adaptationLevel: 'slower' | 'normal' | 'faster';
}

export function AdaptiveLearning() {
  const [modules, setModules] = useState<LearningModule[]>([
    {
      id: '1',
      title: 'Introduction to Data Science',
      content: 'Data science is an interdisciplinary field that uses scientific methods, processes, algorithms, and systems to extract knowledge and insights from structured and unstructured data.',
      difficulty: 'easy',
      estimatedTime: 15,
      skills: ['Data Science Basics', 'Statistics'],
      completed: false
    },
    {
      id: '2',
      title: 'Python for Data Analysis',
      content: 'Learn how to use Python libraries like Pandas, NumPy, and Matplotlib for data manipulation and visualization.',
      difficulty: 'medium',
      estimatedTime: 30,
      skills: ['Python Programming', 'Data Manipulation'],
      completed: false
    },
    {
      id: '3',
      title: 'Machine Learning Fundamentals',
      content: 'Explore the core concepts of machine learning including supervised and unsupervised learning algorithms.',
      difficulty: 'hard',
      estimatedTime: 45,
      skills: ['Machine Learning', 'Algorithms'],
      completed: false
    }
  ]);

  const [userProgress, setUserProgress] = useState<UserProgress>({
    currentModule: 0,
    completedModules: [],
    performanceScore: 0,
    adaptationLevel: 'normal'
  });

  const [isStudying, setIsStudying] = useState(false);
  const [studyTime, setStudyTime] = useState(0);

  useEffect(() => {
    if (isStudying) {
      const timer = setInterval(() => {
        setStudyTime(prev => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isStudying]);

  const adaptContent = (performance: number) => {
    if (performance < 60) {
      return 'slower';
    } else if (performance > 85) {
      return 'faster';
    }
    return 'normal';
  };

  const completeModule = (moduleId: string) => {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return;

    // Simulate performance calculation based on study time
    const expectedTime = module.estimatedTime * 60; // Convert to seconds
    const performanceScore = Math.min(100, Math.max(0, 100 - ((studyTime - expectedTime) / expectedTime) * 20));

    const newProgress = {
      ...userProgress,
      completedModules: [...userProgress.completedModules, moduleId],
      performanceScore: (userProgress.performanceScore + performanceScore) / 2,
      currentModule: userProgress.currentModule + 1
    };

    newProgress.adaptationLevel = adaptContent(newProgress.performanceScore);

    setUserProgress(newProgress);
    setModules(prev => prev.map(m => 
      m.id === moduleId ? { ...m, completed: true } : m
    ));
    setIsStudying(false);
    setStudyTime(0);
  };

  const startStudying = () => {
    setIsStudying(true);
    setStudyTime(0);
  };

  const getAdaptedContent = (module: LearningModule) => {
    const baseContent = module.content;
    
    switch (userProgress.adaptationLevel) {
      case 'slower':
        return `📚 ${baseContent}\n\n💡 Additional Context: This topic builds on previous concepts. Take your time to understand each part before moving forward.`;
      case 'faster':
        return `🚀 ${baseContent}\n\n⚡ Advanced Insight: Consider exploring advanced applications and real-world implementations of these concepts.`;
      default:
        return `📖 ${baseContent}`;
    }
  };

  const getCurrentModule = () => {
    return modules[userProgress.currentModule] || null;
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentModule = getCurrentModule();

  if (!currentModule) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="text-center py-12">
          <Award className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
          <h2 className="text-2xl font-bold mb-2">Congratulations!</h2>
          <p className="text-gray-600 mb-4">You've completed all available modules in this learning path.</p>
          <Badge className="mb-4">Performance Score: {userProgress.performanceScore.toFixed(0)}%</Badge>
          <div className="flex justify-center">
            <Button onClick={() => window.history.pushState({}, '', '/challenges')}>
              Take on Challenges
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <span>Adaptive Learning Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {userProgress.completedModules.length}/{modules.length}
              </div>
              <div className="text-sm text-gray-600">Modules Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {userProgress.performanceScore.toFixed(0)}%
              </div>
              <div className="text-sm text-gray-600">Performance Score</div>
            </div>
            <div className="text-center">
              <Badge variant={
                userProgress.adaptationLevel === 'faster' ? 'default' :
                userProgress.adaptationLevel === 'slower' ? 'secondary' : 'outline'
              }>
                {userProgress.adaptationLevel} pace
              </Badge>
              <div className="text-sm text-gray-600 mt-1">Learning Speed</div>
            </div>
          </div>
          <Progress 
            value={(userProgress.completedModules.length / modules.length) * 100} 
            className="h-2"
          />
        </CardContent>
      </Card>

      {/* Current Module */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-6 h-6 text-blue-600" />
              <span>{currentModule.title}</span>
            </div>
            <Badge variant={
              currentModule.difficulty === 'hard' ? 'destructive' :
              currentModule.difficulty === 'medium' ? 'default' : 'secondary'
            }>
              {currentModule.difficulty}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span>📅 Estimated time: {currentModule.estimatedTime} minutes</span>
              <span>🎯 Skills: {currentModule.skills.join(', ')}</span>
            </div>
            
            {isStudying && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Study Time</span>
                  <span className="text-xl font-mono">{formatTime(studyTime)}</span>
                </div>
              </div>
            )}

            <div className="prose max-w-none">
              <p className="whitespace-pre-line">{getAdaptedContent(currentModule)}</p>
            </div>

            {userProgress.adaptationLevel === 'slower' && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <Lightbulb className="w-5 h-5 text-amber-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800">AI Recommendation</h4>
                    <p className="text-sm text-amber-700">
                      Take your time with this module. Consider reviewing prerequisite topics if needed.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-4">
              {!isStudying ? (
                <Button onClick={startStudying} className="w-full">
                  Start Learning
                </Button>
              ) : (
                <Button 
                  onClick={() => completeModule(currentModule.id)}
                  className="w-full"
                >
                  Complete Module
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Module Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Learning Path Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {modules.map((module, index) => (
              <div
                key={module.id}
                className={`flex items-center space-x-3 p-3 rounded-lg border ${
                  module.completed 
                    ? 'bg-green-50 border-green-200' 
                    : index === userProgress.currentModule
                    ? 'bg-blue-50 border-blue-200'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm ${
                  module.completed 
                    ? 'bg-green-500' 
                    : index === userProgress.currentModule
                    ? 'bg-blue-500'
                    : 'bg-gray-400'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="font-medium">{module.title}</div>
                  <div className="text-sm text-gray-600">{module.estimatedTime} min</div>
                </div>
                {module.completed && (
                  <Award className="w-5 h-5 text-green-500" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
