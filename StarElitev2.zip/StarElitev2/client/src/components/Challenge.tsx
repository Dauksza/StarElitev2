
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Users, 
  Clock, 
  Target,
  CheckCircle,
  PlayCircle,
  Eye
} from "lucide-react";

interface ChallengeProps {
  id: string;
  title: string;
  description: string;
  type: 'individual' | 'team';
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  timeLimit: string;
  points: number;
  participants?: number;
  maxParticipants?: number;
  status: 'available' | 'active' | 'completed';
  onJoin: () => void;
  onView: () => void;
}

export function Challenge({
  id,
  title,
  description,
  type,
  difficulty,
  timeLimit,
  points,
  participants = 0,
  maxParticipants = 100,
  status,
  onJoin,
  onView
}: ChallengeProps) {
  
  const getDifficultyColor = () => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'hard':
        return 'bg-orange-100 text-orange-800';
      case 'expert':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'available':
        return <PlayCircle className="w-4 h-4" />;
      case 'active':
        return <Clock className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Target className="w-4 h-4" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'available':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg font-bold text-gray-900 mb-2">
              {title}
            </CardTitle>
            <div className="flex items-center space-x-2 mb-3">
              <Badge className={getDifficultyColor()}>
                {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
              </Badge>
              <Badge variant="outline">
                {type === 'team' ? <Users className="w-3 h-3 mr-1" /> : <Target className="w-3 h-3 mr-1" />}
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Badge>
              <Badge className={getStatusColor()}>
                {getStatusIcon()}
                <span className="ml-1">{status.charAt(0).toUpperCase() + status.slice(1)}</span>
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center text-yellow-600 font-semibold">
              <Trophy className="w-4 h-4 mr-1" />
              {points} XP
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-gray-600 mb-4 text-sm">{description}</p>
        
        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">Duration:</span>
            <span className="font-medium">{timeLimit}</span>
          </div>
          
          {type === 'team' && maxParticipants && (
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-500">Participants:</span>
                <span className="font-medium">{participants}/{maxParticipants}</span>
              </div>
              <Progress value={(participants / maxParticipants) * 100} className="h-2" />
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          {status === 'available' && (
            <Button 
              onClick={onJoin}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              size="sm"
            >
              <PlayCircle className="w-4 h-4 mr-2" />
              Join Challenge
            </Button>
          )}
          
          {status === 'active' && (
            <Button 
              onClick={onView}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
              size="sm"
            >
              <Clock className="w-4 h-4 mr-2" />
              Continue
            </Button>
          )}
          
          {status === 'completed' && (
            <Button 
              onClick={onView}
              variant="outline"
              className="flex-1"
              size="sm"
            >
              <Eye className="w-4 h-4 mr-2" />
              View Results
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
