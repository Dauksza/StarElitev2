
import { Router, Route, Switch } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "./components/ui/tooltip";
import { Toaster } from "./components/ui/toaster";
import { AuthProvider } from "./hooks/useAuth";

import Landing from "./pages/landing";
import Home from "./pages/home";
import Dashboard from "./pages/dashboard";
import LearningPaths from "./pages/learning-paths";
import SkillGapAnalysis from "./pages/skill-gap-analysis";
import Challenges from "./pages/challenges";
import Community from "./pages/community";
import Admin from "./pages/admin";
import NotFound from "./pages/not-found";
import Demo from "./pages/demo";
import Skills from "./pages/skills";
import Onboarding from "./pages/onboarding";
import CourseCreator from "./pages/course-creator";
import ProtectedRoute from "./components/ProtectedRoute";

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Router>
            <Switch>
              <Route path="/" component={Landing} />
              <Route path="/demo" component={Demo} />
              <Route path="/skills" component={Skills} />
              <Route path="/onboarding" component={Onboarding} />
              
              <Route path="/home">
                <ProtectedRoute>
                  <Home />
                </ProtectedRoute>
              </Route>
              
              <Route path="/dashboard">
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              </Route>
              
              <Route path="/learning-paths">
                <ProtectedRoute>
                  <LearningPaths />
                </ProtectedRoute>
              </Route>
              
              <Route path="/skill-gap-analysis">
                <ProtectedRoute>
                  <SkillGapAnalysis />
                </ProtectedRoute>
              </Route>
              
              <Route path="/challenges">
                <ProtectedRoute>
                  <Challenges />
                </ProtectedRoute>
              </Route>
              
              <Route path="/community">
                <ProtectedRoute>
                  <Community />
                </ProtectedRoute>
              </Route>
              
              <Route path="/course-creator">
                <ProtectedRoute>
                  <CourseCreator />
                </ProtectedRoute>
              </Route>
              
              <Route path="/admin">
                <ProtectedRoute requiredRole="admin">
                  <Admin />
                </ProtectedRoute>
              </Route>
              
              <Route component={NotFound} />
            </Switch>
          </Router>
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
