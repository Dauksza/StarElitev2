import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "../lib/queryClient";

export function useAuth() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  return {
    user: data?.user || null,
    isAuthenticated: !!data?.user,
    isAdmin: data?.user?.isAdmin || false,
    isLoading,
    error: error as Error | null,
  };
}

export { useAuth, AuthProvider };