import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  decimal,
  boolean,
  uuid,
  serial,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
import { sql } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  onboardingCompleted: boolean("onboarding_completed").default(false),
  currentLevel: integer("current_level").default(1),
  experiencePoints: integer("experience_points").default(0),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
  lastActivityDate: timestamp("last_activity_date"),
  skillsMastered: integer("skills_mastered").default(0),
  learningHours: decimal("learning_hours", { precision: 10, scale: 2 }).default("0"),
  globalRank: integer("global_rank"),
  totalXp: integer("total_xp").default(0),
  level: integer("level").default(1),
  displayName: varchar("display_name"),
  avatar: varchar("avatar"),
  bio: text("bio"),
  skills: jsonb("skills"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Learning paths table
export const learningPaths = pgTable("learning_paths", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  difficulty: varchar("difficulty", { length: 50 }).notNull(), // beginner, intermediate, advanced
  estimatedHours: integer("estimated_hours"),
  estimatedDuration: varchar("estimated_duration"),
  category: varchar("category", { length: 100 }),
  prerequisites: jsonb("prerequisites").$type<string[]>(),
  tags: jsonb("tags"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Modules within learning paths
export const modules = pgTable("modules", {
  id: uuid("id").defaultRandom().primaryKey(),
  learningPathId: uuid("learning_path_id").references(() => learningPaths.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  content: jsonb("content"), // AI-generated content
  type: varchar("type", { length: 50 }).notNull(), // lesson, quiz, challenge, project
  difficulty: varchar("difficulty", { length: 50 }).notNull(),
  estimatedMinutes: integer("estimated_minutes"),
  order: integer("order").default(0),
  orderIndex: integer("order_index").notNull(),
  prerequisites: jsonb("prerequisites").$type<string[]>(),
  objectives: jsonb("objectives").$type<string[]>(),
  keyPoints: jsonb("key_points").$type<string[]>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User progress on learning paths
export const userLearningPathProgress = pgTable("user_learning_path_progress", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  learningPathId: uuid("learning_path_id").references(() => learningPaths.id).notNull(),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0"), // 0-100
  status: varchar("status", { length: 50 }).default("not_started"), // not_started, in_progress, completed
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  lastAccessedAt: timestamp("last_accessed_at"),
  currentModuleId: uuid("current_module_id").references(() => modules.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User progress on individual modules
export const userModuleProgress = pgTable("user_module_progress", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  moduleId: uuid("module_id").references(() => modules.id).notNull(),
  progress: integer("progress").default(0),
  status: varchar("status", { length: 50 }).default("not_started"), // not_started, in_progress, completed
  score: decimal("score", { precision: 5, scale: 2 }), // 0-100
  timeSpent: integer("time_spent_minutes"),
  attempts: integer("attempts").default(0),
  completed: boolean("completed").default(false),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Achievements and badges
export const achievements = pgTable("achievements", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  icon: varchar("icon"),
  iconUrl: varchar("icon_url"),
  category: varchar("category", { length: 100 }),
  criteria: jsonb("criteria"),
  requirements: jsonb("requirements"), // Conditions for earning the achievement
  points: integer("points").default(0),
  rarity: varchar("rarity", { length: 50 }).default("common"), // common, rare, epic, legendary
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User achievements
export const userAchievements = pgTable("user_achievements", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  achievementId: uuid("achievement_id").references(() => achievements.id).notNull(),
  earnedAt: timestamp("earned_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Challenges
export const challenges = pgTable("challenges", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  difficulty: varchar("difficulty", { length: 50 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // individual, team, community
  category: varchar("category", { length: 100 }),
  requirements: jsonb("requirements"),
  rewards: jsonb("rewards"), // XP, badges, etc.
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  maxParticipants: integer("max_participants"),
  currentParticipants: integer("current_participants").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User challenge participation
export const userChallenges = pgTable("user_challenges", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  challengeId: uuid("challenge_id").references(() => challenges.id).notNull(),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0"),
  status: varchar("status", { length: 50 }).default("active"), // active, completed, abandoned
  score: decimal("score", { precision: 10, scale: 2 }),
  completed: boolean("completed").default(false),
  joinedAt: timestamp("joined_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Skill assessments
export const skillAssessments = pgTable("skill_assessments", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  assessmentType: varchar("assessment_type", { length: 100 }).notNull(), // onboarding, skill_gap, performance
  skillAreas: jsonb("skill_areas").$type<string[]>(),
  results: jsonb("results"), // AI analysis results
  scores: jsonb("scores"),
  recommendations: jsonb("recommendations"), // AI recommendations
  confidence: decimal("confidence", { precision: 3, scale: 2 }), // 0-1
  takenAt: timestamp("taken_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Community discussions
export const discussions = pgTable("discussions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  category: varchar("category", { length: 100 }),
  tags: jsonb("tags").$type<string[]>(),
  likesCount: integer("likes_count").default(0),
  repliesCount: integer("replies_count").default(0),
  viewsCount: integer("views_count").default(0),
  isPinned: boolean("is_pinned").default(false),
  isLocked: boolean("is_locked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Discussion replies
export const discussionReplies = pgTable("discussion_replies", {
  id: uuid("id").defaultRandom().primaryKey(),
  discussionId: uuid("discussion_id").references(() => discussions.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  parentReplyId: uuid("parent_reply_id"),
  likesCount: integer("likes_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
// User progress table
export const userProgress = pgTable("user_progress", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  learningPathId: uuid("learning_path_id").references(() => learningPaths.id),
  moduleId: uuid("module_id").references(() => modules.id),
  completed: boolean("completed").default(false),
  score: integer("score"),
  timeSpent: integer("time_spent"),
  lastAccessed: timestamp("last_accessed").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const quizzes = pgTable("quizzes", {
  id: uuid("id").defaultRandom().primaryKey(),
  moduleId: uuid("module_id").references(() => modules.id),
  title: text("title").notNull(),
  questions: jsonb("questions").notNull(),
  timeLimit: integer("time_limit").default(30),
  passingScore: integer("passing_score").default(70),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const exams = pgTable("exams", {
  id: uuid("id").defaultRandom().primaryKey(),
  learningPathId: uuid("learning_path_id").references(() => learningPaths.id),
  title: text("title").notNull(),
  questions: jsonb("questions").notNull(),
  timeLimit: integer("time_limit").default(120),
  passingScore: integer("passing_score").default(70),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  quizId: uuid("quiz_id").references(() => quizzes.id),
  answers: jsonb("answers").notNull(),
  score: integer("score").notNull(),
  timeSpent: integer("time_spent"),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const examAttempts = pgTable("exam_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  examId: uuid("exam_id").references(() => exams.id),
  answers: jsonb("answers").notNull(),
  score: integer("score").notNull(),
  timeSpent: integer("time_spent"),
  passed: boolean("passed").default(false),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  learningPathProgress: many(userLearningPathProgress),
  moduleProgress: many(userModuleProgress),
  achievements: many(userAchievements),
  challenges: many(userChallenges),
  assessments: many(skillAssessments),
  discussions: many(discussions),
  replies: many(discussionReplies),
}));

export const learningPathsRelations = relations(learningPaths, ({ many }) => ({
  modules: many(modules),
  userProgress: many(userLearningPathProgress),
}));

export const modulesRelations = relations(modules, ({ one, many }) => ({
  learningPath: one(learningPaths, {
    fields: [modules.learningPathId],
    references: [learningPaths.id],
  }),
  userProgress: many(userModuleProgress),
}));

export const discussionsRelations = relations(discussions, ({ one, many }) => ({
  user: one(users, {
    fields: [discussions.userId],
    references: [users.id],
  }),
  replies: many(discussionReplies),
}));

export const discussionRepliesRelations = relations(discussionReplies, ({ one }) => ({
  discussion: one(discussions, {
    fields: [discussionReplies.discussionId],
    references: [discussions.id],
  }),
  user: one(users, {
    fields: [discussionReplies.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertModuleSchema = createInsertSchema(modules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscussionSchema = createInsertSchema(discussions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChallengeSchema = createInsertSchema(challenges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type LearningPath = typeof learningPaths.$inferSelect;
export type Module = typeof modules.$inferSelect;
export type UserLearningPathProgress = typeof userLearningPathProgress.$inferSelect;
export type UserModuleProgress = typeof userModuleProgress.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type Challenge = typeof challenges.$inferSelect;
export type UserChallenge = typeof userChallenges.$inferSelect;
export type SkillAssessment = typeof skillAssessments.$inferSelect;
export type Discussion = typeof discussions.$inferSelect;
export type DiscussionReply = typeof discussionReplies.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;
export type InsertModule = z.infer<typeof insertModuleSchema>;
export type InsertDiscussion = z.infer<typeof insertDiscussionSchema>;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;