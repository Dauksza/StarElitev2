
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card.tsx';
import { Button } from './ui/button.tsx';
import { Badge } from './ui/badge.tsx';
import { Progress } from './ui/progress.tsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.tsx';
import { 
  Play, 
  BookOpen, 
  Video, 
  FileText, 
  Award, 
  Clock, 
  Star,
  CheckCircle,
  Lock,
  Target,
  TrendingUp
} from 'lucide-react';

interface Module {
  id: string;
  title: string;
  description: string;
  type: 'video' | 'reading' | 'interactive' | 'quiz';
  duration: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  completed: boolean;
  locked: boolean;
  progress: number;
  points: number;
}

interface LearningPath {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  totalModules: number;
  completedModules: number;
  estimatedHours: number;
  progress: number;
  modules: Module[];
  skills: string[];
  certification: boolean;
}

const learningPaths: LearningPath[] = [
  {
    id: 'data-science-fundamentals',
    title: 'Data Science Fundamentals',
    description: 'Master the essential skills for data science including Python, statistics, and machine learning basics.',
    category: 'Data Science',
    difficulty: 'Beginner',
    totalModules: 12,
    completedModules: 3,
    estimatedHours: 40,
    progress: 25,
    certification: true,
    skills: ['Python', 'Statistics', 'Data Visualization', 'Machine Learning'],
    modules: [
      {
        id: 'intro-python',
        title: 'Introduction to Python for Data Science',
        description: 'Learn Python basics and essential libraries like NumPy and Pandas',
        type: 'video',
        duration: 120,
        difficulty: 'beginner',
        completed: true,
        locked: false,
        progress: 100,
        points: 100
      },
      {
        id: 'data-manipulation',
        title: 'Data Manipulation with Pandas',
        description: 'Master data cleaning, transformation, and analysis techniques',
        type: 'interactive',
        duration: 90,
        difficulty: 'beginner',
        completed: true,
        locked: false,
        progress: 100,
        points: 150
      },
      {
        id: 'data-visualization',
        title: 'Data Visualization with Matplotlib & Seaborn',
        description: 'Create compelling visualizations to communicate insights',
        type: 'video',
        duration: 75,
        difficulty: 'intermediate',
        completed: true,
        locked: false,
        progress: 100,
        points: 120
      },
      {
        id: 'statistics-basics',
        title: 'Statistics for Data Science',
        description: 'Understand descriptive and inferential statistics',
        type: 'reading',
        duration: 60,
        difficulty: 'intermediate',
        completed: false,
        locked: false,
        progress: 30,
        points: 100
      },
      {
        id: 'ml-intro',
        title: 'Introduction to Machine Learning',
        description: 'Learn the fundamentals of supervised and unsupervised learning',
        type: 'video',
        duration: 100,
        difficulty: 'intermediate',
        completed: false,
        locked: false,
        progress: 0,
        points: 200
      },
      {
        id: 'ml-algorithms',
        title: 'Common Machine Learning Algorithms',
        description: 'Implement and understand popular ML algorithms',
        type: 'interactive',
        duration: 150,
        difficulty: 'advanced',
        completed: false,
        locked: true,
        progress: 0,
        points: 250
      }
    ]
  },
  {
    id: 'fullstack-web-dev',
    title: 'Full-Stack Web Development',
    description: 'Build complete web applications using modern technologies like React, Node.js, and databases.',
    category: 'Web Development',
    difficulty: 'Intermediate',
    totalModules: 15,
    completedModules: 0,
    estimatedHours: 60,
    progress: 0,
    certification: true,
    skills: ['React', 'Node.js', 'JavaScript', 'Databases', 'APIs'],
    modules: [
      {
        id: 'html-css-fundamentals',
        title: 'HTML & CSS Fundamentals',
        description: 'Master the building blocks of web development',
        type: 'video',
        duration: 90,
        difficulty: 'beginner',
        completed: false,
        locked: false,
        progress: 0,
        points: 100
      },
      {
        id: 'javascript-essentials',
        title: 'JavaScript Essentials',
        description: 'Learn modern JavaScript ES6+ features and best practices',
        type: 'interactive',
        duration: 120,
        difficulty: 'beginner',
        completed: false,
        locked: false,
        progress: 0,
        points: 150
      }
    ]
  }
];

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'video': return <Video className="w-4 h-4" />;
    case 'reading': return <BookOpen className="w-4 h-4" />;
    case 'interactive': return <Target className="w-4 h-4" />;
    case 'quiz': return <FileText className="w-4 h-4" />;
    default: return <BookOpen className="w-4 h-4" />;
  }
};

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'beginner': return 'bg-green-100 text-green-800';
    case 'intermediate': return 'bg-yellow-100 text-yellow-800';
    case 'advanced': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

export const LearningModules: React.FC = () => {
  const [selectedPath, setSelectedPath] = useState<LearningPath>(learningPaths[0]);
  const [activeModule, setActiveModule] = useState<Module | null>(null);

  const startModule = (module: Module) => {
    if (!module.locked) {
      setActiveModule(module);
      // Here you would typically navigate to the module content
      console.log('Starting module:', module.title);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Learning Paths</h1>
          <p className="text-muted-foreground">Choose your learning journey and master new skills</p>
        </div>
        <Badge variant="secondary" className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4" />
          {selectedPath.completedModules}/{selectedPath.totalModules} Completed
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="modules">Modules</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {learningPaths.map((path) => (
              <Card 
                key={path.id} 
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedPath.id === path.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedPath(path)}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{path.title}</CardTitle>
                    {path.certification && (
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Award className="w-3 h-3" />
                        Certified
                      </Badge>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline">{path.category}</Badge>
                    <Badge className={getDifficultyColor(path.difficulty.toLowerCase())}>
                      {path.difficulty}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{path.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{path.progress}%</span>
                    </div>
                    <Progress value={path.progress} className="h-2" />
                  </div>

                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {path.estimatedHours}h
                    </span>
                    <span>{path.totalModules} modules</span>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Skills you'll learn:</p>
                    <div className="flex flex-wrap gap-1">
                      {path.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="modules" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                {selectedPath.title} - Modules
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedPath.modules.map((module, index) => (
                <Card 
                  key={module.id} 
                  className={`transition-all ${
                    module.locked ? 'opacity-60' : 'hover:shadow-md cursor-pointer'
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="flex items-center gap-2">
                          {module.completed ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : module.locked ? (
                            <Lock className="w-5 h-5 text-gray-400" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
                          )}
                          <span className="font-medium text-sm text-gray-500">
                            {(index + 1).toString().padStart(2, '0')}
                          </span>
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            {getTypeIcon(module.type)}
                            <h3 className="font-medium">{module.title}</h3>
                            <Badge className={getDifficultyColor(module.difficulty)}>
                              {module.difficulty}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {module.description}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {module.duration} min
                            </span>
                            <span className="flex items-center gap-1">
                              <Star className="w-3 h-3" />
                              {module.points} points
                            </span>
                          </div>
                          {module.progress > 0 && !module.completed && (
                            <div className="mt-2">
                              <Progress value={module.progress} className="h-1" />
                            </div>
                          )}
                        </div>
                      </div>

                      <Button
                        onClick={() => startModule(module)}
                        disabled={module.locked}
                        variant={module.completed ? "outline" : "default"}
                        size="sm"
                      >
                        {module.completed ? (
                          "Review"
                        ) : module.progress > 0 ? (
                          "Continue"
                        ) : (
                          <><Play className="w-4 h-4 mr-1" /> Start</>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Learning Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Modules Completed</span>
                    <span className="font-semibold">
                      {selectedPath.completedModules}/{selectedPath.totalModules}
                    </span>
                  </div>
                  <Progress 
                    value={(selectedPath.completedModules / selectedPath.totalModules) * 100} 
                    className="h-2" 
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Overall Progress</span>
                    <span className="font-semibold">{selectedPath.progress}%</span>
                  </div>
                  <Progress value={selectedPath.progress} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {selectedPath.modules.reduce((acc, module) => acc + (module.completed ? module.points : 0), 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Points Earned</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {Math.round(selectedPath.modules.reduce((acc, module) => acc + (module.completed ? module.duration : 0), 0) / 60)}h
                    </div>
                    <div className="text-sm text-muted-foreground">Time Invested</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Skills Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedPath.skills.map((skill) => (
                  <div key={skill} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">{skill}</span>
                      <span className="text-sm font-medium">
                        {Math.floor(Math.random() * 40 + 60)}%
                      </span>
                    </div>
                    <Progress 
                      value={Math.floor(Math.random() * 40 + 60)} 
                      className="h-2" 
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LearningModules;
