import { getCourses } from '../models/CourseModel';

export const generateOnboardingPlan = async () => {
  const courses = getCourses();
  if (courses.length > 0) {
    const plan = courses.map(c => `Course: ${c.title} - ${c.syllabus}`).join('\n');
    return `Structured Onboarding Plan:\n${plan}`;
  } else {
    return 'No courses found. Please contact admin.';
  }
};

import { callMistralAI } from '../lib/MistralClient';

export const generateSkillGapAnalysis = async (userBackground: string, initialQuizAnswers: string): Promise<string> => {
  const prompt = 'You are an AI Educational Advisor. You will be provided with a user\'s background and initial quiz answers.\n\nBackground:\n' + userBackground + '\n\nInitial Quiz Answers:\n' + initialQuizAnswers + '\n\nYour task:\n- Analyze the user\'s strengths and weaknesses.\n- Identify skill gaps.\n- Recommend the top 3-5 Courses from the following categories:\n\nAI & ML, Data Science, Cloud, Software Dev, Business, Cybersecurity, Career.\n\nFormat your response as:\n\nSkill Gap Analysis:\n[Your analysis here]\n\nRecommended Courses:\n1. [Course Title]\n2. [Course Title]\n3. [Course Title]\n4. [Optional]\n5. [Optional]\n\nBe concise but informative.';

  const response = await callMistralAI(prompt);
  return response;
};