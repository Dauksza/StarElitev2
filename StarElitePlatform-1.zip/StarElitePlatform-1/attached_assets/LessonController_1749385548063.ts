// LessonController.ts

import { Request, Response } from 'express';
import { getLessons, addLesson, getLessonsByCourseId } from '../models/LessonModel';

export const listLessons = (req: Request, res: Response) => {
  res.json(getLessons());
};

export const createLesson = (req: Request, res: Response) => {
  const lesson = req.body;
  addLesson(lesson);
  res.status(201).json({ message: 'Lesson created', lesson });
};

export const listLessonsByCourse = (req: Request, res: Response) => {
  const { courseId } = req.params;
  res.json(getLessonsByCourseId(courseId));
};