// CertificateModel.ts

export interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  issueDate: string;
  certNumber: string; // UUID
  printableUrl?: string; // For generated PDF
}

let certificates: Certificate[] = [];

// CRUD Operations
export const getCertificates = (): Certificate[] => certificates;

export const addCertificate = (cert: Certificate) => {
  certificates.push(cert);
};

export const getCertificatesByUserId = (userId: string): Certificate[] =>
  certificates.filter((c) => c.userId === userId);