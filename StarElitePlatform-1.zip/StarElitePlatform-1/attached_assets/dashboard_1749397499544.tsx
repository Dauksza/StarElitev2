import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import { Badge as UIBadge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import Badge from "@/components/Badge.tsx";
import { Certificate } from "@/components/Certificate.tsx";
import ProgressBar from "@/components/ProgressBar.tsx";
import Streak from "@/components/Streak.tsx";
import {
  BarChart3,
  Brain,
  Trophy,
  Target,
  Zap,
  TrendingUp,
  CheckCircle,
  Clock,
  Users,
  ArrowRight,
  Award,
  Activity,
  BookOpen,
  Star
} from "lucide-react";
import DashboardCards from "@/components/dashboard-cards.tsx";
import ProgressTracking from "@/components/progress-tracking.tsx";
import AiInsights from "@/components/ai-insights.tsx";
import AchievementSystem from "@/components/achievement-system.tsx";
import SkillGapAnalyzer from "@/components/skill-gap-analyzer.tsx";
import AdaptiveLearningModule from "@/components/adaptive-learning-module.tsx";
import CertificationPathway from "@/components/certification-pathway.tsx";
import RealTimeAnalytics from "@/components/real-time-analytics.tsx";
import AdvancedLeaderboard from "@/components/advanced-leaderboard.tsx";
import SocialLearningHub from "@/components/social-learning-hub.tsx";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: user } = useQuery({
    queryKey: ["/api/user/profile"],
  });

  const { data: learningPaths = [] } = useQuery({
    queryKey: ["/api/learning-paths"],
  });

  const { data: weeklyProgress } = useQuery({
    queryKey: ["/api/progress/weekly"],
  });

  const { data: achievements = [] } = useQuery({
    queryKey: ["/api/achievements"],
  });

  const currentPath = learningPaths.find?.(path => path.status === "active");
  const userId = user?.id || 1;

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-black text-primary mb-2">
            Welcome back, {user?.firstName || "Champion"}! 🚀
          </h1>
          <p className="text-xl text-gray-600">
            Ready to dominate today's learning goals? Your AI-powered growth engine is standing by.
          </p>
        </div>

        {/* Quick Stats */}
        <DashboardCards
          userStats={{
            level: user?.level || 1,
            experiencePoints: user?.experiencePoints || 0,
            streakDays: user?.streakDays || 0,
            completedModules: user?.completedModules || 0,
            totalModules: user?.totalModules || 10,
            weeklyGoalProgress: user?.weeklyGoalProgress || 50,
            rank: user?.rank || 1,
            badges: achievements || [],
            recentActivity: user?.recentActivity || []
          }}
        />

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mt-8">
          {/* Left Column - Progress & Path */}
          <div className="lg:col-span-2 space-y-8">
            {/* Current Learning Path */}
            {currentPath && (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-6 w-6 text-primary" />
                    Current Learning Path
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold text-primary">{currentPath.title}</h3>
                        <p className="text-gray-600">{currentPath.description}</p>
                      </div>
                      <UIBadge variant="secondary" className="bg-accent text-primary">
                        {currentPath.difficulty}
                      </UIBadge>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-gray-600">{Math.round(currentPath.progress)}%</span>
                      </div>
                      <Progress value={currentPath.progress} className="h-3" />
                    </div>

                    {/* Module Progress */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-gray-900">Learning Modules</h4>
                      <div className="grid gap-3">
                        {currentPath.modules?.slice(0, 3).map((module, index) => (
                          <div key={module.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center space-x-3">
                              {module.completed ? (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              ) : (
                                <div className="w-5 h-5 rounded-full border-2 border-primary flex items-center justify-center text-xs font-bold text-primary">
                                  {index + 1}
                                </div>
                              )}
                              <div>
                                <div className="font-medium">{module.title}</div>
                                <div className="text-sm text-gray-600">{module.estimatedMinutes} minutes</div>
                              </div>
                            </div>
                            {!module.completed && (
                              <Button size="sm" variant="outline">
                                Continue
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full bg-primary text-white hover:bg-blue-800">
                      Continue Learning Path <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Progress Tracking */}
            <ProgressTracking />

            {/* Recent Activity */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-6 w-6 text-primary" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <div>
                      <div className="font-medium">Completed "Python Basics" quiz</div>
                      <div className="text-sm text-gray-600">Score: 95% • 2 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <Brain className="h-5 w-5 text-primary" />
                    <div>
                      <div className="font-medium">AI generated new practice problems</div>
                      <div className="text-sm text-gray-600">Based on your performance • 4 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                    <Trophy className="h-5 w-5 text-accent" />
                    <div>
                      <div className="font-medium">Earned "Speed Learner" badge</div>
                      <div className="text-sm text-gray-600">Completed 3 modules in one day • Yesterday</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - AI Insights & Achievements */}
          <div className="space-y-8">
            {/* AI Insights */}
            <AiInsights />

            {/* Achievement System */}
            <AchievementSystem achievements={achievements} />

            {/* Quick Actions */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-6 w-6 text-accent" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Target className="mr-2 h-4 w-4" />
                  Take Skill Assessment
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  Join Study Group
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  View Progress Report
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Challenge Friends
                </Button>
              </CardContent>
            </Card>

            {/* Community Leaderboard */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-6 w-6 text-accent" />
                  Weekly Leaderboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-primary font-bold text-sm">1</div>
                      <span className="font-medium">DataMaster</span>
                    </div>
                    <span className="font-bold text-accent">2,450 XP</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-primary font-bold text-sm">2</div>
                      <span className="font-medium">AIExplorer</span>
                    </div>
                    <span className="font-bold">2,120 XP</span>
                  </div>
                  <div className="flex items-center justify-between bg-accent bg-opacity-20 rounded-lg p-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm">3</div>
                      <span className="font-medium">You</span>
                    </div>
                    <span className="font-bold text-primary">1,890 XP</span>
                  </div>
                  <div className="pt-2">
                    <Button variant="outline" size="sm" className="w-full">
                      View Full Leaderboard
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
