import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  Play, 
  Pause, 
  CheckCircle, 
  Clock, 
  Star, 
  Brain,
  Target,
  Lightbulb,
  MessageSquare,
  ArrowRight,
  RefreshCw,
  Zap
} from "lucide-react";
import { AiService } from "@/lib/ai-service";

interface LearningModule {
  id: string;
  title: string;
  description: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedMinutes: number;
  content: {
    type: "lesson" | "quiz" | "challenge" | "practice";
    data: any;
  };
  completed: boolean;
  score?: number;
}

interface AdaptiveLearningModuleProps {
  moduleId: string;
  userId: number;
  userPerformance?: {
    avgScore: number;
    timeSpent: number;
    strugglingAreas: string[];
    strengths: string[];
  };
  onModuleComplete: (moduleId: string, score: number, timeSpent: number) => void;
}

export default function AdaptiveLearningModule({ 
  moduleId, 
  userId, 
  userPerformance,
  onModuleComplete 
}: AdaptiveLearningModuleProps) {
  const [module, setModule] = useState<LearningModule | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isCompleted, setIsCompleted] = useState(false);
  const [activeTab, setActiveTab] = useState("content");

  const generateAdaptiveContent = async () => {
    setIsGenerating(true);
    try {
      const adaptiveContent = await AiService.generateAdaptiveContent({
        userId,
        moduleId,
        userPerformance: userPerformance || {
          avgScore: 75,
          timeSpent: 30,
          strugglingAreas: [],
          strengths: []
        }
      });

      const generatedModule: LearningModule = {
        id: moduleId,
        title: adaptiveContent.title,
        description: adaptiveContent.description,
        difficulty: adaptiveContent.difficulty,
        estimatedMinutes: adaptiveContent.estimatedMinutes,
        content: adaptiveContent.content,
        completed: false
      };

      setModule(generatedModule);
      setStartTime(new Date());
    } catch (error) {
      console.error("Error generating adaptive content:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    generateAdaptiveContent();
  }, [moduleId, userId]);

  const handleAnswerSubmit = async (questionId: string, answer: any) => {
    setUserAnswers(prev => ({ ...prev, [questionId]: answer }));
    
    // Get real-time AI assistance for the current question
    try {
      const assistance = await AiService.getLearningAssistance({
        userId,
        moduleId,
        currentQuestion: questionId,
        userAnswer: answer,
        context: module?.content
      });
      
      setFeedback(assistance.feedback);
    } catch (error) {
      console.error("Error getting learning assistance:", error);
    }
  };

  const completeModule = async () => {
    if (!module || !startTime) return;

    const timeSpent = Math.round((new Date().getTime() - startTime.getTime()) / 1000 / 60);
    const score = calculateScore();
    
    setIsCompleted(true);
    onModuleComplete(moduleId, score, timeSpent);

    // Generate performance insights
    try {
      const insights = await AiService.generatePerformanceInsights({
        moduleId,
        score,
        timeSpent
      });
      setFeedback(insights.specificFeedback.join(" "));
    } catch (error) {
      console.error("Error generating performance insights:", error);
    }
  };

  const calculateScore = () => {
    if (!module || !module.content.data.questions) return 0;
    
    const totalQuestions = module.content.data.questions.length;
    let correctAnswers = 0;
    
    module.content.data.questions.forEach((question: any, index: number) => {
      const userAnswer = userAnswers[`question_${index}`];
      if (userAnswer === question.correctAnswer) {
        correctAnswers++;
      }
    });
    
    return Math.round((correctAnswers / totalQuestions) * 100);
  };

  if (isGenerating) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-primary animate-pulse" />
            <span>Generating Adaptive Content</span>
          </CardTitle>
          <CardDescription>
            AI is creating personalized learning content based on your performance...
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="text-center space-y-4">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Analyzing your learning patterns...
                </p>
                <p className="text-xs text-muted-foreground">
                  Adapting difficulty and content to your skill level
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!module) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Learning Module</CardTitle>
          <CardDescription>Failed to generate content</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={generateAdaptiveContent} variant="outline" className="w-full">
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  const renderQuizContent = () => {
    if (!module.content.data.questions) return null;

    return (
      <div className="space-y-6">
        {module.content.data.questions.map((question: any, index: number) => (
          <Card key={index} className="border-l-4 border-l-primary">
            <CardHeader>
              <CardTitle className="text-lg">
                Question {index + 1} of {module.content.data.questions.length}
              </CardTitle>
              <CardDescription>{question.question}</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={userAnswers[`question_${index}`] || ""}
                onValueChange={(value) => handleAnswerSubmit(`question_${index}`, value)}
              >
                {question.options.map((option: string, optionIndex: number) => (
                  <div key={optionIndex} className="flex items-center space-x-2">
                    <RadioGroupItem 
                      value={option} 
                      id={`q${index}_o${optionIndex}`}
                    />
                    <Label htmlFor={`q${index}_o${optionIndex}`}>{option}</Label>
                  </div>
                ))}
              </RadioGroup>

              {userAnswers[`question_${index}`] && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-start space-x-2">
                    <Lightbulb className="h-4 w-4 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-900">AI Hint</h4>
                      <p className="text-sm text-blue-700">
                        {question.explanation || "Good choice! This demonstrates understanding of the key concept."}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderLessonContent = () => {
    if (!module.content.data.sections) return null;

    return (
      <div className="space-y-6">
        {module.content.data.sections.map((section: any, index: number) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle>{section.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {section.content}
                </p>
              </div>
              
              {section.keyPoints && (
                <div className="mt-4 p-4 bg-accent/10 rounded-lg">
                  <h4 className="font-semibold text-sm mb-2 flex items-center">
                    <Target className="h-4 w-4 mr-1" />
                    Key Points
                  </h4>
                  <ul className="space-y-1">
                    {section.keyPoints.map((point: string, pointIndex: number) => (
                      <li key={pointIndex} className="text-sm flex items-start">
                        <ArrowRight className="h-3 w-3 mr-1 mt-1 text-primary flex-shrink-0" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-primary" />
              <span>{module.title}</span>
              <Badge className="bg-accent text-primary">AI-Adaptive</Badge>
            </CardTitle>
            <CardDescription>{module.description}</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="capitalize">
              {module.difficulty}
            </Badge>
            <Badge variant="outline">
              <Clock className="h-3 w-3 mr-1" />
              {module.estimatedMinutes}m
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="assistance">AI Help</TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="mt-6">
            {module.content.type === "quiz" && renderQuizContent()}
            {module.content.type === "lesson" && renderLessonContent()}
            
            {!isCompleted && (
              <div className="mt-6 flex justify-between">
                <Button variant="outline">
                  <Pause className="h-4 w-4 mr-2" />
                  Save Progress
                </Button>
                <Button onClick={completeModule} className="bg-primary">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Complete Module
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="progress" className="mt-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Module Progress</span>
                  <span>{Object.keys(userAnswers).length}/{module.content.data.questions?.length || 1}</span>
                </div>
                <Progress 
                  value={(Object.keys(userAnswers).length / (module.content.data.questions?.length || 1)) * 100} 
                  className="h-2"
                />
              </div>

              {startTime && (
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Time Spent</span>
                    <span>{Math.round((new Date().getTime() - startTime.getTime()) / 1000 / 60)}m</span>
                  </div>
                </div>
              )}

              {isCompleted && (
                <Card className="bg-green-50 border-green-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <div>
                        <h4 className="font-semibold text-green-900">Module Completed!</h4>
                        <p className="text-sm text-green-700">
                          Final Score: {calculateScore()}%
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="assistance" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>AI Learning Assistant</span>
                </CardTitle>
                <CardDescription>
                  Get personalized help and explanations
                </CardDescription>
              </CardHeader>
              <CardContent>
                {feedback ? (
                  <Alert>
                    <Brain className="h-4 w-4" />
                    <AlertDescription>{feedback}</AlertDescription>
                  </Alert>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Answer questions to receive AI-powered assistance and explanations</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}