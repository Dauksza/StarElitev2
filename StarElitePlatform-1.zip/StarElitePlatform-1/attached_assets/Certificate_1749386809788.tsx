import React from 'react';

interface CertificateProps {
  value?: number;
  label?: string;
}

export default function Certificate({ value = 0, label = '' }: CertificateProps) {
  return (
    <div className="p-4 border rounded shadow mb-4">
      <h2 className="text-xl font-semibold mb-2">Certificate</h2>
      <p className="text-sm mb-2">{label}</p>
      <div className="w-full bg-gray-200 rounded h-4">
        <div
          className="bg-blue-600 h-4 rounded"
          style={{ width: `${Math.min(value, 100)}%` }}
        ></div>
      </div>
    </div>
  );
}
