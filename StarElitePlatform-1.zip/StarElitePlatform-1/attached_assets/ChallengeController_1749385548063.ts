// ChallengeController.ts

import { Request, Response } from 'express';
import { getChallenges, addChallenge, removeChallenge, Challenge } from '../models/ChallengeModel';

export const listChallenges = (req: Request, res: Response) => {
  res.json(getChallenges());
};

export const createChallenge = (req: Request, res: Response) => {
  const challenge: Challenge = req.body;
  addChallenge(challenge);
  res.status(201).json({ message: 'Challenge created', challenge });
};

export const deleteChallenge = (req: Request, res: Response) => {
  const { id } = req.params;
  removeChallenge(id);
  res.json({ message: `Challenge ${id} removed` });
};