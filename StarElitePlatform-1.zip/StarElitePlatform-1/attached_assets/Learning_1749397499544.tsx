import React, { useEffect, useState } from "react";
import axios from "axios";

const userId = "admin-1"; // Simulated for now

export default function LearningPage() {
  const [courses, setCourses] = useState([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [lessons, setLessons] = useState([]);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);

  useEffect(() => {
    const fetchCourses = async () => {
      const res = await axios.get("/api/courses");
      setCourses(res.data);
    };
    fetchCourses();
  }, []);

  const selectCourse = async (courseId: string) => {
    setSelectedCourseId(courseId);
    const res = await axios.get(`/api/lessons/course/${courseId}`);
    setLessons(res.data);
    setCompletedLessons([]);
  };

  const markLessonComplete = async (lessonId: string) => {
    if (!selectedCourseId) return;
    const updatedCompleted = [...completedLessons, lessonId];
    setCompletedLessons(updatedCompleted);

    // Update progress
    const progress = Math.round((updatedCompleted.length / lessons.length) * 100);
    await axios.post(`/api/users/${userId}/progress/${selectedCourseId}`, { progress });
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Learning</h1>

      <div className="mb-4">
        <h2 className="text-xl font-bold">Select a Course:</h2>
        {courses.map((c: any) => (
          <button key={c.id} onClick={() => selectCourse(c.id)} className="block text-blue-500 underline mb-2">
            {c.title}
          </button>
        ))}
      </div>

      {selectedCourseId && (
        <div>
          <h2 className="text-xl font-bold mb-2">Lessons</h2>
          <ul className="list-disc ml-5">
            {lessons.map((l: any) => (
              <li key={l.id}>
                {l.title}{" "}
                {completedLessons.includes(l.id) ? (
                  <span className="text-green-600">(Completed)</span>
                ) : (
                  <button onClick={() => markLessonComplete(l.id)} className="ml-2 text-blue-500 underline">
                    Mark Complete
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}