
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card.tsx';
import { Button } from './ui/button.tsx';
import { Badge } from './ui/badge.tsx';
import { Progress } from './ui/progress.tsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.tsx';
import { RadioGroup, RadioGroupItem } from './ui/radio-group.tsx';
import { Label } from './ui/label.tsx';
import { Textarea } from './ui/textarea.tsx';
import { 
  Brain, 
  Clock, 
  Target, 
  TrendingUp, 
  Award, 
  CheckCircle, 
  AlertCircle,
  Lightbulb,
  BookOpen,
  Zap
} from 'lucide-react';

interface Question {
  id: string;
  type: 'multiple-choice' | 'coding' | 'essay' | 'scenario';
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  question: string;
  options?: string[];
  correctAnswer?: string;
  points: number;
  explanation?: string;
}

interface AssessmentResult {
  score: number;
  totalPoints: number;
  skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  nextSteps: string[];
}

const assessmentQuestions: Question[] = [
  {
    id: 'q1',
    type: 'multiple-choice',
    category: 'Python Fundamentals',
    difficulty: 'beginner',
    question: 'What is the correct way to create a list in Python?',
    options: [
      'list = {1, 2, 3}',
      'list = [1, 2, 3]',
      'list = (1, 2, 3)',
      'list = <1, 2, 3>'
    ],
    correctAnswer: 'list = [1, 2, 3]',
    points: 10,
    explanation: 'Square brackets [] are used to create lists in Python. Curly braces {} create sets or dictionaries, and parentheses () create tuples.'
  },
  {
    id: 'q2',
    type: 'multiple-choice',
    category: 'Data Analysis',
    difficulty: 'intermediate',
    question: 'Which pandas method is used to handle missing values by removing rows with NaN?',
    options: [
      'fillna()',
      'dropna()',
      'isna()',
      'replace()'
    ],
    correctAnswer: 'dropna()',
    points: 15,
    explanation: 'dropna() removes rows or columns with missing values. fillna() fills missing values, isna() detects missing values, and replace() replaces values.'
  },
  {
    id: 'q3',
    type: 'scenario',
    category: 'Problem Solving',
    difficulty: 'advanced',
    question: 'You have a dataset with 1 million rows and need to find the top 10 most frequent values in a column. Describe your approach considering performance.',
    points: 25,
    explanation: 'Efficient approaches include using pandas value_counts(), numpy unique with return_counts, or Counter from collections. For very large datasets, consider chunking or using Dask.'
  }
];

export const AssessmentEngine: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [assessmentStarted, setAssessmentStarted] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(30 * 60); // 30 minutes

  const currentQ = assessmentQuestions[currentQuestion];

  const handleAnswer = (questionId: string, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const nextQuestion = () => {
    if (currentQuestion < assessmentQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      completeAssessment();
    }
  };

  const completeAssessment = () => {
    setShowResults(true);
  };

  const calculateResults = (): AssessmentResult => {
    let score = 0;
    const totalPoints = assessmentQuestions.reduce((sum, q) => sum + q.points, 0);

    assessmentQuestions.forEach(question => {
      if (question.type === 'multiple-choice' && answers[question.id] === question.correctAnswer) {
        score += question.points;
      } else if (question.type === 'scenario' && answers[question.id]) {
        // Mock scoring for scenario questions
        score += question.points * 0.8; // Assume 80% credit
      }
    });

    const percentage = (score / totalPoints) * 100;
    let skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';

    if (percentage >= 90) skillLevel = 'expert';
    else if (percentage >= 75) skillLevel = 'advanced';
    else if (percentage >= 60) skillLevel = 'intermediate';
    else skillLevel = 'beginner';

    return {
      score,
      totalPoints,
      skillLevel,
      strengths: ['Problem-solving', 'Python syntax', 'Logical thinking'],
      weaknesses: ['Advanced pandas operations', 'Performance optimization'],
      recommendations: [
        'Focus on advanced pandas techniques',
        'Practice with larger datasets',
        'Study algorithm complexity'
      ],
      nextSteps: [
        'Complete the Data Analysis Fundamentals course',
        'Practice coding challenges daily',
        'Join study groups or coding communities'
      ]
    };
  };

  const results = showResults ? calculateResults() : null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!assessmentStarted) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">AI-Powered Skill Assessment</CardTitle>
            <p className="text-muted-foreground">
              Discover your current skill level and get personalized learning recommendations
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <Clock className="w-8 h-8 text-primary mx-auto mb-2" />
                <div className="font-semibold">30 Minutes</div>
                <div className="text-sm text-muted-foreground">Assessment Time</div>
              </div>
              <div className="text-center">
                <Target className="w-8 h-8 text-primary mx-auto mb-2" />
                <div className="font-semibold">{assessmentQuestions.length} Questions</div>
                <div className="text-sm text-muted-foreground">Mixed Format</div>
              </div>
              <div className="text-center">
                <Award className="w-8 h-8 text-primary mx-auto mb-2" />
                <div className="font-semibold">Instant Results</div>
                <div className="text-sm text-muted-foreground">With Recommendations</div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
              <h3 className="font-semibold mb-2 flex items-center">
                <Lightbulb className="w-4 h-4 mr-2" />
                What you'll get:
              </h3>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Detailed skill level analysis</li>
                <li>• Personalized learning path recommendations</li>
                <li>• Strengths and improvement areas</li>
                <li>• AI-powered career guidance</li>
              </ul>
            </div>

            <Button 
              onClick={() => setAssessmentStarted(true)}
              className="w-full"
              size="lg"
            >
              Start Assessment
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showResults && results) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Assessment Complete!</CardTitle>
            <p className="text-muted-foreground">
              Here's your detailed skill analysis and recommendations
            </p>
          </CardHeader>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Your Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {Math.round((results.score / results.totalPoints) * 100)}%
                </div>
                <Badge 
                  variant="secondary" 
                  className="text-lg px-4 py-1 capitalize"
                >
                  {results.skillLevel} Level
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Score</span>
                  <span>{results.score}/{results.totalPoints} points</span>
                </div>
                <Progress 
                  value={(results.score / results.totalPoints) * 100} 
                  className="h-3" 
                />
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                  <div className="text-xl font-bold text-green-600">
                    {results.strengths.length}
                  </div>
                  <div className="text-sm text-green-600">Strengths</div>
                </div>
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <div className="text-xl font-bold text-orange-600">
                    {results.weaknesses.length}
                  </div>
                  <div className="text-sm text-orange-600">Areas to Improve</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="w-5 h-5 mr-2" />
                AI Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-green-600 mb-2">Your Strengths</h4>
                <div className="space-y-1">
                  {results.strengths.map((strength, index) => (
                    <div key={index} className="flex items-center text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      {strength}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-orange-600 mb-2">Focus Areas</h4>
                <div className="space-y-1">
                  {results.weaknesses.map((weakness, index) => (
                    <div key={index} className="flex items-center text-sm">
                      <AlertCircle className="w-4 h-4 text-orange-500 mr-2" />
                      {weakness}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recommendations" className="space-y-4">
          <TabsList>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="next-steps">Next Steps</TabsTrigger>
            <TabsTrigger value="detailed">Detailed Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Personalized Learning Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {results.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                      <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">{rec}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="next-steps">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2" />
                  Your Learning Action Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {results.nextSteps.map((step, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">{step}</p>
                      </div>
                      <Button size="sm" variant="outline">
                        Start
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="detailed">
            <Card>
              <CardHeader>
                <CardTitle>Question-by-Question Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {assessmentQuestions.map((question, index) => (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">{question.category}</Badge>
                      <Badge className={
                        answers[question.id] === question.correctAnswer 
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }>
                        {answers[question.id] === question.correctAnswer ? "Correct" : "Incorrect"}
                      </Badge>
                    </div>
                    <h4 className="font-medium mb-2">{question.question}</h4>
                    {question.explanation && (
                      <p className="text-sm text-muted-foreground">{question.explanation}</p>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex gap-4">
          <Button onClick={() => window.location.reload()} variant="outline">
            Retake Assessment
          </Button>
          <Button>
            Start Learning Path
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Skill Assessment</CardTitle>
              <p className="text-sm text-muted-foreground">
                Question {currentQuestion + 1} of {assessmentQuestions.length}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Time remaining</div>
              <div className="font-mono text-lg">{formatTime(timeRemaining)}</div>
            </div>
          </div>
          <Progress 
            value={(currentQuestion + 1) / assessmentQuestions.length * 100} 
            className="h-2" 
          />
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-2">
            <Badge variant="outline">{currentQ.category}</Badge>
            <Badge className={
              currentQ.difficulty === 'beginner' ? 'bg-green-100 text-green-800' :
              currentQ.difficulty === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
              'bg-red-100 text-red-800'
            }>
              {currentQ.difficulty}
            </Badge>
            <Badge variant="secondary">{currentQ.points} points</Badge>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">{currentQ.question}</h3>

            {currentQ.type === 'multiple-choice' && currentQ.options && (
              <RadioGroup
                value={answers[currentQ.id] || ''}
                onValueChange={(value) => handleAnswer(currentQ.id, value)}
              >
                <div className="space-y-3">
                  {currentQ.options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <RadioGroupItem value={option} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            )}

            {currentQ.type === 'scenario' && (
              <Textarea
                placeholder="Type your answer here..."
                value={answers[currentQ.id] || ''}
                onChange={(e) => handleAnswer(currentQ.id, e.target.value)}
                className="min-h-32"
              />
            )}
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentQuestion(prev => prev - 1)}
              disabled={currentQuestion === 0}
            >
              Previous
            </Button>
            <Button
              onClick={nextQuestion}
              disabled={!answers[currentQ.id]}
            >
              {currentQuestion === assessmentQuestions.length - 1 ? 'Complete' : 'Next'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AssessmentEngine;
