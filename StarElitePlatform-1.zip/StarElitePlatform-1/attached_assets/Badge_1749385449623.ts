// Badge model
export interface Badge {
  id: string;
  name: string;
  description: string;
  iconUrl: string;
  userId: string;
  awardedAt: Date;
}
