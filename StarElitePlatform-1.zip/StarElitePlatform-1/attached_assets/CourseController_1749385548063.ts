// CourseController.ts

import { Request, Response } from 'express';
import { getCourses, addCourse, getCourseById } from '../models/CourseModel';

export const listCourses = (req: Request, res: Response) => {
  res.json(getCourses());
};

export const createCourse = (req: Request, res: Response) => {
  const course = req.body;
  addCourse(course);
  res.status(201).json({ message: 'Course created', course });
};

export const getCourse = (req: Request, res: Response) => {
  const { id } = req.params;
  const course = getCourseById(id);
  if (course) {
    res.json(course);
  } else {
    res.status(404).json({ message: 'Course not found' });
  }
};