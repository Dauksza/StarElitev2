// MistralClient.ts

import axios from 'axios';

export const callMistralAI = async (prompt: string): Promise<string> => {
  try {
    const response = await axios.post(
      process.env.MISTRAL_API_URL || '',
      {
        model: 'mistral-7b-instruct',
        messages: [{ role: 'user', content: prompt }],
        stream: false
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.MISTRAL_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data.choices[0].message.content;
  } catch (error: any) {
    console.error('Mistral API error:', error.response?.data || error.message);
    return 'Error calling Mistral AI';
  }
};