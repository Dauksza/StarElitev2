// LeaderboardController.ts

import { Request, Response } from 'express';

interface LeaderboardEntry {
  username: string;
  points: number;
}

let leaderboard: LeaderboardEntry[] = [];

export const listLeaderboard = (req: Request, res: Response) => {
  res.json(leaderboard.sort((a, b) => b.points - a.points));
};

export const addLeaderboardEntry = (req: Request, res: Response) => {
  const entry: LeaderboardEntry = req.body;
  leaderboard.push(entry);
  res.status(201).json({ message: 'Leaderboard entry added', entry });
};