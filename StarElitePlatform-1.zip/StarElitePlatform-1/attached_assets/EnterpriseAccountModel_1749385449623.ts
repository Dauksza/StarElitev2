// EnterpriseAccountModel.ts

export interface EnterpriseAccount {
  id: string;
  name: string;
  licenseCount: number;
  userIds: string[];
}

let enterpriseAccounts: EnterpriseAccount[] = [];

// CRUD Operations
export const getEnterpriseAccounts = (): EnterpriseAccount[] => enterpriseAccounts;

export const addEnterpriseAccount = (account: EnterpriseAccount) => {
  enterpriseAccounts.push(account);
};

export const addUserToEnterpriseAccount = (accountId: string, userId: string) => {
  const account = enterpriseAccounts.find((a) => a.id === accountId);
  if (account && account.userIds.length < account.licenseCount * 10) {
    account.userIds.push(userId);
    return true;
  }
  return false;
};