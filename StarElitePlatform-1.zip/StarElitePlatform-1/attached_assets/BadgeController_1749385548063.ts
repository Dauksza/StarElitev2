// BadgeController.ts

import { Request, Response } from 'express';
import { getBadges, addBadge, removeBadge, Badge } from '../models/BadgeModel';

export const listBadges = (req: Request, res: Response) => {
  res.json(getBadges());
};

export const createBadge = (req: Request, res: Response) => {
  const badge: Badge = req.body;
  addBadge(badge);
  res.status(201).json({ message: 'Badge created', badge });
};

export const deleteBadge = (req: Request, res: Response) => {
  const { id } = req.params;
  removeBadge(id);
  res.json({ message: `Badge ${id} removed` });
};