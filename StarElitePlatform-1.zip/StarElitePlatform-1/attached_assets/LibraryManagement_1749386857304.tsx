import React, { useEffect, useState } from "react";
import axios from "axios";

export default function LibraryManagementPage() {
  const [courses, setCourses] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [exams, setExams] = useState([]);
  const [certificates, setCertificates] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const resCourses = await axios.get("/api/courses");
      const resLessons = await axios.get("/api/lessons");
      const resExams = await axios.get("/api/exams");
      const resCertificates = await axios.get("/api/certificates");

      setCourses(resCourses.data);
      setLessons(resLessons.data);
      setExams(resExams.data);
      setCertificates(resCertificates.data);
    };
    fetchData();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Library Management</h1>

      <section className="mb-8">
        <h2 className="text-xl font-bold mb-2">Courses</h2>
        <ul className="list-disc ml-5">
          {courses.map((c: any) => (
            <li key={c.id}>{c.title} - {c.syllabus}</li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-bold mb-2">Lessons (Approve / Edit / Archive)</h2>
        <ul className="list-disc ml-5">
          {lessons.map((l: any) => (
            <div key={l.id} className="border p-2 mb-2">
              <strong>{l.title}</strong> (Course: {l.courseId})
              <div className="mt-1">
                <label>
                  <input type="checkbox" checked={!!approvedLessons[l.id]} onChange={() => toggleApproveLesson(l.id)} /> Approve
                </label>
                <button onClick={() => startEditLesson(l.id, l.title)} className="ml-2 text-blue-500">Edit</button>
                <button onClick={() => console.log('Archiving lesson:', l.id)} className="ml-2 text-red-500">Archive</button>
              </div>
              {editingLessonId === l.id && (
                <div className="mt-2">
                  <input type="text" value={editedLessonTitle} onChange={(e) => setEditedLessonTitle(e.target.value)} className="border p-1" />
                  <button onClick={saveEditLesson} className="ml-2 bg-green-500 text-white px-2 py-1 rounded">Save</button>
                </div>
              )}
            </div>

            <li key={l.id}>{l.title} (Course: {l.courseId})</li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-bold mb-2">Exams</h2>
        <ul className="list-disc ml-5">
          {exams.map((e: any) => (
            <li key={e.id}>Course: {e.courseId}, Questions: {e.questions.length}</li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-bold mb-2">Certificates</h2>
        <ul className="list-disc ml-5">
          {certificates.map((c: any) => (
            <li key={c.id}>User: {c.userId}, Course: {c.courseId}, Issued: {c.issueDate}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}