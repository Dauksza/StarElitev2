// UserProgress model

export interface UserProgress {
  userId: string;
  progress: number; // 0 to 100
  level: number;
}

let userProgresses: UserProgress[] = [];

// CRUD operations for UserProgress
export const getUserProgresses = (): UserProgress[] => userProgresses;

export const updateUserProgress = (progress: UserProgress) => {
  const index = userProgresses.findIndex((p) => p.userId === progress.userId);
  if (index >= 0) {
    userProgresses[index] = progress;
  } else {
    userProgresses.push(progress);
  }
};