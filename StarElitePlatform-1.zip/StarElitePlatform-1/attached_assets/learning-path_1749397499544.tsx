// Learning Path Page Placeholder
import React from "react";

export default function LearningPathPage() {
  return <div>Learning Path Page Placeholder</div>;
}
