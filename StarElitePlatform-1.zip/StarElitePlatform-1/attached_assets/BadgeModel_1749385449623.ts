// Badge model (using a simple in-memory or file-based approach for demo)
// In production, integrate with real DB (e.g., PostgreSQL, MongoDB)

export interface Badge {
  id: string;
  name: string;
  description: string;
}

let badges: Badge[] = [];

// CRUD operations for Badge
export const getBadges = (): Badge[] => badges;

export const addBadge = (badge: Badge) => {
  badges.push(badge);
};

export const removeBadge = (id: string) => {
  badges = badges.filter((b) => b.id !== id);
};