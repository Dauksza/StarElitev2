// CourseModel.ts

export interface Course {
  id: string;
  title: string;
  syllabus: string;
  lessonIds: string[];
}

let courses: Course[] = [];

// CRUD Operations
export const getCourses = (): Course[] => courses;

export const addCourse = (course: Course) => {
  courses.push(course);
};

export const getCourseById = (id: string): Course | undefined =>
  courses.find((c) => c.id === id);

// Seed Initial Courses
export const seedInitialCourses = () => {
  if (courses.length === 0) {
    addCourse({
      id: 'course-ai-foundations',
      title: 'AI Foundations',
      syllabus: 'Introduction to AI, Machine Learning Basics, Neural Networks, NLP, Computer Vision',
      lessonIds: []
    });
    addCourse({
      id: 'course-data-science',
      title: 'Data Science Essentials',
      syllabus: 'Data Analysis, Data Engineering, Visualization, SQL',
      lessonIds: []
    });
    addCourse({
      id: 'course-cloud',
      title: 'Cloud Fundamentals',
      syllabus: 'AWS, Azure, GCP Basics',
      lessonIds: []
    });
    addCourse({
      id: 'course-fullstack-dev',
      title: 'Full Stack Development',
      syllabus: 'HTML, CSS, JS, React, Node.js, APIs',
      lessonIds: []
    });
    addCourse({
      id: 'course-cybersecurity',
      title: 'Cybersecurity Essentials',
      syllabus: 'Cyber Threats, Defensive Strategies, Risk Management',
      lessonIds: []
    });
    console.log('Initial courses seeded');
  }
};