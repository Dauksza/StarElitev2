
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card.tsx';
import { Button } from './ui/button.tsx';
import { Badge } from './ui/badge.tsx';
import { Progress } from './ui/progress.tsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.tsx';
import { 
  Award, 
  Clock, 
  Users, 
  Star, 
  CheckCircle, 
  Lock, 
  Download,
  Share,
  TrendingUp,
  Calendar,
  Globe,
  BookOpen
} from 'lucide-react';

interface Certification {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  duration: string;
  enrolledStudents: number;
  completionRate: number;
  industryRecognition: number; // 1-5 stars
  requirements: string[];
  skills: string[];
  status: 'available' | 'in-progress' | 'completed' | 'locked';
  progress: number;
  certificateUrl?: string;
  issueDate?: string;
  expiryDate?: string;
  credentialId?: string;
  modules: Module[];
}

interface Module {
  id: string;
  title: string;
  type: 'video' | 'reading' | 'hands-on' | 'exam';
  duration: number;
  completed: boolean;
  score?: number;
}

const certifications: Certification[] = [
  {
    id: 'data-science-professional',
    title: 'Professional Data Science Certification',
    description: 'Comprehensive certification covering Python, statistics, machine learning, and data visualization. Industry-recognized credential for data science professionals.',
    category: 'Data Science',
    difficulty: 'advanced',
    duration: '3-4 months',
    enrolledStudents: 1250,
    completionRate: 78,
    industryRecognition: 5,
    requirements: [
      'Complete Data Science Fundamentals course',
      'Pass 3 practical projects',
      'Score 80% or higher on final exam',
      'Peer review participation'
    ],
    skills: ['Python', 'Machine Learning', 'Statistics', 'Data Visualization', 'SQL'],
    status: 'in-progress',
    progress: 65,
    modules: [
      {
        id: 'ds-foundations',
        title: 'Data Science Foundations',
        type: 'video',
        duration: 480,
        completed: true,
        score: 92
      },
      {
        id: 'ml-algorithms',
        title: 'Machine Learning Algorithms',
        type: 'hands-on',
        duration: 720,
        completed: true,
        score: 88
      },
      {
        id: 'capstone-project',
        title: 'Capstone Project',
        type: 'hands-on',
        duration: 1200,
        completed: false
      },
      {
        id: 'final-exam',
        title: 'Certification Exam',
        type: 'exam',
        duration: 180,
        completed: false
      }
    ]
  },
  {
    id: 'fullstack-developer',
    title: 'Full-Stack Web Developer Certification',
    description: 'Master modern web development with React, Node.js, databases, and deployment. Build production-ready applications.',
    category: 'Web Development',
    difficulty: 'intermediate',
    duration: '2-3 months',
    enrolledStudents: 2100,
    completionRate: 85,
    industryRecognition: 4,
    requirements: [
      'Complete all web development modules',
      'Build 2 full-stack projects',
      'Pass technical interview simulation',
      'Code review participation'
    ],
    skills: ['React', 'Node.js', 'JavaScript', 'Databases', 'APIs', 'Deployment'],
    status: 'available',
    progress: 0,
    modules: [
      {
        id: 'frontend-fundamentals',
        title: 'Frontend Fundamentals',
        type: 'video',
        duration: 360,
        completed: false
      },
      {
        id: 'backend-development',
        title: 'Backend Development',
        type: 'hands-on',
        duration: 480,
        completed: false
      },
      {
        id: 'database-integration',
        title: 'Database Integration',
        type: 'hands-on',
        duration: 300,
        completed: false
      }
    ]
  },
  {
    id: 'cloud-architect',
    title: 'Cloud Solutions Architect',
    description: 'Design and implement scalable cloud solutions using AWS, Azure, and GCP. Enterprise-level cloud architecture certification.',
    category: 'Cloud Computing',
    difficulty: 'expert',
    duration: '4-6 months',
    enrolledStudents: 850,
    completionRate: 72,
    industryRecognition: 5,
    requirements: [
      '2+ years cloud experience',
      'Complete all cloud modules',
      'Pass vendor-neutral exam',
      'Design and present solution architecture'
    ],
    skills: ['AWS', 'Azure', 'GCP', 'DevOps', 'Security', 'Architecture'],
    status: 'locked',
    progress: 0,
    modules: []
  },
  {
    id: 'ai-ml-specialist',
    title: 'AI/ML Specialist Certification',
    description: 'Deep learning, neural networks, and AI applications. Cutting-edge certification for AI professionals.',
    category: 'Artificial Intelligence',
    difficulty: 'expert',
    duration: '5-6 months',
    enrolledStudents: 950,
    completionRate: 68,
    industryRecognition: 5,
    requirements: [
      'Advanced mathematics background',
      'Complete ML fundamentals',
      'Research project submission',
      'Peer review participation'
    ],
    skills: ['Deep Learning', 'Neural Networks', 'TensorFlow', 'PyTorch', 'AI Ethics'],
    status: 'available',
    progress: 0,
    modules: []
  }
];

const earnedCertifications = [
  {
    id: 'python-fundamentals',
    title: 'Python Programming Fundamentals',
    category: 'Programming',
    issueDate: '2024-01-15',
    credentialId: 'PYF-2024-001234',
    certificateUrl: '/certificates/python-fundamentals.pdf'
  },
  {
    id: 'sql-database',
    title: 'SQL and Database Management',
    category: 'Data Management',
    issueDate: '2023-12-10',
    credentialId: 'SQL-2023-005678',
    certificateUrl: '/certificates/sql-database.pdf'
  }
];

export const CertificationSystem: React.FC = () => {
  const [selectedCert, setSelectedCert] = useState<Certification>(certifications[0]);
  const [activeTab, setActiveTab] = useState('browse');

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'advanced': return 'bg-orange-100 text-orange-800';
      case 'expert': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'locked': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const enrollInCertification = (cert: Certification) => {
    console.log('Enrolling in:', cert.title);
    // Here you would handle enrollment logic
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Professional Certifications</h1>
          <p className="text-muted-foreground">
            Earn industry-recognized credentials and advance your career
          </p>
        </div>
        <Badge variant="secondary" className="flex items-center gap-2">
          <Award className="w-4 h-4" />
          {earnedCertifications.length} Earned
        </Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="browse">Browse Certifications</TabsTrigger>
          <TabsTrigger value="my-progress">My Progress</TabsTrigger>
          <TabsTrigger value="earned">Earned Certificates</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {certifications.map((cert) => (
              <Card 
                key={cert.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedCert.id === cert.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedCert(cert)}
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{cert.title}</CardTitle>
                    <div className="flex gap-1">
                      {[...Array(cert.industryRecognition)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline">{cert.category}</Badge>
                    <Badge className={getDifficultyColor(cert.difficulty)}>
                      {cert.difficulty}
                    </Badge>
                    <Badge className={getStatusColor(cert.status)}>
                      {cert.status === 'in-progress' ? 'In Progress' : cert.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{cert.description}</p>

                  {cert.status === 'in-progress' && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{cert.progress}%</span>
                      </div>
                      <Progress value={cert.progress} className="h-2" />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>{cert.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span>{cert.enrolledStudents.toLocaleString()} enrolled</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span>{cert.completionRate}% completion</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-purple-500" />
                      <span>Industry recognized</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Skills you'll master:</p>
                    <div className="flex flex-wrap gap-1">
                      {cert.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                {selectedCert.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Requirements</h4>
                  <ul className="space-y-2">
                    {selectedCert.requirements.map((req, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Certification Modules</h4>
                  <div className="space-y-2">
                    {selectedCert.modules.map((module, index) => (
                      <div key={module.id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          {module.completed ? (
                            <CheckCircle className="w-4 h-4 text-green-500" />
                          ) : (
                            <div className="w-4 h-4 rounded-full border border-gray-300" />
                          )}
                          <span>{module.title}</span>
                        </div>
                        {module.score && (
                          <Badge variant="outline">{module.score}%</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                {selectedCert.status === 'available' && (
                  <Button 
                    onClick={() => enrollInCertification(selectedCert)}
                    className="flex-1"
                  >
                    Enroll Now
                  </Button>
                )}
                {selectedCert.status === 'in-progress' && (
                  <Button className="flex-1">
                    Continue Learning
                  </Button>
                )}
                {selectedCert.status === 'locked' && (
                  <Button disabled className="flex-1">
                    <Lock className="w-4 h-4 mr-2" />
                    Requirements Not Met
                  </Button>
                )}
                <Button variant="outline">
                  Learn More
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="my-progress" className="space-y-6">
          {certifications.filter(cert => cert.status === 'in-progress').map((cert) => (
            <Card key={cert.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{cert.title}</CardTitle>
                    <Badge className={getDifficultyColor(cert.difficulty)}>
                      {cert.difficulty}
                    </Badge>
                  </div>
                  <Badge className={getStatusColor(cert.status)}>
                    In Progress
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Overall Progress</span>
                    <span className="font-semibold">{cert.progress}%</span>
                  </div>
                  <Progress value={cert.progress} className="h-3" />
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Module Progress</h4>
                  {cert.modules.map((module) => (
                    <div key={module.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {module.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : (
                          <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
                        )}
                        <div>
                          <div className="font-medium">{module.title}</div>
                          <div className="text-sm text-muted-foreground">
                            {module.duration} minutes • {module.type}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {module.score && (
                          <Badge variant="outline">{module.score}%</Badge>
                        )}
                        <Button size="sm" variant={module.completed ? "outline" : "default"}>
                          {module.completed ? "Review" : "Start"}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="earned" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {earnedCertifications.map((cert) => (
              <Card key={cert.id} className="border-green-200 bg-green-50 dark:bg-green-950">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Award className="w-6 h-6 text-green-600" />
                      <CardTitle className="text-green-800 dark:text-green-200">
                        {cert.title}
                      </CardTitle>
                    </div>
                    <Badge className="bg-green-600 text-white">
                      Certified
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Issue Date:</span>
                      <div className="font-medium">{cert.issueDate}</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Credential ID:</span>
                      <div className="font-medium font-mono text-xs">{cert.credentialId}</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1">
                      <Download className="w-4 h-4 mr-2" />
                      Download Certificate
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <Share className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {earnedCertifications.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Award className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Certificates Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Complete your first certification to earn your credentials
                </p>
                <Button onClick={() => setActiveTab('browse')}>
                  Browse Certifications
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CertificationSystem;
