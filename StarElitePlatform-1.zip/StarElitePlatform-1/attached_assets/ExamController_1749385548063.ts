// ExamController.ts

import { Request, Response } from 'express';
import { getExams, addExam, getExamByCourseId } from '../models/ExamModel';

export const listExams = (req: Request, res: Response) => {
  res.json(getExams());
};

export const createExam = (req: Request, res: Response) => {
  const exam = req.body;
  addExam(exam);
  res.status(201).json({ message: 'Exam created', exam });
};

export const getExamByCourse = (req: Request, res: Response) => {
  const { courseId } = req.params;
  const exam = getExamByCourseId(courseId);
  if (exam) {
    res.json(exam);
  } else {
    res.status(404).json({ message: 'Exam not found' });
  }
};