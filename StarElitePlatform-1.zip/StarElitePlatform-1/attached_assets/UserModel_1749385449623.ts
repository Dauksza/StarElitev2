// UserModel.ts
import bcrypt from 'bcrypt';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  subscription: 'Freemium' | 'Premium' | 'Pro' | 'Enterprise';
  isAdmin: boolean;
  progress: number; // 0 to 100
  streak: number;
courseProgress: { [courseId: string]: number };
// Stripe integration fields
stripeCustomerId?: string;
subscriptionStatus?: 'active' | 'inactive' | 'trialing' | 'canceled';
lessonsUsedToday: number;
lessonsLastUsedDate: string;
certsUsed: number;   // days
}

let users: User[] = [];

// Seed Admin User
export const seedAdminUser = async () => {
  const existingAdmin = users.find((u) => u.email === 'chrisdauksza@gmail.com');
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash('LynLeigh123!@$', 10);
    const adminUser: User = {
      id: 'admin-1',
      email: 'chrisdauksza@gmail.com',
      passwordHash,
      subscription: 'Enterprise',
      isAdmin: true,
      progress: 100,
      streak: 999
    };
    users.push(adminUser);
    console.log('Admin user seeded:', adminUser.email);
  }
};

// CRUD Operations
export const getUsers = (): User[] => users;

export const addUser = async (user: Omit<User, 'id' | 'passwordHash'> & { password: string }) => {
  const passwordHash = await bcrypt.hash(user.password, 10);
  const newUser: User = {
    id: `user-${Date.now()}`,
    email: user.email,
    passwordHash,
    subscription: user.subscription,
    isAdmin: user.isAdmin,
    progress: user.progress,
    streak: user.streak
  };
  users.push(newUser);
  return newUser;
};

export const updateUser = (id: string, updates: Partial<Omit<User, 'id' | 'email' | 'passwordHash'>>) => {
  const user = users.find((u) => u.id === id);
  if (user) {
    Object.assign(user, updates);
  }
  return user;
};

export const resetUserPassword = async (id: string, newPassword: string) => {
  const user = users.find((u) => u.id === id);
  if (user) {
    user.passwordHash = await bcrypt.hash(newPassword, 10);
  }
  return user;
};

export const authenticateUser = async (email: string, password: string) => {
  const user = users.find((u) => u.email === email);
  if (user && await bcrypt.compare(password, user.passwordHash)) {
    return user;
  }
  return null;
};