// CertificateController.ts

import { Request, Response } from 'express';
import { getCertificates, addCertificate, getCertificatesByUserId } from '../models/CertificateModel';

export const listCertificates = (req: Request, res: Response) => {
  res.json(getCertificates());
};

export const issueCertificate = (req: Request, res: Response) => {
  const cert = req.body;
  addCertificate(cert);
  res.status(201).json({ message: 'Certificate issued', cert });
};

export const listCertificatesByUser = (req: Request, res: Response) => {
  const { userId } = req.params;
  res.json(getCertificatesByUserId(userId));
};