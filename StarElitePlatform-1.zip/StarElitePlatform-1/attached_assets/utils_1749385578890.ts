// AI shared utils.ts

// TODO: Add helper functions
