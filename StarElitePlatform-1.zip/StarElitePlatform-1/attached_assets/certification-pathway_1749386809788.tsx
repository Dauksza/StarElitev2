import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Award, 
  CheckCircle, 
  Clock, 
  Star, 
  Target,
  TrendingUp,
  Users,
  ExternalLink,
  Download,
  Share2,
  Trophy,
  Zap
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface Certification {
  id: number;
  name: string;
  description: string;
  category: string;
  difficulty: "beginner" | "intermediate" | "advanced" | "expert";
  requirements: {
    minLevel?: number;
    requiredPaths?: string[];
    minScore?: number;
  };
  badgeIcon?: string;
  industryRecognition?: number;
  averageCompletionTime?: number;
  completionRate?: number;
  createdAt: string;
}

interface UserCertification {
  id: number;
  userId: number;
  certificationId: number;
  status: "in_progress" | "completed" | "expired";
  progress: number;
  completedAt?: string;
  expiresAt?: string;
  credentialUrl?: string;
  certification?: Certification;
}

interface CertificationPathwayProps {
  userId: number;
  selectedCategory?: string;
}

export default function CertificationPathway({ userId, selectedCategory }: CertificationPathwayProps) {
  const [selectedTab, setSelectedTab] = useState("available");
  const [selectedCert, setSelectedCert] = useState<Certification | null>(null);

  const { data: certifications, isLoading: certsLoading } = useQuery({
    queryKey: ["/api/certifications"],
  });

  const { data: userCertifications, isLoading: userCertsLoading } = useQuery({
    queryKey: ["/api/user/certifications"],
  });

  const { data: userProfile } = useQuery({
    queryKey: ["/api/user/profile"],
  });

  const filteredCertifications = certifications?.filter((cert: Certification) => 
    !selectedCategory || cert.category === selectedCategory
  ) || [];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800 border-green-200";
      case "intermediate": return "bg-blue-100 text-blue-800 border-blue-200";
      case "advanced": return "bg-orange-100 text-orange-800 border-orange-200";
      case "expert": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "in_progress": return <Clock className="h-4 w-4 text-blue-600" />;
      case "expired": return <Target className="h-4 w-4 text-red-600" />;
      default: return <Star className="h-4 w-4 text-gray-600" />;
    }
  };

  const canStartCertification = (cert: Certification) => {
    if (!userProfile) return false;
    
    const { requirements } = cert;
    
    // Check minimum level
    if (requirements.minLevel && userProfile.level < requirements.minLevel) {
      return false;
    }
    
    // Check required learning paths (simplified check)
    if (requirements.requiredPaths && requirements.requiredPaths.length > 0) {
      // Would need to check if user has completed required paths
      return true; // Simplified for demo
    }
    
    return true;
  };

  const startCertification = async (certificationId: number) => {
    try {
      const response = await fetch("/api/user/certifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ certificationId }),
      });
      
      if (response.ok) {
        // Refresh user certifications
        window.location.reload();
      }
    } catch (error) {
      console.error("Error starting certification:", error);
    }
  };

  if (certsLoading || userCertsLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="h-5 w-5 text-primary" />
            <span>Certification Pathway</span>
          </CardTitle>
          <CardDescription>Loading certification data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Award className="h-5 w-5 text-primary" />
          <span>Industry Certifications</span>
          <Badge className="bg-accent text-primary">Professional Recognition</Badge>
        </CardTitle>
        <CardDescription>
          Earn industry-recognized certifications to advance your career
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="available">Available</TabsTrigger>
            <TabsTrigger value="in_progress">In Progress</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="mt-6">
            <div className="grid gap-4 md:grid-cols-2">
              {filteredCertifications.map((cert: Certification) => {
                const userCert = userCertifications?.find((uc: UserCertification) => 
                  uc.certificationId === cert.id
                );
                const canStart = canStartCertification(cert);

                return (
                  <Card key={cert.id} className="border-l-4 border-l-accent">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{cert.name}</CardTitle>
                          <CardDescription className="mt-1">
                            {cert.description}
                          </CardDescription>
                        </div>
                        <Badge className={getDifficultyColor(cert.difficulty)}>
                          {cert.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="text-xs">
                            <Users className="h-3 w-3 mr-1" />
                            {cert.completionRate}% completion rate
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            ~{cert.averageCompletionTime}h
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            {cert.industryRecognition}/10 recognition
                          </Badge>
                        </div>

                        {cert.requirements && (
                          <div className="text-xs text-muted-foreground">
                            <p className="font-semibold mb-1">Requirements:</p>
                            <ul className="space-y-1">
                              {cert.requirements.minLevel && (
                                <li>• Minimum Level {cert.requirements.minLevel}</li>
                              )}
                              {cert.requirements.minScore && (
                                <li>• Minimum {cert.requirements.minScore}% average score</li>
                              )}
                              {cert.requirements.requiredPaths && (
                                <li>• Complete {cert.requirements.requiredPaths.length} prerequisite paths</li>
                              )}
                            </ul>
                          </div>
                        )}

                        <div className="flex space-x-2">
                          {userCert ? (
                            <Button variant="outline" size="sm" disabled>
                              {userCert.status === "completed" ? "Completed" : "In Progress"}
                            </Button>
                          ) : canStart ? (
                            <Button 
                              size="sm" 
                              onClick={() => startCertification(cert.id)}
                              className="bg-primary"
                            >
                              <Zap className="h-3 w-3 mr-1" />
                              Start Certification
                            </Button>
                          ) : (
                            <Button variant="outline" size="sm" disabled>
                              Requirements Not Met
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setSelectedCert(cert)}
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="in_progress" className="mt-6">
            <div className="space-y-4">
              {userCertifications?.filter((uc: UserCertification) => uc.status === "in_progress")
                .map((userCert: UserCertification) => (
                <Card key={userCert.id} className="border-l-4 border-l-blue-500">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center">
                        {getStatusIcon(userCert.status)}
                        <span className="ml-2">{userCert.certification?.name}</span>
                      </CardTitle>
                      <Badge variant="secondary">
                        {userCert.progress}% Complete
                      </Badge>
                    </div>
                    <CardDescription>
                      {userCert.certification?.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Progress</span>
                          <span>{userCert.progress}%</span>
                        </div>
                        <Progress value={userCert.progress} className="h-2" />
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button size="sm">
                          Continue Learning
                        </Button>
                        <Button variant="outline" size="sm">
                          View Requirements
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {!userCertifications?.some((uc: UserCertification) => uc.status === "in_progress") && (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No certifications in progress</p>
                  <p className="text-sm">Start a certification from the Available tab</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <div className="space-y-4">
              {userCertifications?.filter((uc: UserCertification) => uc.status === "completed")
                .map((userCert: UserCertification) => (
                <Card key={userCert.id} className="border-l-4 border-l-green-500 bg-green-50/50">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <span className="ml-2">{userCert.certification?.name}</span>
                      </CardTitle>
                      <Badge className="bg-green-100 text-green-800">
                        Certified
                      </Badge>
                    </div>
                    <CardDescription>
                      Completed on {userCert.completedAt ? new Date(userCert.completedAt).toLocaleDateString() : 'N/A'}
                      {userCert.expiresAt && (
                        <span className="ml-2">
                          • Expires {new Date(userCert.expiresAt).toLocaleDateString()}
                        </span>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-2">
                      {userCert.credentialUrl && (
                        <Button size="sm" variant="outline">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Credential
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        <Download className="h-3 w-3 mr-1" />
                        Download Certificate
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="h-3 w-3 mr-1" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {!userCertifications?.some((uc: UserCertification) => uc.status === "completed") && (
                <div className="text-center py-8 text-muted-foreground">
                  <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No completed certifications yet</p>
                  <p className="text-sm">Complete your first certification to showcase your expertise</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {selectedCert && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{selectedCert.name}</CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setSelectedCert(null)}
                  >
                    ×
                  </Button>
                </div>
                <CardDescription>{selectedCert.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-sm">Difficulty</h4>
                      <Badge className={getDifficultyColor(selectedCert.difficulty)}>
                        {selectedCert.difficulty}
                      </Badge>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">Category</h4>
                      <p className="text-sm text-muted-foreground">{selectedCert.category}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">Industry Recognition</h4>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 mr-1" />
                        <span className="text-sm">{selectedCert.industryRecognition}/10</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">Avg. Completion Time</h4>
                      <p className="text-sm text-muted-foreground">{selectedCert.averageCompletionTime} hours</p>
                    </div>
                  </div>

                  {selectedCert.requirements && (
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Requirements</h4>
                      <Alert>
                        <Target className="h-4 w-4" />
                        <AlertDescription>
                          <ul className="space-y-1">
                            {selectedCert.requirements.minLevel && (
                              <li>• Minimum Level {selectedCert.requirements.minLevel}</li>
                            )}
                            {selectedCert.requirements.minScore && (
                              <li>• Minimum {selectedCert.requirements.minScore}% average score</li>
                            )}
                            {selectedCert.requirements.requiredPaths && (
                              <li>• Complete {selectedCert.requirements.requiredPaths.length} prerequisite learning paths</li>
                            )}
                          </ul>
                        </AlertDescription>
                      </Alert>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    {canStartCertification(selectedCert) ? (
                      <Button 
                        onClick={() => {
                          startCertification(selectedCert.id);
                          setSelectedCert(null);
                        }}
                        className="bg-primary"
                      >
                        <Zap className="h-4 w-4 mr-2" />
                        Start Certification
                      </Button>
                    ) : (
                      <Button variant="outline" disabled>
                        Requirements Not Met
                      </Button>
                    )}
                    <Button variant="outline" onClick={() => setSelectedCert(null)}>
                      Close
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  );
}