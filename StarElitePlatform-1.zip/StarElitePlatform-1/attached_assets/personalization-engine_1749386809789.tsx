
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Brain,
  Target,
  Zap,
  TrendingUp,
  Settings,
  User,
  BookOpen,
  Clock,
  Star
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";

export default function PersonalizationEngine() {
  const [learningStyle, setLearningStyle] = useState("visual");
  const [difficulty, setDifficulty] = useState("intermediate");
  const [timePreference, setTimePreference] = useState("30min");

  const { data: preferences = {} } = useQuery({
    queryKey: ["/api/user/preferences"],
  });

  const { data: recommendations = [] } = useQuery({
    queryKey: ["/api/ai/recommendations"],
  });

  const updatePreferences = useMutation({
    mutationFn: async (prefs: any) => {
      const response = await fetch("/api/user/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(prefs)
      });
      return response.json();
    }
  });

  const learningStyles = [
    { value: "visual", label: "Visual", description: "Learn through diagrams and visual aids" },
    { value: "auditory", label: "Auditory", description: "Learn through listening and discussion" },
    { value: "kinesthetic", label: "Kinesthetic", description: "Learn through hands-on practice" },
    { value: "reading", label: "Reading/Writing", description: "Learn through text and written content" }
  ];

  const difficultyLevels = [
    { value: "beginner", label: "Beginner", description: "New to the topic" },
    { value: "intermediate", label: "Intermediate", description: "Some experience" },
    { value: "advanced", label: "Advanced", description: "Experienced learner" },
    { value: "expert", label: "Expert", description: "Deep expertise" }
  ];

  const timePreferences = [
    { value: "15min", label: "15 minutes", description: "Quick learning sessions" },
    { value: "30min", label: "30 minutes", description: "Standard sessions" },
    { value: "60min", label: "1 hour", description: "Deep dive sessions" },
    { value: "120min", label: "2+ hours", description: "Extended learning" }
  ];

  const handleSavePreferences = () => {
    updatePreferences.mutate({
      learningStyle,
      difficulty,
      timePreference,
      updatedAt: new Date()
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary" />
            AI Personalization Engine
          </CardTitle>
          <p className="text-gray-600">Customize your learning experience with AI-powered recommendations</p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="preferences" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
              <TabsTrigger value="analytics">Learning Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="preferences" className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Learning Style</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Select value={learningStyle} onValueChange={setLearningStyle}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {learningStyles.map((style) => (
                          <SelectItem key={style.value} value={style.value}>
                            <div>
                              <div className="font-medium">{style.label}</div>
                              <div className="text-sm text-gray-500">{style.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Difficulty Level</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Select value={difficulty} onValueChange={setDifficulty}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {difficultyLevels.map((level) => (
                          <SelectItem key={level.value} value={level.value}>
                            <div>
                              <div className="font-medium">{level.label}</div>
                              <div className="text-sm text-gray-500">{level.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Session Duration</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Select value={timePreference} onValueChange={setTimePreference}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timePreferences.map((time) => (
                          <SelectItem key={time.value} value={time.value}>
                            <div>
                              <div className="font-medium">{time.label}</div>
                              <div className="text-sm text-gray-500">{time.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card className="flex items-center justify-center">
                  <CardContent className="p-6">
                    <Button 
                      onClick={handleSavePreferences}
                      className="w-full bg-primary text-white"
                      disabled={updatePreferences.isPending}
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      {updatePreferences.isPending ? "Saving..." : "Save Preferences"}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                {recommendations.map((rec, index) => (
                  <Card key={index} className="border-l-4 border-l-accent">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{rec.title}</CardTitle>
                          <p className="text-sm text-gray-600 mt-1">{rec.description}</p>
                        </div>
                        <Badge className="bg-accent text-primary">
                          <Star className="h-3 w-3 mr-1" />
                          {rec.confidence}%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {rec.estimatedTime}
                          </span>
                          <span className="flex items-center">
                            <Target className="h-4 w-4 mr-1" />
                            {rec.difficulty}
                          </span>
                        </div>
                        <Button size="sm" className="w-full">
                          <BookOpen className="h-4 w-4 mr-2" />
                          Start Learning
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold text-primary">87%</CardTitle>
                    <p className="text-sm text-gray-600">Learning Efficiency</p>
                  </CardHeader>
                  <CardContent>
                    <Progress value={87} className="mb-2" />
                    <p className="text-xs text-gray-500">Based on completion rates and engagement</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold text-green-600">92%</CardTitle>
                    <p className="text-sm text-gray-600">Retention Rate</p>
                  </CardHeader>
                  <CardContent>
                    <Progress value={92} className="mb-2" />
                    <p className="text-xs text-gray-500">Knowledge retained after 7 days</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold text-purple-600">4.8</CardTitle>
                    <p className="text-sm text-gray-600">Learning Score</p>
                  </CardHeader>
                  <CardContent>
                    <Progress value={96} className="mb-2" />
                    <p className="text-xs text-gray-500">Overall learning performance</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
