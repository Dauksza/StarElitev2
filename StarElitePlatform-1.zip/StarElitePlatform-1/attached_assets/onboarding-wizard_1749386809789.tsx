import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Target, 
  Brain, 
  Rocket, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  Sparkles,
  Zap
} from "lucide-react";

interface OnboardingWizardProps {
  onComplete: (data: any) => void;
  isLoading?: boolean;
}

export default function OnboardingWizard({ onComplete, isLoading = false }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    goals: [] as string[],
    experience: "",
    currentSkills: [] as string[],
    interests: [] as string[],
    timeCommitment: "",
    learningStyle: "",
    careerGoals: "",
    challenges: [] as string[],
  });

  const steps = [
    {
      title: "Tell Us Your Goals",
      subtitle: "What do you want to achieve with StarElite?",
      icon: Target,
      component: "goals"
    },
    {
      title: "Your Experience Level",
      subtitle: "Help us understand where you're starting from",
      icon: Brain,
      component: "experience"
    },
    {
      title: "Current Skills",
      subtitle: "What skills do you already have?",
      icon: CheckCircle,
      component: "skills"
    },
    {
      title: "Learning Preferences",
      subtitle: "How do you learn best?",
      icon: Sparkles,
      component: "preferences"
    },
    {
      title: "Final Details",
      subtitle: "Complete your personalized profile",
      icon: Rocket,
      component: "details"
    }
  ];

  const goalOptions = [
    "Advance my career in technology",
    "Develop leadership skills",
    "Master data analysis",
    "Learn machine learning",
    "Improve programming skills",
    "Get certified in my field",
    "Switch to a new career",
    "Build a startup",
    "Enhance problem-solving abilities",
    "Stay current with industry trends"
  ];

  const skillOptions = [
    "Python", "JavaScript", "Data Analysis", "Machine Learning", 
    "Leadership", "Project Management", "SQL", "Excel", 
    "Communication", "Critical Thinking", "Problem Solving",
    "Team Management", "Strategic Planning", "Research"
  ];

  const interestOptions = [
    "Artificial Intelligence", "Data Science", "Web Development",
    "Mobile Development", "Cloud Computing", "Cybersecurity",
    "Digital Marketing", "Business Strategy", "Finance",
    "Product Management", "UX/UI Design", "DevOps"
  ];

  const challengeOptions = [
    "Finding time to study", "Staying motivated", 
    "Understanding complex concepts", "Practical application",
    "Keeping up with technology", "Building confidence",
    "Networking and connections", "Career transition"
  ];

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: string, item: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field as keyof typeof prev].includes(item)
        ? (prev[field as keyof typeof prev] as string[]).filter(i => i !== item)
        : [...(prev[field as keyof typeof prev] as string[]), item]
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(formData);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const progress = ((currentStep + 1) / steps.length) * 100;
  const currentStepData = steps[currentStep];

  const renderStepContent = () => {
    switch (currentStepData.component) {
      case "goals":
        return (
          <div className="space-y-4">
            <p className="text-gray-600 mb-6">
              Select all that apply. This helps us create your personalized learning path.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {goalOptions.map((goal) => (
                <div key={goal} className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-blue-50 cursor-pointer">
                  <Checkbox
                    checked={formData.goals.includes(goal)}
                    onCheckedChange={() => toggleArrayItem("goals", goal)}
                  />
                  <label className="cursor-pointer flex-1">{goal}</label>
                </div>
              ))}
            </div>
          </div>
        );

      case "experience":
        return (
          <div className="space-y-6">
            <p className="text-gray-600">
              This helps us calibrate the difficulty level of your content.
            </p>
            <RadioGroup
              value={formData.experience}
              onValueChange={(value) => updateFormData("experience", value)}
            >
              <div className="space-y-4">
                {[
                  { value: "beginner", label: "Beginner", desc: "New to most professional skills" },
                  { value: "intermediate", label: "Intermediate", desc: "Some experience in my field" },
                  { value: "advanced", label: "Advanced", desc: "Strong foundation, looking to specialize" },
                  { value: "expert", label: "Expert", desc: "Deep expertise, seeking cutting-edge knowledge" }
                ].map((option) => (
                  <div key={option.value} className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-blue-50">
                    <RadioGroupItem value={option.value} className="mt-1" />
                    <div>
                      <Label className="font-medium">{option.label}</Label>
                      <p className="text-sm text-gray-600">{option.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>
        );

      case "skills":
        return (
          <div className="space-y-6">
            <p className="text-gray-600">
              Select your existing skills so we can build on what you already know.
            </p>
            <div>
              <Label className="text-base font-medium mb-3 block">Current Skills</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {skillOptions.map((skill) => (
                  <div key={skill} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                    <Checkbox
                      checked={formData.currentSkills.includes(skill)}
                      onCheckedChange={() => toggleArrayItem("currentSkills", skill)}
                    />
                    <label className="cursor-pointer text-sm">{skill}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-base font-medium mb-3 block">Areas of Interest</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {interestOptions.map((interest) => (
                  <div key={interest} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                    <Checkbox
                      checked={formData.interests.includes(interest)}
                      onCheckedChange={() => toggleArrayItem("interests", interest)}
                    />
                    <label className="cursor-pointer text-sm">{interest}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case "preferences":
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-base font-medium mb-3 block">Time Commitment</Label>
              <RadioGroup
                value={formData.timeCommitment}
                onValueChange={(value) => updateFormData("timeCommitment", value)}
              >
                <div className="space-y-3">
                  {[
                    { value: "15-30min", label: "15-30 minutes per day", desc: "Perfect for busy schedules" },
                    { value: "30-60min", label: "30-60 minutes per day", desc: "Balanced learning pace" },
                    { value: "1-2hours", label: "1-2 hours per day", desc: "Intensive learning" },
                    { value: "flexible", label: "Flexible schedule", desc: "I'll learn when I have time" }
                  ].map((option) => (
                    <div key={option.value} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-blue-50">
                      <RadioGroupItem value={option.value} className="mt-1" />
                      <div>
                        <Label className="font-medium">{option.label}</Label>
                        <p className="text-sm text-gray-600">{option.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label className="text-base font-medium mb-3 block">Learning Style</Label>
              <RadioGroup
                value={formData.learningStyle}
                onValueChange={(value) => updateFormData("learningStyle", value)}
              >
                <div className="space-y-3">
                  {[
                    { value: "visual", label: "Visual", desc: "Charts, diagrams, and videos" },
                    { value: "hands-on", label: "Hands-on", desc: "Interactive exercises and projects" },
                    { value: "reading", label: "Reading", desc: "Text-based content and articles" },
                    { value: "mixed", label: "Mixed", desc: "Combination of all methods" }
                  ].map((option) => (
                    <div key={option.value} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-blue-50">
                      <RadioGroupItem value={option.value} className="mt-1" />
                      <div>
                        <Label className="font-medium">{option.label}</Label>
                        <p className="text-sm text-gray-600">{option.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case "details":
        return (
          <div className="space-y-6">
            <div>
              <Label htmlFor="careerGoals" className="text-base font-medium mb-3 block">
                Career Goals (Optional)
              </Label>
              <Textarea
                id="careerGoals"
                placeholder="Tell us about your career aspirations and how we can help you get there..."
                value={formData.careerGoals}
                onChange={(e) => updateFormData("careerGoals", e.target.value)}
                className="min-h-[100px]"
              />
            </div>

            <div>
              <Label className="text-base font-medium mb-3 block">
                Current Challenges (Optional)
              </Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {challengeOptions.map((challenge) => (
                  <div key={challenge} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                    <Checkbox
                      checked={formData.challenges.includes(challenge)}
                      onCheckedChange={() => toggleArrayItem("challenges", challenge)}
                    />
                    <label className="cursor-pointer text-sm">{challenge}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-2xl">
      <CardHeader className="bg-white border-b">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-primary rounded-lg">
              <currentStepData.icon className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl text-primary">{currentStepData.title}</CardTitle>
              <p className="text-gray-600">{currentStepData.subtitle}</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-accent text-primary">
            Step {currentStep + 1} of {steps.length}
          </Badge>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Progress</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </CardHeader>

      <CardContent className="p-8">
        {renderStepContent()}

        <div className="flex justify-between items-center mt-8 pt-6 border-t">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="flex items-center"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          <div className="flex space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${
                  index <= currentStep ? 'bg-primary' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          <Button
            onClick={nextStep}
            disabled={isLoading}
            className="bg-primary text-white hover:bg-blue-800 flex items-center"
          >
            {isLoading ? (
              <>
                <Zap className="h-4 w-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : currentStep === steps.length - 1 ? (
              <>
                <Rocket className="h-4 w-4 mr-2" />
                Complete Assessment
              </>
            ) : (
              <>
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
