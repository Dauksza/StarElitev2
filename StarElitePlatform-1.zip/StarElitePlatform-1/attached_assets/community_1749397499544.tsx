
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Badge from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Users,
  MessageSquare,
  Trophy,
  Target,
  Star,
  Plus,
  Search,
  Filter,
  TrendingUp,
  Calendar,
  Award,
  Zap,
  BookOpen,
  Heart,
  MessageCircle,
  Share2,
  Crown,
  Flame,
  Clock
} from "lucide-react";
import Leaderboard from "@/components/Leaderboard";
import { Challenge } from "@/components/Challenge";

interface Discussion {
  id: number;
  title: string;
  content: string;
  author: {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    level: number;
    badge?: string;
  };
  category: string;
  tags: string[];
  replies: number;
  likes: number;
  views: number;
  createdAt: string;
  lastActivity: string;
  isPinned?: boolean;
  isHot?: boolean;
}

interface TeamChallenge {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  duration: string;
  participants: number;
  maxParticipants: number;
  startDate: string;
  endDate: string;
  prize: string;
  status: "upcoming" | "active" | "completed";
  skills: string[];
}

export default function Community() {
  const [activeTab, setActiveTab] = useState("discussions");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Mock data
  const discussions: Discussion[] = [
    {
      id: 1,
      title: "Best practices for data preprocessing in machine learning",
      content: "I've been working on a project involving customer data analysis and I'm struggling with the preprocessing phase...",
      author: {
        id: 1,
        username: "ml_enthusiast",
        firstName: "Sarah",
        lastName: "Chen",
        level: 34,
        badge: "Data Science Expert"
      },
      category: "Machine Learning",
      tags: ["data-preprocessing", "pandas", "scikit-learn"],
      replies: 23,
      likes: 45,
      views: 189,
      createdAt: "2024-01-15T10:30:00Z",
      lastActivity: "2024-01-15T15:45:00Z",
      isPinned: true,
      isHot: true
    },
    {
      id: 2,
      title: "React performance optimization techniques",
      content: "Share your favorite techniques for optimizing React applications. Let's discuss memo, useMemo, useCallback...",
      author: {
        id: 2,
        username: "react_pro",
        firstName: "Alex",
        lastName: "Johnson",
        level: 28,
        badge: "Frontend Master"
      },
      category: "Web Development",
      tags: ["react", "performance", "optimization"],
      replies: 31,
      likes: 67,
      views: 234,
      createdAt: "2024-01-14T14:20:00Z",
      lastActivity: "2024-01-15T12:30:00Z",
      isHot: true
    },
    {
      id: 3,
      title: "Career transition from backend to full-stack",
      content: "I've been working as a backend developer for 3 years and want to transition to full-stack. Any advice?",
      author: {
        id: 3,
        username: "backend_dev",
        firstName: "Michael",
        lastName: "Rodriguez",
        level: 22,
        badge: "Backend Specialist"
      },
      category: "Career",
      tags: ["career", "full-stack", "transition"],
      replies: 18,
      likes: 29,
      views: 145,
      createdAt: "2024-01-14T09:15:00Z",
      lastActivity: "2024-01-15T11:20:00Z"
    }
  ];

  const teamChallenges: TeamChallenge[] = [
    {
      id: "python-optimization",
      title: "Python Performance Championship",
      description: "Optimize a complex data processing pipeline for maximum performance. Teams compete to achieve the fastest execution time while maintaining accuracy.",
      category: "Programming",
      difficulty: "Hard",
      duration: "2 weeks",
      participants: 156,
      maxParticipants: 200,
      startDate: "2024-01-20T00:00:00Z",
      endDate: "2024-02-03T23:59:59Z",
      prize: "Certificate + $500 Amazon Gift Card",
      status: "upcoming",
      skills: ["Python", "Algorithm Optimization", "Data Structures"]
    },
    {
      id: "ml-model-battle",
      title: "ML Model Accuracy Battle",
      description: "Build the most accurate machine learning model for predicting customer churn. Real-world dataset provided.",
      category: "Machine Learning",
      difficulty: "Expert",
      duration: "3 weeks",
      participants: 89,
      maxParticipants: 150,
      startDate: "2024-01-15T00:00:00Z",
      endDate: "2024-02-05T23:59:59Z",
      prize: "Professional Certification + Industry Mentorship",
      status: "active",
      skills: ["Machine Learning", "Feature Engineering", "Model Validation"]
    },
    {
      id: "ui-design-sprint",
      title: "UI Design Sprint Challenge",
      description: "Design and prototype a mobile app interface in 5 days. Focus on user experience and modern design principles.",
      category: "Design",
      difficulty: "Medium",
      duration: "1 week",
      participants: 45,
      maxParticipants: 100,
      startDate: "2024-01-22T00:00:00Z",
      endDate: "2024-01-29T23:59:59Z",
      prize: "Design Software License + Portfolio Review",
      status: "upcoming",
      skills: ["UI Design", "Prototyping", "User Experience"]
    }
  ];

  const categories = [
    "all", "Machine Learning", "Web Development", "Data Science", 
    "Cloud Computing", "DevOps", "Mobile Development", "Career", "General"
  ];

  const filteredDiscussions = discussions.filter(discussion => {
    const matchesSearch = discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         discussion.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || discussion.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDiscussionIcon = (discussion: Discussion) => {
    if (discussion.isPinned) return <Star className="h-4 w-4 text-yellow-500" />;
    if (discussion.isHot) return <Flame className="h-4 w-4 text-red-500" />;
    return <MessageSquare className="h-4 w-4 text-gray-500" />;
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-black text-primary mb-2">
                Elite Community 🌟
              </h1>
              <p className="text-xl text-gray-600">
                Connect with top performers, share knowledge, and compete in challenges
              </p>
            </div>
            
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Start Discussion
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Start a New Discussion</DialogTitle>
                  <DialogDescription>
                    Share your knowledge or ask the community for help
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <Input placeholder="Discussion title..." />
                  <select className="w-full p-2 border rounded-md">
                    <option>Select Category</option>
                    {categories.slice(1).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                  <Textarea placeholder="What would you like to discuss?" rows={4} />
                  <Input placeholder="Tags (comma separated)" />
                  <Button className="w-full">
                    Create Discussion
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="h-6 w-6 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">12.5K</div>
                <div className="text-sm text-gray-600">Active Members</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <MessageSquare className="h-6 w-6 mx-auto mb-2 text-blue-500" />
                <div className="text-2xl font-bold">4.2K</div>
                <div className="text-sm text-gray-600">Discussions</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Target className="h-6 w-6 mx-auto mb-2 text-purple-500" />
                <div className="text-2xl font-bold">89</div>
                <div className="text-sm text-gray-600">Active Challenges</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Award className="h-6 w-6 mx-auto mb-2 text-yellow-500" />
                <div className="text-2xl font-bold">1.8K</div>
                <div className="text-sm text-gray-600">Certificates Earned</div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
            <TabsTrigger value="challenges">Team Challenges</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            <TabsTrigger value="mentorship">Mentorship</TabsTrigger>
          </TabsList>

          {/* Discussions Tab */}
          <TabsContent value="discussions" className="space-y-6">
            {/* Search and Filters */}
            <div className="flex gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search discussions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border rounded-md bg-white"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>
                    {cat === "all" ? "All Categories" : cat}
                  </option>
                ))}
              </select>
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
            </div>

            {/* Discussions List */}
            <div className="space-y-4">
              {filteredDiscussions.map((discussion) => (
                <Card key={discussion.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary text-white">
                          {discussion.author.firstName[0]}{discussion.author.lastName[0]}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getDiscussionIcon(discussion)}
                            <h3 className="font-semibold text-lg">{discussion.title}</h3>
                          </div>
                          <Badge variant="secondary">{discussion.category}</Badge>
                        </div>
                        
                        <p className="text-gray-600 mb-3 line-clamp-2">{discussion.content}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              <Avatar className="h-6 w-6">
                                <AvatarFallback className="text-xs">
                                  {discussion.author.firstName[0]}{discussion.author.lastName[0]}
                                </AvatarFallback>
                              </Avatar>
                              <span>{discussion.author.firstName} {discussion.author.lastName}</span>
                              {discussion.author.badge && (
                                <Badge variant="outline" className="text-xs">
                                  {discussion.author.badge}
                                </Badge>
                              )}
                            </div>
                            <span>•</span>
                            <span>{formatTimeAgo(discussion.createdAt)}</span>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              <Heart className="h-4 w-4" />
                              <span>{discussion.likes}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-4 w-4" />
                              <span>{discussion.replies}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <TrendingUp className="h-4 w-4" />
                              <span>{discussion.views}</span>
                            </div>
                          </div>
                        </div>
                        
                        {discussion.tags.length > 0 && (
                          <div className="flex gap-1 mt-3">
                            {discussion.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Team Challenges Tab */}
          <TabsContent value="challenges" className="space-y-6">
            <div className="grid gap-6">
              {teamChallenges.map((challenge) => (
                <Challenge 
                  key={challenge.id}
                  id={challenge.id}
                  title={challenge.title}
                  description={challenge.description}
                  type="team"
                  difficulty={challenge.difficulty.toLowerCase() as 'easy' | 'medium' | 'hard' | 'expert'}
                  timeLimit={challenge.duration}
                  points={500}
                  participants={challenge.participants}
                  maxParticipants={challenge.maxParticipants}
                  status={challenge.status === 'upcoming' ? 'available' : challenge.status === 'active' ? 'active' : 'completed'}
                  onJoin={() => console.log('Join challenge:', challenge.id)}
                  onView={() => console.log('View challenge:', challenge.id)}
                />
              ))}
            </div>
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard" className="space-y-6">
            <Leaderboard />
          </TabsContent>

          {/* Mentorship Tab */}
          <TabsContent value="mentorship" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Crown className="mr-2 h-5 w-5 text-yellow-500" />
                    Find a Mentor
                  </CardTitle>
                  <CardDescription>
                    Connect with industry experts who can guide your career growth
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <h3 className="font-semibold mb-2">Mentorship Program</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Get matched with experienced professionals in your field
                      </p>
                      <Button className="w-full">
                        Apply for Mentorship
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="mr-2 h-5 w-5 text-primary" />
                    Become a Mentor
                  </CardTitle>
                  <CardDescription>
                    Share your expertise and help others grow in their careers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center py-8">
                      <Award className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <h3 className="font-semibold mb-2">Mentor Application</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Requirements: Level 25+ and industry experience
                      </p>
                      <Button variant="outline" className="w-full">
                        Apply to be a Mentor
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
