import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Badge from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Navbar from "@/components/layout/navbar";
import { 
  Trophy, 
  Zap, 
  Target, 
  Brain, 
  Users, 
  Award,
  TrendingUp,
  BookOpen,
  MessageCircle,
  Star,
  Rocket,
  CheckCircle
} from "lucide-react";

export default function Landing() {
  const [progressValue, setProgressValue] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setProgressValue(87), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-7xl font-black leading-tight mb-6">
                Be the <span className="text-accent">Greatest</span> Version of Yourself
              </h1>
              <p className="text-xl lg:text-2xl font-light mb-8 text-blue-100">
                High-impact, zero-fluff AI-powered learning platform designed for results. 
                Powered by StarForce AI, your personal growth engine.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-accent text-primary hover:bg-accent/90 ai-glow">
                  <Link href="/register">
                    <Rocket className="mr-2 h-5 w-5" />
                    Start Your Journey
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                  Watch Demo
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl bg-white/10 backdrop-blur-sm p-8 border border-white/20">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">AI Assessment Preview</h3>
                  <Badge className="bg-accent text-primary pulse-animation">
                    🚀 AI-Powered
                  </Badge>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center text-blue-100">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-400" />
                    Current skill level detected: Intermediate
                  </div>
                  <div className="flex items-center text-blue-100">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-400" />
                    3 critical skill gaps identified
                  </div>
                  <div className="flex items-center text-blue-100">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-400" />
                    Personalized path generated in 2.3 seconds
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Python for Data Science</span>
                      <span>Priority</span>
                    </div>
                    <Progress value={progressValue} className="h-2" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Stats */}
      <section className="bg-muted py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-black text-primary mb-2">98%</div>
              <div className="text-muted-foreground font-medium">Skill Improvement</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black text-primary mb-2">50%</div>
              <div className="text-muted-foreground font-medium">Faster Learning</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black text-primary mb-2">24/7</div>
              <div className="text-muted-foreground font-medium">AI Support</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black text-primary mb-2">∞</div>
              <div className="text-muted-foreground font-medium">Adaptive Content</div>
            </div>
          </div>
        </div>
      </section>

      {/* Onboarding Preview */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              "Be the Greatest" Onboarding
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Dynamic, AI-powered onboarding that personalizes your experience instantly. 
              No tedious setups – just results from day one.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <Card className="card-hover">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-xl">1</div>
                  <h3 className="text-2xl font-bold text-primary ml-4">Tell Us Your Goals</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <input type="checkbox" defaultChecked className="w-5 h-5 text-primary" />
                    <label className="ml-3 text-foreground">Advance my career in technology</label>
                  </div>
                  <div className="flex items-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <input type="checkbox" className="w-5 h-5 text-primary" />
                    <label className="ml-3 text-foreground">Develop leadership skills</label>
                  </div>
                  <div className="flex items-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <input type="checkbox" defaultChecked className="w-5 h-5 text-primary" />
                    <label className="ml-3 text-foreground">Master data analysis</label>
                  </div>
                </div>
                <Button className="w-full bg-accent text-primary hover:bg-accent/90 mt-6">
                  Analyze My Profile →
                </Button>
              </CardContent>
            </Card>
            
            <div className="space-y-8">
              <Card className="bg-gradient-to-r from-primary to-blue-600 text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4 flex items-center">
                    <Zap className="mr-2" />
                    StarForce AI Analysis
                  </h3>
                  <div className="space-y-3 text-blue-100">
                    <p className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Current skill level detected: Intermediate
                    </p>
                    <p className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      3 critical skill gaps identified
                    </p>
                    <p className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Personalized path generated in 2.3 seconds
                    </p>
                    <p className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      87% compatibility with career goals
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-2 border-accent">
                <CardContent className="p-6">
                  <h4 className="font-bold text-primary mb-3 flex items-center">
                    <Target className="mr-2" />
                    Your Precision Learning Path
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Python for Data Science</span>
                      <Badge variant="secondary">Priority</Badge>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* StarForce AI Features */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              StarForce AI: Your Growth Engine
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Powered by Mistral.ai and cutting-edge machine learning, 
              StarForce AI personalizes every aspect of your learning journey.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-primary to-blue-700 text-white card-hover">
              <CardContent className="p-8">
                <Brain className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-bold mb-3">Intelligent Insights</h3>
                <p className="text-blue-100">Real-time performance analysis with actionable recommendations for maximum growth.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-accent to-yellow-500 text-primary card-hover">
              <CardContent className="p-8">
                <BookOpen className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-bold mb-3">Content Generation</h3>
                <p>AI creates personalized quizzes, scenarios, and challenges tailored to your skill level.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white card-hover">
              <CardContent className="p-8">
                <TrendingUp className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-bold mb-3">Predictive Analytics</h3>
                <p className="text-green-100">Forecast your learning trajectory and optimize your path to success.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Gamification Showcase */}
      <section className="bg-gradient-to-br from-gray-900 via-primary to-blue-900 py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black mb-6">
              Turn Growth Into a <span className="text-accent">Quest</span>
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Gamified progression system that makes learning addictive. 
              Earn achievements, climb leaderboards, and celebrate every victory.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Card className="bg-white text-gray-900">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-primary mb-6 flex items-center">
                    <Trophy className="mr-2" />
                    Your Achievement Vault
                  </h3>
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-accent rounded-xl">
                      <Trophy className="h-8 w-8 mb-2 mx-auto text-primary" />
                      <div className="text-xs font-semibold text-primary">Master</div>
                    </div>
                    <div className="text-center p-4 bg-secondary rounded-xl">
                      <Zap className="h-8 w-8 mb-2 mx-auto text-primary" />
                      <div className="text-xs font-semibold text-primary">Speed Runner</div>
                    </div>
                    <div className="text-center p-4 bg-green-400 rounded-xl">
                      <Star className="h-8 w-8 mb-2 mx-auto text-white" />
                      <div className="text-xs font-semibold text-white">30-Day Streak</div>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold text-primary">Level 7: Data Scientist</span>
                      <span className="text-sm text-muted-foreground">2,340 XP</span>
                    </div>
                    <Progress value={74} className="h-3 mb-1" />
                    <p className="text-xs text-muted-foreground">660 XP to Level 8</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-accent to-yellow-400 text-primary">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-bold flex items-center">
                      <Award className="mr-2" />
                      Weekly Leaderboard
                    </h3>
                    <Badge className="bg-primary text-white">Top 10%</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between bg-white bg-opacity-20 rounded-lg p-3">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">3</div>
                        <span className="font-semibold">You</span>
                      </div>
                      <span className="font-bold">1,250 pts</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-white text-gray-900">
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-black text-primary mb-2">15K+</div>
                    <div className="text-muted-foreground font-medium">Active Learners</div>
                  </CardContent>
                </Card>
                <Card className="bg-white text-gray-900">
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-black text-primary mb-2">2.3K</div>
                    <div className="text-muted-foreground font-medium">Daily Discussions</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Community Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              Join the Elite Community
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Connect with high-achievers, share insights, and accelerate your growth through 
              collaborative learning and mentorship.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Card>
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-primary mb-6 flex items-center">
                    <MessageCircle className="mr-2" />
                    High-Value Discussions
                  </h3>
                  <div className="space-y-4">
                    <div className="border-l-4 border-accent pl-4 py-2">
                      <h4 className="font-semibold text-foreground mb-1">Best practices for machine learning pipelines?</h4>
                      <p className="text-sm text-muted-foreground">12 replies • Started by DataExpert</p>
                    </div>
                    <div className="border-l-4 border-primary pl-4 py-2">
                      <h4 className="font-semibold text-foreground mb-1">Career transition from analyst to data scientist</h4>
                      <p className="text-sm text-muted-foreground">8 replies • Started by CareerChanger</p>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4 py-2">
                      <h4 className="font-semibold text-foreground mb-1">Weekly challenge: Python optimization techniques</h4>
                      <p className="text-sm text-muted-foreground">23 participants • Hosted by CodingMaster</p>
                    </div>
                  </div>
                  <Button className="w-full mt-6" asChild>
                    <Link href="/community">Join Discussion →</Link>
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-accent to-yellow-400 text-primary">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4 flex items-center">
                    <Target className="mr-2" />
                    Elite Mentorship Program
                  </h3>
                  <p className="mb-6">Get paired with industry experts and accelerate your growth through personalized guidance.</p>
                  <div className="flex items-center space-x-4">
                    <div className="flex -space-x-2">
                      <div className="w-10 h-10 bg-primary rounded-full border-2 border-white"></div>
                      <div className="w-10 h-10 bg-gray-600 rounded-full border-2 border-white"></div>
                      <div className="w-10 h-10 bg-green-600 rounded-full border-2 border-white"></div>
                    </div>
                    <span className="font-semibold">500+ Expert Mentors Available</span>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-black text-primary mb-2">15K+</div>
                  <div className="text-muted-foreground font-medium">Active Learners</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-black text-primary mb-2">2.3K</div>
                  <div className="text-muted-foreground font-medium">Daily Discussions</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="hero-gradient text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl lg:text-6xl font-black mb-6">
            Ready to Become <span className="text-accent">Unstoppable?</span>
          </h2>
          <p className="text-xl lg:text-2xl font-light mb-8 text-blue-100">
            Join thousands of high-achievers using StarElite to dominate their industries. 
            Your transformation starts now.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button size="lg" className="bg-accent text-primary px-12 py-4 text-xl ai-glow" asChild>
              <Link href="/register">
                <Rocket className="mr-2 h-6 w-6" />
                Start Your Journey
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white px-12 py-4 text-xl hover:bg-white hover:text-primary">
              Schedule Demo
            </Button>
          </div>
          <p className="text-sm text-blue-200 mt-6">
            ✓ Free 14-day trial • ✓ No credit card required • ✓ Setup in under 60 seconds
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-accent mb-4 flex items-center">
                <Star className="mr-2" />
                StarElite
              </h3>
              <p className="text-gray-300 text-sm">Supercharged Edition - The future of AI-powered learning and professional development.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-accent transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">AI Technology</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Certifications</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Integrations</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-accent transition-colors">Discussions</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Mentorship</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Events</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Success Stories</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-accent transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">API Docs</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Enterprise</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm">© 2024 StarElite Supercharged Edition. Powered by Mistral.ai. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
