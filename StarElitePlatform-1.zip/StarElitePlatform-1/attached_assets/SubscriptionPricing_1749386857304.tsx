import React from "react";

const handleSubscribe = async (priceId: string) => {
  try {
    const res = await axios.post('/api/payment/checkout-session', { priceId });
    if (res.data.url) {
      window.location.href = res.data.url;
    }
  } catch (err) {
    console.error('Error starting Stripe Checkout:', err);
    alert('Failed to start checkout. Please try again.');
  }
};

const plans = [
  { name: 'Freemium', price: '$0/mo', priceId: process.env.REACT_APP_STRIPE_PRICE_ID_FREEMIUM || 'price_xxx', features: ["Community Access", "Skill Gap Analysis", "1 Module / 30 mins daily"] },
  { name: 'Premium', price: '$15/mo', priceId: process.env.REACT_APP_STRIPE_PRICE_ID_PREMIUM || 'price_xxx', features: ["2 hrs/day lessons", "Free Exams", "Discounted Certifications", "AI Insights", "Adaptive Challenges"] },
  { name: 'Pro', price: '$45/mo', priceId: process.env.REACT_APP_STRIPE_PRICE_ID_PRO || 'price_xxx', features: ["4 hrs/day lessons", "3 Free Certifications", "Real-Time Analytics", "All Premium Features"] },
  { name: 'Enterprise', price: '$250/mo per 10 users', priceId: process.env.REACT_APP_STRIPE_PRICE_ID_ENTERPRISE || 'price_xxx', features: ["Unlimited Access", "Unlimited Certifications", "Admin Panel", "SaaS License"] },

  { name: "Freemium", price: "$0/mo", features: ["Community Access", "Skill Gap Analysis", "1 Module / 30 mins daily"] },
  { name: "Premium", price: "$15/mo", features: ["2 hrs/day lessons", "Free Exams", "Discounted Certifications", "AI Insights", "Adaptive Challenges"] },
  { name: "Pro", price: "$45/mo", features: ["4 hrs/day lessons", "3 Free Certifications", "Real-Time Analytics", "All Premium Features"] },
  { name: "Enterprise", price: "$250/mo per 10 users", features: ["Unlimited Access", "Unlimited Certifications", "Admin Panel", "SaaS License"] }
];

export default function SubscriptionPricing() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Subscription Plans</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => (
          <div key={plan.name} className="border rounded p-4 shadow">
            <h2 className="text-xl font-bold mb-2">{plan.name}</h2>
            <p className="text-lg mb-4">{plan.price}</p>
            <ul className="mb-4">
              {plan.features.map((feature) => (
                <li key={feature} className="list-disc ml-5">{feature}</li>
              ))}
            </ul>
            <button className="bg-blue-500 text-white px-4 py-2 rounded w-full">
              Subscribe
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}