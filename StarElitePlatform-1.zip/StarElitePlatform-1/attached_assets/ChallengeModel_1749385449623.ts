// Challenge model

export interface Challenge {
  id: string;
  title: string;
  description: string;
  participants: string[]; // userIds
}

let challenges: Challenge[] = [];

// CRUD operations for Challenge
export const getChallenges = (): Challenge[] => challenges;

export const addChallenge = (challenge: Challenge) => {
  challenges.push(challenge);
};

export const removeChallenge = (id: string) => {
  challenges = challenges.filter((c) => c.id !== id);
};