import { useLocation } from "wouter";
import { useEffect } from "react";
import HeroSection from "@/components/hero-section";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Zap, 
  Users, 
  Brain, 
  Target, 
  BarChart3,
  Award,
  MessageSquare,
  Rocket,
  Star,
  CheckCircle,
  ArrowRight
} from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  const stats = [
    { value: "98%", label: "Skill Improvement" },
    { value: "50%", label: "Faster Learning" },
    { value: "24/7", label: "AI Support" },
    { value: "∞", label: "Adaptive Content" }
  ];

  const features = [
    {
      icon: <Target className="h-8 w-8" />,
      title: "Precision Skill Gap Analysis",
      description: "Advanced AI analyzes your performance against industry benchmarks, identifying exact areas for improvement with surgical precision."
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Dynamic Learning Paths",
      description: "Continuously evolving curriculum that adapts to your progress, learning style, and career goals in real-time."
    },
    {
      icon: <Brain className="h-8 w-8" />,
      title: "Adaptive Training Modules",
      description: "Scenario-based simulations and adaptive quizzes that adjust difficulty and content based on your performance."
    }
  ];

  const aiCapabilities = [
    {
      icon: "🧠",
      title: "Intelligent Insights",
      description: "Real-time performance analysis with actionable recommendations for maximum growth.",
      gradient: "from-primary to-blue-700"
    },
    {
      icon: "🎨",
      title: "Content Generation",
      description: "AI creates personalized quizzes, scenarios, and challenges tailored to your skill level.",
      gradient: "from-accent to-yellow-500"
    },
    {
      icon: "📊",
      title: "Predictive Analytics",
      description: "Forecast your learning trajectory and optimize your path to success.",
      gradient: "from-green-500 to-emerald-600"
    }
  ];

  const certifications = [
    {
      title: "Data Science Master",
      description: "Advanced certification in machine learning and analytics",
      completionRate: 12,
      averageTime: "6 months",
      recognition: 5,
      color: "from-accent to-yellow-400",
      icon: "🏆"
    },
    {
      title: "Leadership Excellence",
      description: "Strategic leadership and team management skills",
      completionRate: 28,
      averageTime: "4 months",
      recognition: 4,
      color: "from-green-500 to-emerald-600",
      icon: "🚀"
    },
    {
      title: "AI & Innovation",
      description: "Cutting-edge AI implementation and innovation strategies",
      completionRate: 8,
      averageTime: "8 months",
      recognition: 5,
      color: "from-purple-500 to-indigo-600",
      icon: "⚡"
    }
  ];

  const handleGetStarted = () => {
    setLocation("/onboarding");
  };

  const handleScheduleDemo = () => {
    // This would open a demo scheduling modal or redirect to a scheduling page
    console.log("Schedule demo clicked");
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection onGetStarted={handleGetStarted} onScheduleDemo={handleScheduleDemo} />

      {/* Key Stats */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-black text-primary mb-2">{stat.value}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Onboarding Preview */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              "Be the Greatest" Onboarding
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Dynamic, AI-powered onboarding that personalizes your experience instantly. 
              No tedious setups – just results from day one.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Card className="shadow-xl card-hover">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-xl">1</div>
                    <h3 className="text-2xl font-bold text-primary ml-4">Tell Us Your Goals</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-primary" />
                      <label className="ml-3 text-gray-700">Advance my career in technology</label>
                    </div>
                    <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                      <div className="w-5 h-5 border-2 border-gray-300 rounded" />
                      <label className="ml-3 text-gray-700">Develop leadership skills</label>
                    </div>
                    <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-primary" />
                      <label className="ml-3 text-gray-700">Master data analysis</label>
                    </div>
                  </div>
                  <Button 
                    onClick={handleGetStarted}
                    className="w-full bg-accent text-primary hover:bg-yellow-400 font-bold mt-6"
                  >
                    Analyze My Profile →
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-8">
              <Card className="bg-gradient-to-r from-primary to-blue-600 text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4">⚡ StarForce AI Analysis</h3>
                  <div className="space-y-3 text-blue-100">
                    <p>✓ Current skill level detected: Intermediate</p>
                    <p>✓ 3 critical skill gaps identified</p>
                    <p>✓ Personalized path generated in 2.3 seconds</p>
                    <p>✓ 87% compatibility with career goals</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-2 border-accent">
                <CardContent className="p-6">
                  <h4 className="font-bold text-primary mb-3">🎯 Your Precision Learning Path</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Python for Data Science</span>
                      <Badge variant="secondary" className="bg-green-100 text-green-700">Priority</Badge>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="bg-gray-900 py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black mb-6">
              Your Mission Control Dashboard
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Real-time insights, adaptive content, and precision tracking. 
              Everything you need to dominate your learning journey.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Progress Card */}
            <Card className="text-gray-900 card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-primary">Weekly Progress</h3>
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-black text-primary mb-2">87%</div>
                <p className="text-sm text-gray-600 mb-4">+23% from last week</p>
                <Progress value={87} className="h-3" />
              </CardContent>
            </Card>
            
            {/* AI Insights Card */}
            <Card className="bg-gradient-to-br from-accent to-yellow-400 text-primary card-hover ai-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold">🧠 AI Insights</h3>
                  <Badge className="bg-primary text-white">Live</Badge>
                </div>
                <p className="font-semibold mb-3">"Focus on Python loops - 40% skill gap detected"</p>
                <p className="text-sm mb-4">Recommended: Complete Module 3.2 next for maximum impact</p>
                <Button className="bg-primary text-white hover:bg-blue-800">
                  Take Action →
                </Button>
              </CardContent>
            </Card>
            
            {/* Achievements Card */}
            <Card className="text-gray-900 card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-primary">🏆 Achievements</h3>
                  <Badge className="bg-accent text-primary">+3 New!</Badge>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-primary font-bold text-sm">🥇</div>
                    <span className="ml-3 text-sm font-medium">Data Master</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-primary font-bold text-sm">🥈</div>
                    <span className="ml-3 text-sm font-medium">7-Day Streak</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-orange-400 rounded-full flex items-center justify-center text-white font-bold text-sm">🥉</div>
                    <span className="ml-3 text-sm font-medium">Quiz Champion</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* StarForce AI Features */}
      <section id="platform" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              StarForce AI: Your Growth Engine
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Powered by Mistral.ai and cutting-edge machine learning, 
              StarForce AI personalizes every aspect of your learning journey.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="space-y-8">
              {features.map((feature, index) => (
                <Card key={index} className="border-l-4 border-primary shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="text-primary">{feature.icon}</div>
                      <div>
                        <h3 className="text-xl font-bold text-primary mb-3">{feature.title}</h3>
                        <p className="text-gray-600">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div>
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=700" 
                alt="Team collaboration workspace" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
          
          {/* AI Capabilities Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {aiCapabilities.map((capability, index) => (
              <Card key={index} className={`bg-gradient-to-br ${capability.gradient} text-white card-hover`}>
                <CardContent className="p-8">
                  <div className="text-4xl mb-4">{capability.icon}</div>
                  <h3 className="text-xl font-bold mb-3">{capability.title}</h3>
                  <p className="text-gray-100">{capability.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gamification Showcase */}
      <section className="bg-gradient-to-br from-gray-900 via-primary to-blue-900 py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black mb-6">
              Turn Growth Into a <span className="text-accent">Quest</span>
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Gamified progression system that makes learning addictive. 
              Earn achievements, climb leaderboards, and celebrate every victory.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=700" 
                alt="Achievement celebration" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
            <div className="space-y-8">
              {/* Achievement Showcase */}
              <Card className="text-gray-900">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-primary mb-6">🏆 Your Achievement Vault</h3>
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-accent rounded-xl">
                      <div className="text-2xl mb-2">🥇</div>
                      <div className="text-xs font-semibold text-primary">Master</div>
                    </div>
                    <div className="text-center p-4 bg-secondary rounded-xl">
                      <div className="text-2xl mb-2">⚡</div>
                      <div className="text-xs font-semibold text-primary">Speed Runner</div>
                    </div>
                    <div className="text-center p-4 bg-green-400 rounded-xl">
                      <div className="text-2xl mb-2">🔥</div>
                      <div className="text-xs font-semibold text-white">30-Day Streak</div>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold text-primary">Level 7: Data Scientist</span>
                      <span className="text-sm text-gray-600">2,340 XP</span>
                    </div>
                    <Progress value={74} className="h-3 mb-1" />
                    <p className="text-xs text-gray-600">660 XP to Level 8</p>
                  </div>
                </CardContent>
              </Card>
              
              {/* Leaderboard Preview */}
              <Card className="bg-gradient-to-r from-accent to-yellow-400 text-primary">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-bold">🏅 Weekly Leaderboard</h3>
                    <Badge className="bg-primary text-white">Top 10%</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between bg-white bg-opacity-20 rounded-lg p-3">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">3</div>
                        <span className="font-semibold">You</span>
                      </div>
                      <span className="font-bold">1,250 pts</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Community Features */}
      <section id="community" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              Join the Elite Community
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Connect with high-achievers, share insights, and accelerate your growth through 
              collaborative learning and mentorship.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              {/* Discussion Forum Preview */}
              <Card className="shadow-xl">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-primary mb-6">💬 High-Value Discussions</h3>
                  <div className="space-y-4">
                    <div className="border-l-4 border-accent pl-4 py-2">
                      <h4 className="font-semibold text-gray-900 mb-1">Best practices for machine learning pipelines?</h4>
                      <p className="text-sm text-gray-600">12 replies • Started by DataExpert</p>
                    </div>
                    <div className="border-l-4 border-primary pl-4 py-2">
                      <h4 className="font-semibold text-gray-900 mb-1">Career transition from analyst to data scientist</h4>
                      <p className="text-sm text-gray-600">8 replies • Started by CareerChanger</p>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4 py-2">
                      <h4 className="font-semibold text-gray-900 mb-1">Weekly challenge: Python optimization techniques</h4>
                      <p className="text-sm text-gray-600">23 participants • Hosted by CodingMaster</p>
                    </div>
                  </div>
                  <Button className="w-full bg-primary text-white hover:bg-blue-800 mt-6">
                    Join Discussion →
                  </Button>
                </CardContent>
              </Card>
              
              {/* Mentorship Program */}
              <Card className="bg-gradient-to-br from-accent to-yellow-400 text-primary">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4">🎯 Elite Mentorship Program</h3>
                  <p className="mb-6">Get paired with industry experts and accelerate your growth through personalized guidance.</p>
                  <div className="flex items-center space-x-4">
                    <div className="flex -space-x-2">
                      <div className="w-10 h-10 bg-primary rounded-full border-2 border-white"></div>
                      <div className="w-10 h-10 bg-gray-600 rounded-full border-2 border-white"></div>
                      <div className="w-10 h-10 bg-green-600 rounded-full border-2 border-white"></div>
                    </div>
                    <span className="font-semibold">500+ Expert Mentors Available</span>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <img 
                src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=700" 
                alt="Technology innovation" 
                className="rounded-2xl shadow-2xl mb-8"
              />
              
              {/* Community Stats */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="text-center shadow-lg">
                  <CardContent className="p-6">
                    <div className="text-3xl font-black text-primary mb-2">15K+</div>
                    <div className="text-gray-600 font-medium">Active Learners</div>
                  </CardContent>
                </Card>
                <Card className="text-center shadow-lg">
                  <CardContent className="p-6">
                    <div className="text-3xl font-black text-primary mb-2">2.3K</div>
                    <div className="text-gray-600 font-medium">Daily Discussions</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certification System */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-black text-primary mb-6">
              Expert-Level Certifications
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Earn industry-recognized certifications through AI-generated, adaptive examinations 
              that truly test your mastery.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {certifications.map((cert, index) => (
              <Card key={index} className="shadow-xl card-hover border-t-4 border-accent">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className={`w-20 h-20 bg-gradient-to-br ${cert.color} rounded-full flex items-center justify-center text-3xl font-bold mx-auto mb-4`}>
                      {cert.icon}
                    </div>
                    <h3 className="text-xl font-bold text-primary">{cert.title}</h3>
                    <p className="text-gray-600 text-sm">{cert.description}</p>
                  </div>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Completion Rate:</span>
                      <span className="font-semibold text-primary">{cert.completionRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Average Time:</span>
                      <span className="font-semibold text-primary">{cert.averageTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Industry Recognition:</span>
                      <span className="text-accent font-semibold">
                        {"★".repeat(cert.recognition)}{"☆".repeat(5 - cert.recognition)}
                      </span>
                    </div>
                  </div>
                  <Button className="w-full bg-primary text-white hover:bg-blue-800 mt-6">
                    Start Certification
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="hero-gradient text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl lg:text-6xl font-black mb-6">
            Ready to Become <span className="text-accent">Unstoppable?</span>
          </h2>
          <p className="text-xl lg:text-2xl font-light mb-8 text-blue-100">
            Join thousands of high-achievers using StarElite to dominate their industries. 
            Your transformation starts now.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button 
              onClick={handleGetStarted}
              className="bg-accent text-primary hover:bg-yellow-400 font-bold text-xl px-12 py-4 h-auto ai-glow"
            >
              🚀 Start Your Journey
            </Button>
            <Button 
              onClick={handleScheduleDemo}
              variant="outline" 
              className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold text-xl px-12 py-4 h-auto"
            >
              📞 Schedule Demo
            </Button>
          </div>
          <p className="text-sm text-blue-200 mt-6">
            ✓ Free 14-day trial • ✓ No credit card required • ✓ Setup in under 60 seconds
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-accent mb-4">⭐ StarElite</h3>
              <p className="text-gray-300 text-sm">Supercharged Edition - The future of AI-powered learning and professional development.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#features" className="hover:text-accent transition-colors">Features</a></li>
                <li><a href="#platform" className="hover:text-accent transition-colors">AI Technology</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Certifications</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Integrations</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#community" className="hover:text-accent transition-colors">Discussions</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Mentorship</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Events</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Success Stories</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-accent transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">API Docs</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Enterprise</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm">© 2024 StarElite Supercharged Edition. Powered by Mistral.ai. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
