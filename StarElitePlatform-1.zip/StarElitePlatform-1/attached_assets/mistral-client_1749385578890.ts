// Mistral Client - AI Integration Layer
// Replace 'YOUR_API_KEY' with your actual MistralAI API Key in production

import axios from 'axios';

const MISTRAL_API_BASE_URL = 'https://api.mistral.ai/v1';
const MISTRAL_API_KEY = process.env.MISTRAL_API_KEY || 'YOUR_API_KEY';

const mistralClient = axios.create({
  baseURL: MISTRAL_API_BASE_URL,
  headers: {
    'Authorization': `Bearer ${MISTRAL_API_KEY}`,
    'Content-Type': 'application/json',
  },
});

export const callChatCompletion = async (prompt: string) => {
  try {
    const response = await mistralClient.post('/chat/completions', {
      messages: [{ role: 'user', content: prompt }],
      model: 'mistral-7b-instruct', // Example model
    });
    return response.data;
  } catch (error) {
    console.error('Error calling Mistral Chat Completion:', error);
    return null;
  }
};

export const callEmbeddings = async (input: string) => {
  try {
    const response = await mistralClient.post('/embeddings', {
      input,
      model: 'mistral-embedding-model', // Example model
    });
    return response.data;
  } catch (error) {
    console.error('Error calling Mistral Embeddings:', error);
    return null;
  }
};