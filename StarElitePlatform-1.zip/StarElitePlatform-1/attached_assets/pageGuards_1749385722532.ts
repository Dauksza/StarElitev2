// Page Guards

export const canAccessFeature = (subscription: string, feature: string, certsUsed = 0) => {
  const tiers = ['Freemium', 'Premium', 'Pro', 'Enterprise'];

  const featureRequirements: { [key: string]: number } = {
    'AIInsights': 1,
    'AdaptiveChallenges': 1,
    'RealTimeAnalytics': 2,
    'Certifications': 1,
    'Exams': 1
  };

  const tierIndex = tiers.indexOf(subscription);
  const requiredTier = featureRequirements[feature] || 0;

  if (feature === 'Certifications' && subscription === 'Pro' && certsUsed >= 3) {
    return false;
  }

  return tierIndex >= requiredTier;
};