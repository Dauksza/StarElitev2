// Challenge model
export interface Challenge {
  id: string;
  name: string;
  description: string;
  teamMembers: string[];
  startDate: Date;
  endDate: Date;
  status: 'active' | 'completed' | 'upcoming';
}
