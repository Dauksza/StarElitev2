// UserController.ts

import { Request, Response } from 'express';
import { getUsers, updateUser } from '../models/UserModel';

export const getUserProgress = (req: Request, res: Response) => {
  const { userId } = req.params;
  const user = getUsers().find(u => u.id === userId);
  if (user) {
    res.json(user.courseProgress || {});
  } else {
    res.status(404).json({ message: 'User not found' });
  }
};

export const updateUserProgress = (req: Request, res: Response) => {
  const { userId, courseId } = req.params;
  const { progress } = req.body;
  const user = getUsers().find(u => u.id === userId);
  if (user) {
    if (!user.courseProgress) user.courseProgress = {};
    user.courseProgress[courseId] = progress;
    res.json({ message: 'Progress updated', progress });
  } else {
    res.status(404).json({ message: 'User not found' });
  }
};