// UserProgress model
export interface UserProgress {
  userId: string;
  completedModules: string[];
  level: number;
  experiencePoints: number;
  lastUpdated: Date;
}
