// LessonModel.ts

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  content: string; // Markdown or rich text
  version: number;
}

let lessons: Lesson[] = [];

// CRUD Operations
export const getLessons = (): Lesson[] => lessons;

export const addLesson = (lesson: Lesson) => {
  lessons.push(lesson);
};

export const getLessonsByCourseId = (courseId: string): Lesson[] =>
  lessons.filter((l) => l.courseId === courseId);