import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Star, 
  Award, 
  Target,
  Zap,
  Medal,
  Crown,
  Gem
} from "lucide-react";

interface AchievementSystemProps {
  achievements: any[];
}

export default function AchievementSystem({ achievements }: AchievementSystemProps) {
  // Sample achievement categories for display
  const achievementCategories = [
    { 
      name: "Learning", 
      icon: Target, 
      count: achievements.filter(a => a.category === "learning").length,
      color: "text-blue-500",
      bgColor: "bg-blue-50"
    },
    { 
      name: "Streak", 
      icon: Zap, 
      count: achievements.filter(a => a.category === "streak").length,
      color: "text-orange-500",
      bgColor: "bg-orange-50"
    },
    { 
      name: "Community", 
      icon: Award, 
      count: achievements.filter(a => a.category === "community").length,
      color: "text-green-500",
      bgColor: "bg-green-50"
    },
    { 
      name: "Mastery", 
      icon: Crown, 
      count: achievements.filter(a => a.category === "mastery").length,
      color: "text-purple-500",
      bgColor: "bg-purple-50"
    }
  ];

  const getRarityIcon = (rarity: string) => {
    switch (rarity) {
      case "legendary": return <Crown className="h-4 w-4 text-accent" />;
      case "epic": return <Gem className="h-4 w-4 text-purple-500" />;
      case "rare": return <Medal className="h-4 w-4 text-blue-500" />;
      default: return <Star className="h-4 w-4 text-gray-500" />;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "legendary": return "bg-accent text-primary";
      case "epic": return "bg-purple-100 text-purple-800";
      case "rare": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-accent" />
          Achievements
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Achievement Categories */}
        <div className="grid grid-cols-2 gap-3">
          {achievementCategories.map((category) => (
            <div key={category.name} className={`p-3 rounded-lg ${category.bgColor}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <category.icon className={`h-4 w-4 ${category.color}`} />
                  <span className="text-sm font-medium">{category.name}</span>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {category.count}
                </Badge>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Achievements */}
        {achievements.length > 0 ? (
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900">Recent Achievements</h4>
            <div className="space-y-3">
              {achievements.slice(0, 3).map((achievement) => (
                <div key={achievement.id} className="p-3 border rounded-lg card-hover">
                  <div className="flex items-center space-x-3">
                    <div className="text-2xl">{achievement.icon || "🏆"}</div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h5 className="font-semibold text-sm">{achievement.name}</h5>
                        {getRarityIcon(achievement.rarity)}
                      </div>
                      <p className="text-xs text-gray-600">{achievement.description}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge 
                          variant="secondary" 
                          className={`text-xs ${getRarityColor(achievement.rarity)}`}
                        >
                          {achievement.rarity}
                        </Badge>
                        <span className="text-xs text-gray-500">+{achievement.points} XP</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {achievements.length > 3 && (
                <Button variant="outline" size="sm" className="w-full">
                  View All Achievements ({achievements.length})
                </Button>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h4 className="font-semibold text-gray-600 mb-2">No achievements yet</h4>
            <p className="text-gray-500 text-sm mb-4">
              Complete activities and reach milestones to earn your first achievement!
            </p>
            
            {/* Sample upcoming achievements */}
            <div className="text-left space-y-2">
              <h5 className="font-medium text-gray-700 text-sm">Upcoming Achievements:</h5>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="text-lg">🎯</div>
                    <span>First Steps</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Progress value={0} className="w-12 h-1" />
                    <span className="text-xs text-gray-500">0/1</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="text-lg">⚡</div>
                    <span>Quick Learner</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Progress value={0} className="w-12 h-1" />
                    <span className="text-xs text-gray-500">0/3</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="text-lg">🔥</div>
                    <span>Streak Master</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Progress value={0} className="w-12 h-1" />
                    <span className="text-xs text-gray-500">0/7</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
