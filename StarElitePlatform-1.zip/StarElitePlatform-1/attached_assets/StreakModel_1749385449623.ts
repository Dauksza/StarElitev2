// Streak model

export interface Streak {
  userId: string;
  days: number;
}

let streaks: Streak[] = [];

// CRUD operations for Streak
export const getStreaks = (): Streak[] => streaks;

export const updateStreak = (streak: Streak) => {
  const index = streaks.findIndex((s) => s.userId === streak.userId);
  if (index >= 0) {
    streaks[index] = streak;
  } else {
    streaks.push(streak);
  }
};