import React, { useEffect, useState } from "react";
import axios from "axios";

export default function AdaptiveChallengesPage() {
  const [challenges, setChallenges] = useState("Loading adaptive challenges...");

  useEffect(() => {
    const fetchChallenges = async () => {
      const res = await axios.get("/api/ai/adaptive-challenges");
      setChallenges(res.data.result);
    };
    fetchChallenges();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Adaptive Challenges</h1>
      <p>{challenges}</p>
    </div>
  );
}