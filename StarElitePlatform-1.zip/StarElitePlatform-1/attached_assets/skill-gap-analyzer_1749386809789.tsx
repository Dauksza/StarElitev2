import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ProgressBar } from "./ProgressBar.tsx";
import { 
  Target, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  Brain,
  Zap,
  ArrowRight,
  BarChart3,
  BookOpen,
  Clock,
  Star
} from "lucide-react";

interface SkillGap {
  id: string;
  skill: string;
  currentLevel: number;
  targetLevel: number;
  importance: 'high' | 'medium' | 'low';
  category: string;
  estimatedTimeToClose: number;
  recommendedActions: string[];
}

interface SkillAssessment {
  skill: string;
  selfRating: number;
  marketDemand: number;
  futureGrowth: number;
  currentTrend: 'rising' | 'stable' | 'declining';
}

export default function SkillGapAnalyzer() {
  const [currentRole, setCurrentRole] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [careerGoals, setCareerGoals] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const skillGaps: SkillGap[] = [
    {
      id: 'cloud-architecture',
      skill: 'Cloud Architecture',
      currentLevel: 4,
      targetLevel: 8,
      importance: 'high',
      category: 'Technical',
      estimatedTimeToClose: 6,
      recommendedActions: [
        'Complete AWS Solutions Architect certification',
        'Build 3 cloud-native applications',
        'Study microservices patterns'
      ]
    },
    {
      id: 'machine-learning',
      skill: 'Machine Learning',
      currentLevel: 2,
      targetLevel: 7,
      importance: 'high',
      category: 'Technical',
      estimatedTimeToClose: 12,
      recommendedActions: [
        'Complete ML specialization course',
        'Work on 5 ML projects',
        'Learn TensorFlow and PyTorch'
      ]
    },
    {
      id: 'leadership',
      skill: 'Team Leadership',
      currentLevel: 5,
      targetLevel: 8,
      importance: 'medium',
      category: 'Soft Skills',
      estimatedTimeToClose: 8,
      recommendedActions: [
        'Lead a cross-functional project',
        'Take management training course',
        'Find a leadership mentor'
      ]
    },
    {
      id: 'product-strategy',
      skill: 'Product Strategy',
      currentLevel: 3,
      targetLevel: 7,
      importance: 'medium',
      category: 'Business',
      estimatedTimeToClose: 10,
      recommendedActions: [
        'Study product management frameworks',
        'Analyze competitor strategies',
        'Work with product teams'
      ]
    }
  ];

  const skillAssessments: SkillAssessment[] = [
    {
      skill: 'Python Programming',
      selfRating: 8,
      marketDemand: 9,
      futureGrowth: 8,
      currentTrend: 'rising'
    },
    {
      skill: 'React Development',
      selfRating: 7,
      marketDemand: 8,
      futureGrowth: 7,
      currentTrend: 'stable'
    },
    {
      skill: 'DevOps',
      selfRating: 5,
      marketDemand: 9,
      futureGrowth: 9,
      currentTrend: 'rising'
    },
    {
      skill: 'Data Science',
      selfRating: 6,
      marketDemand: 8,
      futureGrowth: 9,
      currentTrend: 'rising'
    }
  ];

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsAnalyzing(false);
    setAnalysisComplete(true);
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'rising': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'stable': return <ArrowRight className="h-4 w-4 text-blue-500" />;
      case 'declining': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return null;
    }
  };

  const calculateGapPercentage = (current: number, target: number) => {
    return Math.round(((target - current) / target) * 100);
  };

  return (
    <div className="space-y-6">
      {!analysisComplete ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-6 w-6 mr-3" />
              AI-Powered Skill Gap Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Current Role</Label>
                <Textarea
                  placeholder="Describe your current role and responsibilities..."
                  value={currentRole}
                  onChange={(e) => setCurrentRole(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label>Target Role</Label>
                <Textarea
                  placeholder="What role are you aspiring to reach?"
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value)}
                  rows={3}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Career Goals & Timeline</Label>
              <Textarea
                placeholder="What are your career goals and when do you want to achieve them?"
                value={careerGoals}
                onChange={(e) => setCareerGoals(e.target.value)}
                rows={4}
              />
            </div>

            <Button 
              onClick={handleAnalyze}
              disabled={isAnalyzing || !currentRole || !targetRole}
              className="w-full"
              size="lg"
            >
              {isAnalyzing ? (
                <>
                  <Brain className="h-5 w-5 mr-2 animate-spin" />
                  Analyzing with StarForce AI...
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5 mr-2" />
                  Analyze My Skill Gaps
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="gaps" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="gaps">Skill Gaps</TabsTrigger>
            <TabsTrigger value="assessment">Market Analysis</TabsTrigger>
            <TabsTrigger value="roadmap">Learning Roadmap</TabsTrigger>
          </TabsList>

          <TabsContent value="gaps" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Critical Skill Gaps Identified
                  </span>
                  <Badge variant="outline">{skillGaps.length} gaps found</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillGaps.map((gap) => (
                    <div key={gap.id} className="p-4 border rounded-lg space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h3 className="font-semibold text-lg">{gap.skill}</h3>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{gap.category}</Badge>
                            <Badge className={getImportanceColor(gap.importance)}>
                              {gap.importance} priority
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-muted-foreground">Gap Size</div>
                          <div className="text-2xl font-bold text-red-500">
                            {calculateGapPercentage(gap.currentLevel, gap.targetLevel)}%
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Current Level: {gap.currentLevel}/10</span>
                          <span>Target Level: {gap.targetLevel}/10</span>
                        </div>
                        <div className="relative">
                          <ProgressBar 
                            progress={(gap.currentLevel / 10) * 100}
                            height="h-3"
                            className="w-full"
                          />
                          <div 
                            className="absolute top-0 h-3 bg-red-200 rounded-r-full"
                            style={{ 
                              left: `${(gap.currentLevel / 10) * 100}%`,
                              width: `${((gap.targetLevel - gap.currentLevel) / 10) * 100}%`
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-medium">Recommended Actions:</Label>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="h-4 w-4 mr-1" />
                            {gap.estimatedTimeToClose} months to close
                          </div>
                        </div>
                        <ul className="space-y-1">
                          {gap.recommendedActions.map((action, index) => (
                            <li key={index} className="flex items-start text-sm">
                              <CheckCircle className="h-4 w-4 mr-2 mt-0.5 text-green-500 flex-shrink-0" />
                              {action}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <Button variant="outline" className="w-full">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Create Learning Path for {gap.skill}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Market Demand Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {skillAssessments.map((assessment, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">{assessment.skill}</h3>
                        <div className="flex items-center space-x-2">
                          {getTrendIcon(assessment.currentTrend)}
                          <span className="text-sm capitalize">{assessment.currentTrend}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Your Level</div>
                          <div className="text-2xl font-bold text-blue-500">{assessment.selfRating}/10</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Market Demand</div>
                          <div className="text-2xl font-bold text-green-500">{assessment.marketDemand}/10</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Future Growth</div>
                          <div className="text-2xl font-bold text-purple-500">{assessment.futureGrowth}/10</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Market Readiness</span>
                          <span>{Math.round((assessment.selfRating / assessment.marketDemand) * 100)}%</span>
                        </div>
                        <ProgressBar 
                          progress={(assessment.selfRating / assessment.marketDemand) * 100}
                          height="h-2"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="roadmap" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2" />
                  Personalized Learning Roadmap
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h3 className="font-semibold text-blue-900 mb-2">Phase 1: Foundation (Months 1-3)</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center">
                          <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                          Complete Cloud Fundamentals course
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          AWS Certified Solutions Architect
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Build first cloud application
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <h3 className="font-semibold text-yellow-900 mb-2">Phase 2: Practice (Months 4-6)</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Advanced ML algorithms course
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Complete 3 ML projects
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Leadership training program
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-green-50 rounded-lg">
                      <h3 className="font-semibold text-green-900 mb-2">Phase 3: Mastery (Months 7-9)</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Lead cross-functional project
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Advanced cloud architecture
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Product strategy certification
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-purple-50 rounded-lg">
                      <h3 className="font-semibold text-purple-900 mb-2">Phase 4: Excellence (Months 10-12)</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Mentor junior developers
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Contribute to open source
                        </li>
                        <li className="flex items-center">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded mr-2"></div>
                          Speak at tech conferences
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="text-center">
                    <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                      <BookOpen className="h-5 w-5 mr-2" />
                      Start My Learning Journey
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}