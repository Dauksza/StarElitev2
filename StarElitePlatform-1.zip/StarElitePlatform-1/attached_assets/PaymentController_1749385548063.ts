// PaymentController.ts - Stripe Webhook Endpoint (Placeholder)

import { Request, Response } from 'express';

export const stripeWebhook = (req: Request, res: Response) => {
  // NOTE: Replace this with full Stripe webhook handling logic
  console.log('Stripe webhook received:', req.body);
  res.json({ received: true });
};

import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2022-11-15' });

export const createCheckoutSession = async (req: Request, res: Response) => {
  const { priceId } = req.body;
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: (process.env.FRONTEND_URL || 'http://localhost:3000') + '/subscription-success',
      cancel_url: (process.env.FRONTEND_URL || 'http://localhost:3000') + '/subscription-cancel',
    });
    res.json({ url: session.url });
  } catch (error: any) {
    console.error('Error creating Stripe Checkout Session:', error);
    res.status(500).json({ error: error.message });
  }
};