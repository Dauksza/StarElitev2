import React from "react";

interface ChallengeProps {
  title: string;
  description: string;
  participants: string[];
}

export default function Challenge({ title, description, participants }: ChallengeProps) {
  return (
    <div className="border p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-2">{title}</h2>
      <p className="mb-2">{description}</p>
      <h3 className="font-semibold">Participants:</h3>
      <ul className="list-disc pl-5">
        {participants.map((p, i) => (
          <li key={i}>{p}</li>
        ))}
      </ul>
    </div>
  );
}