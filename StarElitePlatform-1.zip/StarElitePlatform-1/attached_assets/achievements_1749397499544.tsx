
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Badge from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy,
  Medal,
  Star,
  Target,
  Zap,
  Crown,
  Award,
  Lock,
  CheckCircle
} from "lucide-react";

export default function Achievements() {
  const { data: achievements = [] } = useQuery({
    queryKey: ["/api/achievements"],
  });

  const { data: userProgress = {} } = useQuery({
    queryKey: ["/api/user/achievements"],
  });

  const categories = {
    learning: { icon: BookOpen, color: "bg-blue-500", name: "Learning" },
    social: { icon: Users, color: "bg-green-500", name: "Social" },
    mastery: { icon: Crown, color: "bg-purple-500", name: "Mastery" },
    streak: { icon: Flame, color: "bg-orange-500", name: "Streak" }
  };

  const earnedAchievements = achievements.filter(a => userProgress[a.id]?.earned);
  const lockedAchievements = achievements.filter(a => !userProgress[a.id]?.earned);

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-primary mb-2">
            🏆 Achievements
          </h1>
          <p className="text-xl text-gray-600">
            Track your learning milestones and unlock rewards
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {Object.entries(categories).map(([key, category]) => {
            const Icon = category.icon;
            const categoryAchievements = achievements.filter(a => a.category === key);
            const earned = categoryAchievements.filter(a => userProgress[a.id]?.earned).length;
            
            return (
              <Card key={key} className="text-center">
                <CardContent className="p-6">
                  <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{category.name}</h3>
                  <p className="text-2xl font-bold text-primary">{earned}/{categoryAchievements.length}</p>
                  <Progress value={(earned / categoryAchievements.length) * 100} className="mt-2" />
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="earned" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="earned">Earned ({earnedAchievements.length})</TabsTrigger>
            <TabsTrigger value="locked">Locked ({lockedAchievements.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="earned" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {earnedAchievements.map((achievement) => (
                <Card key={achievement.id} className="border-2 border-yellow-200 bg-yellow-50">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <Trophy className="h-10 w-10 text-yellow-800" />
                    </div>
                    <CardTitle className="text-xl">{achievement.title}</CardTitle>
                    <p className="text-gray-600">{achievement.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <Badge className="bg-yellow-200 text-yellow-800">
                        <Star className="h-4 w-4 mr-1" />
                        {achievement.points} XP
                      </Badge>
                      <span className="text-sm text-gray-500">
                        Earned {new Date(userProgress[achievement.id]?.earnedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="locked" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lockedAchievements.map((achievement) => (
                <Card key={achievement.id} className="border-2 border-gray-200 bg-gray-50">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 bg-gray-300 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Lock className="h-10 w-10 text-gray-600" />
                    </div>
                    <CardTitle className="text-xl text-gray-600">{achievement.title}</CardTitle>
                    <p className="text-gray-500">{achievement.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userProgress[achievement.id]?.progress && (
                        <div>
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{userProgress[achievement.id].progress}/{achievement.requirement}</span>
                          </div>
                          <Progress 
                            value={(userProgress[achievement.id].progress / achievement.requirement) * 100} 
                            className="mt-1"
                          />
                        </div>
                      )}
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">
                          <Star className="h-4 w-4 mr-1" />
                          {achievement.points} XP
                        </Badge>
                        <span className="text-sm text-gray-500">
                          {achievement.category}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
