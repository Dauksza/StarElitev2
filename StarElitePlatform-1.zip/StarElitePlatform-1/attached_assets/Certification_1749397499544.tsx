import React, { useEffect, useState } from "react";
import axios from "axios";

export default function CertificationPage() {
  const [content, setContent] = useState("Loading certification content...");
  const [examResult, setExamResult] = useState("");

  useEffect(() => {
    const fetchContent = async () => {
      const res = await axios.get("/api/certification/content");
      setContent(res.data.result);
    };
    fetchContent();
  }, []);

  const handleExamSubmit = async () => {
    const res = await axios.post("/api/certification/exam");
    setExamResult(res.data.result);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Certification</h1>
      <p className="mb-4">{content}</p>
      <button onClick={handleExamSubmit} className="bg-blue-500 text-white px-4 py-2 rounded mb-4">
        Submit Exam
      </button>
      {examResult && <p>{examResult}</p>}
    </div>
  );
}