import React, { useEffect, useState } from "react";
import axios from "axios";

export default function AdminPage() {
  const [users, setUsers] = useState([]);

  const fetchUsers = async () => {
    const res = await axios.get("/api/admin/users");
    setUsers(res.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
      <table className="w-full text-left">
        <thead>
          <tr>
            <th>Email</th>
            <th>Subscription</th>
            <th>Progress</th>
            <th>Streak</th>
            <th>Admin</th><th>Stripe Customer ID</th><th>Subscription Status</th><th>Lessons Used Today</th><th>Certs Used</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user: any) => (
            <tr key={user.id}>
              <td>{user.email}</td>
              <td>{user.subscription}</td>
              <td>{user.progress}%</td>
              <td>{user.streak}</td>
              <td>{user.isAdmin ? "Yes" : "No"}</td><td>{user.stripeCustomerId || '-'}</td><td>{user.subscriptionStatus || '-'}<td>{user.lessonsUsedToday || 0}</td><td>{user.certsUsed || 0}</td></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}