import { apiRequest } from "./queryClient.ts";

export const api = {
  // Authentication
  register: async (userData: any) => {
    const response = await apiRequest("POST", "/api/auth/register", userData);
    return response.json();
  },

  login: async (credentials: { email: string; password: string }) => {
    const response = await apiRequest("POST", "/api/auth/login", credentials);
    return response.json();
  },

  // User Profile
  getUserProfile: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/profile`);
    return response.json();
  },

  updateUserProfile: async (userId: number, updates: any) => {
    const response = await apiRequest("PUT", `/api/users/${userId}/profile`, updates);
    return response.json();
  },

  // AI Services
  onboardingAssessment: async (data: any) => {
    const response = await apiRequest("POST", "/api/ai/onboarding-assessment", data);
    return response.json();
  },

  skillGapAnalysis: async (data: any) => {
    const response = await apiRequest("POST", "/api/ai/skill-gap-analysis", data);
    return response.json();
  },

  generateLearningPath: async (data: any) => {
    const response = await apiRequest("POST", "/api/ai/generate-learning-path", data);
    return response.json();
  },

  generateTrainingModule: async (data: any) => {
    const response = await apiRequest("POST", "/api/ai/generate-training-module", data);
    return response.json();
  },

  getPerformanceInsights: async (data: any) => {
    const response = await apiRequest("POST", "/api/ai/performance-insights", data);
    return response.json();
  },

  // Dashboard
  getDashboardData: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/dashboard`);
    return response.json();
  },

  // Progress
  getUserProgress: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/progress`);
    return response.json();
  },

  createUserProgress: async (userId: number, progressData: any) => {
    const response = await apiRequest("POST", `/api/users/${userId}/progress`, progressData);
    return response.json();
  },

  // Learning Paths
  getUserLearningPaths: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/learning-paths`);
    return response.json();
  },

  // Achievements
  getUserAchievements: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/achievements`);
    return response.json();
  },

  // Discussions
  getDiscussions: async (category?: string) => {
    const url = category ? `/api/discussions?category=${category}` : "/api/discussions";
    const response = await apiRequest("GET", url);
    return response.json();
  },

  getDiscussion: async (id: number) => {
    const response = await apiRequest("GET", `/api/discussions/${id}`);
    return response.json();
  },

  createDiscussion: async (discussionData: any) => {
    const response = await apiRequest("POST", "/api/discussions", discussionData);
    return response.json();
  },

  // Challenges
  getChallenges: async () => {
    const response = await apiRequest("GET", "/api/challenges");
    return response.json();
  },

  getUserChallenges: async (userId: number) => {
    const response = await apiRequest("GET", `/api/users/${userId}/challenges`);
    return response.json();
  },

  joinChallenge: async (userId: number, challengeId: number) => {
    const response = await apiRequest("POST", `/api/users/${userId}/challenges/${challengeId}/join`);
    return response.json();
  },

  // Leaderboard
  getLeaderboard: async (timeframe?: string) => {
    const url = timeframe ? `/api/leaderboard?timeframe=${timeframe}` : "/api/leaderboard";
    const response = await apiRequest("GET", url);
    return response.json();
  },
};
