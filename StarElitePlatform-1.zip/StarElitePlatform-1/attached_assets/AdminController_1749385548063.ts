// AdminController.ts

import { Request, Response } from 'express';
import { getUsers, updateUser, resetUserPassword } from '../models/UserModel';

export const listUsers = (req: Request, res: Response) => {
  res.json(getUsers());
};

export const updateUserSubscription = (req: Request, res: Response) => {
  const { id } = req.params;
  const { subscription } = req.body;
  const updated = updateUser(id, { subscription });
  res.json({ updated });
};

export const resetPassword = async (req: Request, res: Response) => {
  const { id } = req.params;
  const { newPassword } = req.body;
  const updated = await resetUserPassword(id, newPassword);
  res.json({ updated });
};

export const updateUserProgress = (req: Request, res: Response) => {
  const { id } = req.params;
  const { progress, streak } = req.body;
  const updated = updateUser(id, { progress, streak });
  res.json({ updated });
};

export const updateStripeInfo = (req: Request, res: Response) => {
  const { id } = req.params;
  const { stripeCustomerId, subscriptionStatus } = req.body;
  const updated = updateUser(id, { stripeCustomerId, subscriptionStatus });
  res.json({ updated });
};

export const updateUserLimits = (req: Request, res: Response) => {
  const { id } = req.params;
  const { lessonsUsedToday, lessonsLastUsedDate, certsUsed } = req.body;
  const updated = updateUser(id, { lessonsUsedToday, lessonsLastUsedDate, certsUsed });
  res.json({ updated });
};