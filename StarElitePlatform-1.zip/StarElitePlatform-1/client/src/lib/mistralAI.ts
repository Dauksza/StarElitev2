interface MistralMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface MistralResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: MistralMessage;
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

const MISTRAL_API_KEY = import.meta.env.VITE_MISTRAL_API_KEY;
const MISTRAL_BASE_URL = "https://api.mistral.ai/v1";

export class MistralAI {
  private apiKey: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || MISTRAL_API_KEY || "";
    if (!this.apiKey) {
      console.warn("Mistral API key not found. AI features will use mock data.");
    }
  }

  async generateContent(prompt: string, options: {
    model?: string;
    temperature?: number;
    maxTokens?: number;
  } = {}): Promise<string> {
    // Always use mock responses for now to avoid API costs during development
    return this.getMockResponse(prompt);
  }

  private getMockResponse(prompt: string): string {
    // Provide contextual mock responses based on prompt content
    if (prompt.includes('skill gap') || prompt.includes('analysis')) {
      return JSON.stringify({
        skillGaps: [
          { skill: "Advanced JavaScript", currentLevel: 6, targetLevel: 9, priority: "High" },
          { skill: "React Performance", currentLevel: 4, targetLevel: 8, priority: "High" },
          { skill: "System Design", currentLevel: 3, targetLevel: 7, priority: "Medium" },
          { skill: "Leadership", currentLevel: 5, targetLevel: 8, priority: "Low" }
        ],
        recommendations: [
          {
            title: "JavaScript Mastery Path",
            description: "Deep dive into advanced JavaScript concepts including closures, prototypes, and async programming",
            estimatedTime: "4 weeks",
            resources: ["MDN JavaScript Guide", "JavaScript.info", "You Don't Know JS series"]
          },
          {
            title: "React Performance Optimization",
            description: "Learn React performance optimization techniques and profiling",
            estimatedTime: "3 weeks",
            resources: ["React Performance Course", "React Profiler Documentation"]
          }
        ],
        overallReadiness: 65
      });
    }

    if (prompt.includes('learning path') || prompt.includes('curriculum')) {
      return JSON.stringify({
        title: "Personalized Learning Path",
        description: "AI-generated curriculum tailored to your goals and experience level",
        duration: "8-12 weeks",
        difficulty: "Intermediate",
        modules: [
          { 
            title: "Fundamentals Review", 
            duration: "2 weeks",
            topics: ["Core concepts", "Best practices", "Common patterns"]
          },
          { 
            title: "Intermediate Concepts", 
            duration: "3 weeks",
            topics: ["Advanced techniques", "Performance optimization", "Testing strategies"]
          },
          { 
            title: "Advanced Applications", 
            duration: "4 weeks",
            topics: ["Real-world projects", "System design", "Architecture patterns"]
          }
        ]
      });
    }

    if (prompt.includes('quiz') || prompt.includes('questions')) {
      return JSON.stringify([
        {
          id: 1,
          question: "What is the main purpose of React hooks?",
          options: [
            "To replace class components entirely",
            "To manage state and side effects in functional components",
            "To improve performance of React applications",
            "To handle routing in React applications"
          ],
          correct: 1,
          explanation: "React hooks allow you to use state and other React features in functional components without writing a class."
        },
        {
          id: 2,
          question: "Which hook is used for side effects in React?",
          options: ["useState", "useEffect", "useContext", "useReducer"],
          correct: 1,
          explanation: "useEffect is the hook used to perform side effects in functional components."
        }
      ]);
    }

    return "This is a mock AI response. The Mistral AI integration is working with sample data for development purposes.";
  }

  async analyzeSkillGap(data: {
    currentSkills: string[];
    targetRole: string;
    experience: string;
  }): Promise<any> {
    const prompt = `Analyze the skill gap for someone with ${data.experience} experience, 
    current skills: ${data.currentSkills.join(', ')}, 
    targeting role: ${data.targetRole}. 
    Provide specific skill gaps and learning recommendations in JSON format.`;

    const response = await this.generateContent(prompt);

    try {
      return JSON.parse(response);
    } catch {
      return {
        skillGaps: [
          { skill: "Advanced JavaScript", currentLevel: 6, targetLevel: 9, priority: "High" },
          { skill: "System Design", currentLevel: 3, targetLevel: 7, priority: "Medium" }
        ],
        recommendations: [
          {
            title: "JavaScript Advanced Concepts",
            description: "Master closures, prototypes, and async programming",
            estimatedTime: "4 weeks",
            resources: ["MDN JavaScript Guide"]
          }
        ],
        overallReadiness: 65,
        analysis: response
      };
    }
  }

  async generateLearningPath(goals: string[], level: string, timeCommitment: string): Promise<any> {
    const prompt = `Create a personalized learning path for goals: ${goals.join(', ')}, 
    skill level: ${level}, time commitment: ${timeCommitment}. 
    Return structured JSON with modules, timeline, and resources.`;

    const response = await this.generateContent(prompt);

    try {
      return JSON.parse(response);
    } catch {
      return {
        title: `${goals.join(' & ')} Learning Path`,
        description: "AI-generated learning curriculum",
        duration: timeCommitment === "intensive" ? "8 weeks" : "12 weeks",
        difficulty: level,
        modules: [
          {
            title: "Fundamentals",
            duration: "2 weeks",
            topics: ["Core concepts", "Basic patterns"]
          }
        ],
        timeline: timeCommitment,
        analysis: response
      };
    }
  }

  async generateQuizQuestions(topic: string, difficulty: string, count: number = 5): Promise<any[]> {
    const prompt = `Generate ${count} ${difficulty} level quiz questions about ${topic}. 
    Return JSON array with question, options, and correct answer.`;

    const response = await this.generateContent(prompt);

    try {
      const questions = JSON.parse(response);
      return Array.isArray(questions) ? questions : [];
    } catch {
      return Array.from({ length: count }, (_, i) => ({
        id: i + 1,
        question: `Sample ${difficulty} question ${i + 1} about ${topic}`,
        options: ["Option A", "Option B", "Option C", "Option D"],
        correct: 0,
        explanation: `This is a sample ${difficulty} level question about ${topic} for development purposes.`
      }));
    }
  }
}

export const mistralAI = new MistralAI();