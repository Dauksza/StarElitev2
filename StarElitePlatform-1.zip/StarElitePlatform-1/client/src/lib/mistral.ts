// Mistral.ai API integration
const MISTRAL_API_KEY = import.meta.env.VITE_MISTRAL_API_KEY || "";
const MISTRAL_API_URL = "https://api.mistral.ai/v1";

interface MistralMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface MistralResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: MistralMessage;
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

class MistralService {
  private apiKey: string;

  constructor(apiKey: string = MISTRAL_API_KEY) {
    this.apiKey = apiKey;
    if (!this.apiKey) {
      console.warn("Mistral API key not found. AI features will use server-side processing.");
    }
  }

  async chatCompletion(messages: MistralMessage[], model: string = "mistral-small-latest"): Promise<MistralResponse> {
    if (!this.apiKey) {
      throw new Error("Mistral API key is required for client-side calls");
    }

    const response = await fetch(`${MISTRAL_API_URL}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Mistral API error: ${response.status} ${response.statusText} ${JSON.stringify(errorData)}`);
    }

    return response.json();
  }

  async generateSkillAssessment(userGoals: string[], currentSkills: string, experience: string) {
    const systemPrompt = `You are StarForce AI, an expert learning assessment system. Analyze the user's goals, current skills, and experience to provide a comprehensive skill gap analysis and personalized recommendations.

Respond with a JSON object containing:
- gapAnalysis: { strengths: string[], weaknesses: string[], criticalGaps: string[] }
- recommendations: { skill: string, priority: 'high'|'medium'|'low', estimatedTime: string, reason: string }[]
- skillLevel: 'beginner'|'intermediate'|'advanced'
- confidenceScore: number (0-1)

Be specific and actionable in your recommendations.`;

    const userPrompt = `User Goals: ${userGoals.join(", ")}
Current Skills: ${currentSkills}
Experience Level: ${experience}

Please analyze my profile and provide detailed skill gap analysis and recommendations.`;

    const response = await this.chatCompletion([
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]);

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from Mistral AI");
    }

    try {
      return JSON.parse(content);
    } catch (error) {
      console.error("Failed to parse Mistral response:", content);
      throw new Error("Invalid response format from AI");
    }
  }

  async generateLearningPath(assessment: any, userGoals: string[]) {
    const systemPrompt = `You are StarForce AI, an expert learning path designer. Create a personalized, sequential learning path based on the user's skill assessment and goals.

Respond with a JSON object containing:
- title: string
- description: string
- estimatedDuration: number (total hours)
- difficulty: 'beginner'|'intermediate'|'advanced'
- modules: { 
    id: number, 
    title: string, 
    description: string,
    type: 'lesson'|'quiz'|'challenge'|'project',
    duration: number (minutes),
    difficulty: string,
    prerequisites: number[]
  }[]

Focus on practical, skill-building modules that align with the user's goals and address identified gaps.`;

    const userPrompt = `Based on this assessment:
${JSON.stringify(assessment, null, 2)}

User Goals: ${userGoals.join(", ")}

Create an optimal learning path that addresses the identified skill gaps and helps achieve the stated goals.`;

    const response = await this.chatCompletion([
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]);

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from Mistral AI");
    }

    try {
      return JSON.parse(content);
    } catch (error) {
      console.error("Failed to parse Mistral response:", content);
      throw new Error("Invalid response format from AI");
    }
  }

  async generatePerformanceInsight(userId: number, performanceData: any, userHistory: any) {
    const systemPrompt = `You are StarForce AI, an expert performance analyst. Analyze user performance data and provide actionable insights and recommendations.

Respond with a JSON object containing:
- insight: string (main insight about performance)
- strengths: string[] (areas where user is excelling)
- improvements: string[] (specific areas needing attention)
- recommendations: { action: string, priority: 'high'|'medium'|'low', estimatedImpact: string }[]
- nextBestAction: string (single most important next step)
- confidenceLevel: number (0-1)

Provide specific, actionable feedback that helps the user improve.`;

    const userPrompt = `Analyze this performance data:
${JSON.stringify(performanceData, null, 2)}

User History:
${JSON.stringify(userHistory, null, 2)}

Provide detailed performance insights and recommendations for improvement.`;

    const response = await this.chatCompletion([
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]);

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from Mistral AI");
    }

    try {
      return JSON.parse(content);
    } catch (error) {
      console.error("Failed to parse Mistral response:", content);
      throw new Error("Invalid response format from AI");
    }
  }
}

export const mistralService = new MistralService();
export default MistralService;
