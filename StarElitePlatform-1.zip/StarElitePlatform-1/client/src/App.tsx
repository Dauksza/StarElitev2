import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Onboarding from "@/pages/onboarding";
import SkillGapAnalysis from "@/pages/skill-gap-analysis";
import LearningPaths from "./pages/learning-paths";
import Challenges from "./pages/challenges";
import Community from "./pages/community";
import Admin from "./pages/admin";
import { lazy } from "react";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cosmic-white">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-starfleet-blue rounded-full animate-pulse"></div>
          <div className="w-2 h-2 bg-starfleet-blue rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
          <div className="w-2 h-2 bg-starfleet-blue rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          {/* Check if user needs onboarding */}
          {!user?.onboardingCompleted ? (
            <Route path="/" component={Onboarding} />
          ) : (
            <>
              {/* Protected routes for authenticated users */}
              <Route path="/" component={Home} />
              <Route path="/dashboard" component={Home} />
              <Route path="/skill-gap-analysis">
                <ProtectedRoute>
                  <SkillGapAnalysis />
                </ProtectedRoute>
              </Route>
              <Route path="/learning-paths">
                <ProtectedRoute>
                  <LearningPaths />
                </ProtectedRoute>
              </Route>
              <Route path="/challenges">
                <ProtectedRoute>
                  <Challenges />
                </ProtectedRoute>
              </Route>
              <Route path="/community">
                <ProtectedRoute>
                  <Community />
                </ProtectedRoute>
              </Route>
              <Route path="/admin" component={lazy(() => import("./pages/admin"))} />
              <Route path="/course-creator" component={lazy(() => import("./pages/course-creator"))} />
            </>
          )}

          {/* Onboarding route accessible anytime */}
          <Route path="/onboarding" component={Onboarding} />
        </>
      )}

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;