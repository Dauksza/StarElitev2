import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface SkillData {
  skill: string;
  current: number;
  target: number;
  gap: number;
}

interface SkillGapChartProps {
  skills: SkillData[];
  className?: string;
}

export function SkillGapChart({ skills, className = '' }: SkillGapChartProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Skill Gap Analysis</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {skills.map((skill, index) => (
          <div key={index} className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-medium">{skill.skill}</span>
              <span className="text-sm text-gray-500">
                {skill.current}% / {skill.target}%
              </span>
            </div>
            <Progress value={skill.current} className="h-2" />
            <div className="text-xs text-gray-500">
              Gap: {skill.gap}% to reach target
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}