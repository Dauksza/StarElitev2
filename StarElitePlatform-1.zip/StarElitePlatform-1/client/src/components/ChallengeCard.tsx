import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Clock, Trophy, Target } from "lucide-react";

interface Challenge {
  id: string;
  title: string;
  description: string;
  type: string;
  difficulty: string;
  category?: string;
  startDate?: string;
  endDate?: string;
  maxParticipants?: number;
  currentParticipants?: number;
  progress?: number;
  status?: string;
  rewards?: any;
}

interface ChallengeCardProps {
  challenge: Challenge;
  onJoin?: (challengeId: string) => void;
  showProgress?: boolean;
}

export function ChallengeCard({ challenge, onJoin, showProgress = true }: ChallengeCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "hard":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "easy":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "team":
        return "bg-blue-100 text-blue-800";
      case "individual":
        return "bg-purple-100 text-purple-800";
      case "community":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string = "active") => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "active":
        return "bg-blue-100 text-blue-800";
      case "upcoming":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getRemainingTime = () => {
    if (!challenge.endDate) return null;
    
    const endDate = new Date(challenge.endDate);
    const now = new Date();
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "Ended";
    if (diffDays === 0) return "Ends today";
    if (diffDays === 1) return "1 day remaining";
    return `${diffDays} days remaining`;
  };

  const getIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "team":
        return <Users className="w-4 h-4" />;
      case "individual":
        return <Target className="w-4 h-4" />;
      default:
        return <Trophy className="w-4 h-4" />;
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-semibold text-gray-900 text-sm">{challenge.title}</h3>
        <div className="flex items-center space-x-2">
          <Badge className={`${getTypeColor(challenge.type)} flex items-center space-x-1`}>
            {getIcon(challenge.type)}
            <span className="text-xs font-bold uppercase">{challenge.type}</span>
          </Badge>
          <Badge className={getDifficultyColor(challenge.difficulty)}>
            {challenge.difficulty}
          </Badge>
        </div>
      </div>

      <p className="text-xs text-gray-600 mb-3">{challenge.description}</p>

      {showProgress && challenge.progress !== undefined && (
        <div className="mb-3">
          <div className="flex items-center space-x-2 mb-2">
            <div className="flex-1 bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-starfleet-blue to-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${challenge.progress}%` }}
              ></div>
            </div>
            <span className="text-xs font-medium text-gray-700">
              {Math.round(challenge.progress || 0)}%
            </span>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
        <div className="flex items-center space-x-4">
          {challenge.maxParticipants && (
            <div className="flex items-center space-x-1">
              <Users className="w-3 h-3" />
              <span>{challenge.currentParticipants || 0}/{challenge.maxParticipants}</span>
            </div>
          )}
          {getRemainingTime() && (
            <div className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>{getRemainingTime()}</span>
            </div>
          )}
        </div>
        {challenge.rewards && (
          <div className="flex items-center space-x-1">
            <Trophy className="w-3 h-3" />
            <span>Rewards available</span>
          </div>
        )}
      </div>

      {challenge.status && (
        <div className="flex items-center justify-between">
          <Badge className={getStatusColor(challenge.status)}>
            {challenge.status.toUpperCase()}
          </Badge>
          {onJoin && challenge.status === "active" && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onJoin(challenge.id)}
              className="text-starfleet-blue border-starfleet-blue hover:bg-starfleet-blue hover:text-white"
            >
              Join Challenge
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
