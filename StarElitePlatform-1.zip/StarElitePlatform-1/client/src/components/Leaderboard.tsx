
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Medal, Award, TrendingUp } from "lucide-react";

interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  level: number;
  badge?: string;
  rank: number;
  weeklyProgress: number;
}

export default function Leaderboard() {
  // Mock data - in real app this would come from API
  const leaderboardData: LeaderboardEntry[] = [
    { id: '1', name: 'Alex Chen', points: 2450, level: 28, badge: 'Data Master', rank: 1, weeklyProgress: 340 },
    { id: '2', name: 'Sarah Johnson', points: 2120, level: 26, badge: 'AI Expert', rank: 2, weeklyProgress: 290 },
    { id: '3', name: 'You', points: 1890, level: 24, badge: 'Quick Learner', rank: 3, weeklyProgress: 275 },
    { id: '4', name: 'Mike Rodriguez', points: 1650, level: 22, badge: 'Consistent', rank: 4, weeklyProgress: 210 },
    { id: '5', name: 'Emily Davis', points: 1420, level: 20, badge: 'Rising Star', rank: 5, weeklyProgress: 185 }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-sm font-bold text-gray-600">{rank}</div>;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500';
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600';
      default:
        return 'bg-gradient-to-r from-blue-400 to-blue-600';
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="w-6 h-6 text-yellow-500" />
          Weekly Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {leaderboardData.map((entry, index) => (
            <div 
              key={entry.id} 
              className={`flex items-center justify-between p-4 rounded-lg transition-all ${
                entry.name === 'You' 
                  ? 'bg-blue-50 border-2 border-blue-200' 
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center">
                  {getRankIcon(entry.rank)}
                </div>
                
                <Avatar className="h-10 w-10">
                  <AvatarFallback className={`text-white ${getRankBadgeColor(entry.rank)}`}>
                    {entry.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div>
                  <div className="flex items-center space-x-2">
                    <span className={`font-semibold ${entry.name === 'You' ? 'text-blue-800' : 'text-gray-900'}`}>
                      {entry.name}
                    </span>
                    {entry.badge && (
                      <Badge variant="outline" className="text-xs">
                        {entry.badge}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <span>Level {entry.level}</span>
                    <span>•</span>
                    <div className="flex items-center">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      <span>+{entry.weeklyProgress} this week</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className={`text-lg font-bold ${entry.name === 'You' ? 'text-blue-800' : 'text-gray-900'}`}>
                  {entry.points.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500">XP</div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold">Your Performance</h4>
              <p className="text-sm text-blue-100">Keep learning to climb higher!</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">#3</div>
              <div className="text-sm text-blue-200">This Week</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
