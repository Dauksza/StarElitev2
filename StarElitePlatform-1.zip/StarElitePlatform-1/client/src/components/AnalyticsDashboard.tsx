
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { TrendingUp, Clock, Target, Award, Users, Brain, Zap } from 'lucide-react';

interface AnalyticsData {
  studyTime: number;
  completedModules: number;
  averageScore: number;
  streak: number;
  engagement: number;
  skillProgress: Array<{
    skill: string;
    progress: number;
    trend: 'up' | 'down' | 'stable';
  }>;
  insights: string[];
}

export function AnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    studyTime: 45,
    completedModules: 8,
    averageScore: 85,
    streak: 12,
    engagement: 92,
    skillProgress: [
      { skill: 'Data Science', progress: 78, trend: 'up' },
      { skill: 'Machine Learning', progress: 65, trend: 'up' },
      { skill: 'Python Programming', progress: 89, trend: 'stable' },
      { skill: 'Statistics', progress: 72, trend: 'up' }
    ],
    insights: [
      'Your learning pace has increased by 23% this week',
      'Strong performance in Python Programming - consider advanced topics',
      'Machine Learning concepts need more practice',
      'Consistent daily engagement is boosting your retention rate'
    ]
  });

  const [realTimeMetrics, setRealTimeMetrics] = useState({
    currentSession: 0,
    focusScore: 95,
    comprehensionRate: 88
  });

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setRealTimeMetrics(prev => ({
        currentSession: prev.currentSession + Math.floor(Math.random() * 3),
        focusScore: Math.max(80, Math.min(100, prev.focusScore + (Math.random() - 0.5) * 5)),
        comprehensionRate: Math.max(70, Math.min(100, prev.comprehensionRate + (Math.random() - 0.5) * 3))
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down':
        return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />;
      default:
        return <div className="w-4 h-4 bg-gray-400 rounded-full" />;
    }
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <div className="space-y-6">
      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Current Session</p>
                <p className="text-2xl font-bold">{formatTime(realTimeMetrics.currentSession)}</p>
              </div>
              <Clock className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Focus Score</p>
                <p className="text-2xl font-bold">{realTimeMetrics.focusScore.toFixed(0)}%</p>
              </div>
              <Brain className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Comprehension</p>
                <p className="text-2xl font-bold">{realTimeMetrics.comprehensionRate.toFixed(0)}%</p>
              </div>
              <Target className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">{formatTime(analytics.studyTime)}</div>
              <div className="text-sm text-gray-600">Total Study Time</div>
              <div className="text-xs text-green-600 mt-1">+15% this week</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">{analytics.completedModules}</div>
              <div className="text-sm text-gray-600">Modules Completed</div>
              <div className="text-xs text-green-600 mt-1">+3 this week</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">{analytics.averageScore}%</div>
              <div className="text-sm text-gray-600">Average Score</div>
              <div className="text-xs text-green-600 mt-1">+5% improvement</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">{analytics.streak}</div>
              <div className="text-sm text-gray-600">Day Streak</div>
              <div className="text-xs text-green-600 mt-1">Personal best!</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Skill Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <span>Skill Progress Tracking</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics.skillProgress.map((skill, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">{skill.skill}</span>
                    {getTrendIcon(skill.trend)}
                  </div>
                  <span className="text-sm text-gray-600">{skill.progress}%</span>
                </div>
                <Progress value={skill.progress} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="w-6 h-6 text-yellow-500" />
            <span>AI-Powered Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics.insights.map((insight, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p className="text-sm text-blue-800">{insight}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Engagement Meter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-6 h-6 text-green-600" />
            <span>Engagement Analytics</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Overall Engagement</span>
                <Badge variant={analytics.engagement > 80 ? 'default' : 'secondary'}>
                  {analytics.engagement}%
                </Badge>
              </div>
              <Progress value={analytics.engagement} className="h-3" />
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Sessions this week:</span>
                <span className="font-semibold ml-2">18</span>
              </div>
              <div>
                <span className="text-gray-600">Avg. session length:</span>
                <span className="font-semibold ml-2">24m</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
