import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { mistralAI } from '../lib/mistralAI';

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

interface SkillAssessmentProps {
  topic: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  onComplete: (score: number, results: any) => void;
}

function SkillAssessment({ topic, difficulty, onComplete }: SkillAssessmentProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [score, setScore] = useState(0);

  const startAssessment = async () => {
    setLoading(true);
    try {
      const generatedQuestions = await mistralAI.generateQuizQuestions(topic, difficulty, 10);
      setQuestions(generatedQuestions);
      setStarted(true);
    } catch (error) {
      console.error('Error generating questions:', error);
      // Fallback questions
      setQuestions([
        {
          id: 1,
          question: `What is a key concept in ${topic}?`,
          options: ['Option A', 'Option B', 'Option C', 'Option D'],
          correct: 0,
          explanation: 'This is a sample question.'
        },
        {
          id: 2,
          question: `Which best describes ${topic}?`,
          options: ['Definition A', 'Definition B', 'Definition C', 'Definition D'],
          correct: 1,
          explanation: 'This is another sample question.'
        }
      ]);
      setStarted(true);
    }
    setLoading(false);
  };

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      completeAssessment();
    }
  };

  const completeAssessment = () => {
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (answers[index] === question.correct) {
        correctAnswers++;
      }
    });

    const finalScore = Math.round((correctAnswers / questions.length) * 100);
    setScore(finalScore);
    setCompleted(true);

    onComplete(finalScore, {
      topic,
      difficulty,
      totalQuestions: questions.length,
      correctAnswers,
      answers,
      questions
    });
  };

  if (!started) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Skill Assessment: {topic}</CardTitle>
          <CardDescription>
            Test your knowledge with this {difficulty} level assessment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            onClick={startAssessment} 
            disabled={loading}
            className="w-full"
          >
            {loading ? 'Generating Questions...' : 'Start Assessment'}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (completed) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Assessment Complete!</CardTitle>
          <CardDescription>
            Your {topic} assessment results
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div className="text-4xl font-bold text-blue-600 mb-2">
              {score}%
            </div>
            <p className="text-gray-600">
              You scored {Math.round((score / 100) * questions.length)} out of {questions.length} questions correctly
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Performance Breakdown:</h3>
            <Progress value={score} className="w-full" />

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Difficulty:</span> {difficulty}
              </div>
              <div>
                <span className="font-medium">Topic:</span> {topic}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const question = questions[currentQuestion];
  if (!question) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardContent>
          <p>Loading question...</p>
        </CardContent>
      </Card>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Question {currentQuestion + 1} of {questions.length}</CardTitle>
          <span className="text-sm text-gray-500">{difficulty}</span>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <h3 className="text-lg font-medium">{question.question}</h3>

          <RadioGroup
            value={answers[currentQuestion]?.toString() || ''}
            onValueChange={(value) => handleAnswer(parseInt(value))}
          >
            {question.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>

          <Button 
            onClick={nextQuestion}
            disabled={answers[currentQuestion] === undefined}
            className="w-full"
          >
            {currentQuestion === questions.length - 1 ? 'Complete Assessment' : 'Next Question'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default SkillAssessment;
export { SkillAssessment };