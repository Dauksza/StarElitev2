import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Star,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Target,
  Brain,
  Rocket,
  Trophy,
  Users,
  BarChart3
} from "lucide-react";
import { useLocation } from "wouter";

const STEPS = [
  { id: 1, title: "Welcome", subtitle: "Let's get to know you" },
  { id: 2, title: "Goals", subtitle: "What do you want to achieve?" },
  { id: 3, title: "Experience", subtitle: "Tell us about your background" },
  { id: 4, title: "Preferences", subtitle: "How do you like to learn?" },
  { id: 5, title: "Analysis", subtitle: "AI is creating your path" }
];

export default function Onboarding() {
  const [currentStep, setCurrentStep] = useState(1);
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    currentRole: '',
    goals: [],
    experience: '',
    skills: '',
    learningStyle: '',
    timeCommitment: '',
    motivation: ''
  });

  const goalOptions = [
    { id: 'career-advancement', label: 'Advance my career', icon: '🚀' },
    { id: 'skill-development', label: 'Develop new skills', icon: '📚' },
    { id: 'certification', label: 'Earn certifications', icon: '🏆' },
    { id: 'leadership', label: 'Build leadership skills', icon: '👥' },
    { id: 'technical-expertise', label: 'Become a technical expert', icon: '⚡' },
    { id: 'career-change', label: 'Change career paths', icon: '🎯' }
  ];

  const learningStyleOptions = [
    { id: 'visual', label: 'Visual learner', description: 'I learn best with diagrams, videos, and visual aids' },
    { id: 'hands-on', label: 'Hands-on learner', description: 'I prefer practical exercises and real projects' },
    { id: 'reading', label: 'Reading/Writing', description: 'I learn well through text and written materials' },
    { id: 'mixed', label: 'Mixed approach', description: 'I like a combination of different learning methods' }
  ];

  const timeCommitmentOptions = [
    { id: 'light', label: '2-5 hours/week', description: 'I have limited time but want to make progress' },
    { id: 'moderate', label: '5-10 hours/week', description: 'I can dedicate regular time to learning' },
    { id: 'intensive', label: '10+ hours/week', description: 'I want to accelerate my learning journey' }
  ];

  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleGoalToggle = (goalId: string) => {
    const newGoals = formData.goals.includes(goalId)
      ? formData.goals.filter(g => g !== goalId)
      : [...formData.goals, goalId];
    setFormData(prev => ({ ...prev, goals: newGoals }));
  };

  const handleComplete = async () => {
    // Save user preferences and redirect to dashboard
    try {
      const response = await fetch('/api/user/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setLocation('/dashboard');
      }
    } catch (error) {
      console.error('Onboarding error:', error);
      // For demo, redirect anyway
      setLocation('/dashboard');
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-blue-800 mb-2">Welcome to StarElite!</h2>
              <p className="text-lg text-gray-600">
                Let's personalize your learning experience in just a few steps
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                <Input
                  placeholder="Enter your first name"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                <Input
                  placeholder="Enter your last name"
                  value={formData.lastName}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Current Role/Position</label>
              <Input
                placeholder="e.g., Software Developer, Marketing Manager, Student"
                value={formData.currentRole}
                onChange={(e) => setFormData(prev => ({ ...prev, currentRole: e.target.value }))}
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <Target className="w-16 h-16 mx-auto mb-4 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">What are your goals?</h2>
              <p className="text-gray-600">Select all that apply - this helps us personalize your experience</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {goalOptions.map((goal) => (
                <Card 
                  key={goal.id}
                  className={`cursor-pointer transition-all ${
                    formData.goals.includes(goal.id) 
                      ? 'ring-2 ring-blue-500 bg-blue-50' 
                      : 'hover:shadow-md'
                  }`}
                  onClick={() => handleGoalToggle(goal.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{goal.icon}</span>
                      <div className="flex-1">
                        <span className="font-medium text-gray-900">{goal.label}</span>
                        {formData.goals.includes(goal.id) && (
                          <CheckCircle className="w-5 h-5 text-blue-500 ml-auto" />
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <BarChart3 className="w-16 h-16 mx-auto mb-4 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Tell us about your experience</h2>
              <p className="text-gray-600">This helps us understand your starting point</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Years of Experience in your field
              </label>
              <select 
                className="w-full p-3 border border-gray-300 rounded-md"
                value={formData.experience}
                onChange={(e) => setFormData(prev => ({ ...prev, experience: e.target.value }))}
              >
                <option value="">Select your experience level</option>
                <option value="0-1">0-1 years (Beginner)</option>
                <option value="2-3">2-3 years (Junior)</option>
                <option value="4-6">4-6 years (Intermediate)</option>
                <option value="7-10">7-10 years (Senior)</option>
                <option value="10+">10+ years (Expert)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Current Skills & Technologies
              </label>
              <Textarea
                placeholder="List your current skills, technologies, and tools (e.g., JavaScript, React, Project Management, Excel, etc.)"
                value={formData.skills}
                onChange={(e) => setFormData(prev => ({ ...prev, skills: e.target.value }))}
                rows={4}
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <Brain className="w-16 h-16 mx-auto mb-4 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">How do you prefer to learn?</h2>
              <p className="text-gray-600">Let's optimize your learning experience</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Learning Style</label>
              <div className="space-y-3">
                {learningStyleOptions.map((style) => (
                  <Card 
                    key={style.id}
                    className={`cursor-pointer transition-all ${
                      formData.learningStyle === style.id 
                        ? 'ring-2 ring-blue-500 bg-blue-50' 
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => setFormData(prev => ({ ...prev, learningStyle: style.id }))}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{style.label}</h4>
                          <p className="text-sm text-gray-600">{style.description}</p>
                        </div>
                        {formData.learningStyle === style.id && (
                          <CheckCircle className="w-5 h-5 text-blue-500" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Time Commitment</label>
              <div className="space-y-3">
                {timeCommitmentOptions.map((option) => (
                  <Card 
                    key={option.id}
                    className={`cursor-pointer transition-all ${
                      formData.timeCommitment === option.id 
                        ? 'ring-2 ring-blue-500 bg-blue-50' 
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => setFormData(prev => ({ ...prev, timeCommitment: option.id }))}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{option.label}</h4>
                          <p className="text-sm text-gray-600">{option.description}</p>
                        </div>
                        {formData.timeCommitment === option.id && (
                          <CheckCircle className="w-5 h-5 text-blue-500" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center mx-auto animate-pulse">
              <Brain className="w-12 h-12 text-white" />
            </div>

            <div>
              <h2 className="text-3xl font-bold text-blue-800 mb-4">
                StarForce AI is analyzing your profile...
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Creating your personalized learning path based on your goals and experience
              </p>
            </div>

            <div className="bg-blue-50 rounded-xl p-6 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center text-blue-700">
                  <CheckCircle className="w-5 h-5 mr-3" />
                  <span>Profile analysis complete</span>
                </div>
                <div className="flex items-center text-blue-700">
                  <CheckCircle className="w-5 h-5 mr-3" />
                  <span>Skill gaps identified</span>
                </div>
                <div className="flex items-center text-blue-700">
                  <CheckCircle className="w-5 h-5 mr-3" />
                  <span>Learning path generated</span>
                </div>
                <div className="flex items-center text-blue-700">
                  <Brain className="w-5 h-5 mr-3 animate-spin" />
                  <span>Personalizing content...</span>
                </div>
              </div>
            </div>

            <Button 
              onClick={handleComplete}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3"
              size="lg"
            >
              <Rocket className="mr-2 h-5 w-5" />
              Launch My Learning Journey
            </Button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-blue-800">StarElite</span>
            </div>
            <Badge className="bg-blue-100 text-blue-800">
              Step {currentStep} of {STEPS.length}
            </Badge>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4 mb-4">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  currentStep >= step.id 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {currentStep > step.id ? <CheckCircle className="w-5 h-5" /> : step.id}
                </div>
                {index < STEPS.length - 1 && (
                  <div className={`w-12 h-1 mx-2 ${
                    currentStep > step.id ? 'bg-blue-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <Progress value={(currentStep / STEPS.length) * 100} className="h-2" />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-center">
              <h1 className="text-2xl font-bold text-gray-900">
                {STEPS[currentStep - 1]?.title}
              </h1>
              <p className="text-gray-600 text-base font-normal mt-2">
                {STEPS[currentStep - 1]?.subtitle}
              </p>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            {renderStep()}

            {/* Navigation */}
            {currentStep < 5 && (
              <div className="flex justify-between mt-8">
                <Button 
                  variant="outline" 
                  onClick={handlePrevious}
                  disabled={currentStep === 1}
                  className="flex items-center"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Previous
                </Button>
                <Button 
                  onClick={handleNext}
                  disabled={
                    (currentStep === 1 && (!formData.firstName || !formData.currentRole)) ||
                    (currentStep === 2 && formData.goals.length === 0) ||
                    (currentStep === 3 && (!formData.experience || !formData.skills)) ||
                    (currentStep === 4 && (!formData.learningStyle || !formData.timeCommitment))
                  }
                  className="flex items-center bg-blue-600 hover:bg-blue-700"
                >
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}