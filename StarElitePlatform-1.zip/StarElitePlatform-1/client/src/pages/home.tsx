import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { 
  BookOpen, 
  Trophy, 
  Target, 
  TrendingUp, 
  Users, 
  Calendar,
  Star,
  Clock,
  Award,
  ArrowRight,
  Zap,
  Brain,
  BarChart3,
  CheckCircle,
  LogOut,
  GraduationCap
} from "lucide-react";
import { useLocation } from "wouter";
import { api } from "@/lib/api";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };
  const { data: learningPaths } = useQuery({
    queryKey: ["/api/learning-paths"],
    queryFn: () => api.getLearningPaths(),
  });
  const { data: challenges } = useQuery({
    queryKey: ["/api/challenges"],
    queryFn: () => api.getChallenges(),
  });

  // Mock data for demonstration - in real app this would come from API
  const userProgress = {
    completedCourses: 12,
    totalCourses: 50,
    currentStreak: 15,
    skillLevel: "Intermediate",
    weeklyGoal: 5,
    completedThisWeek: 3,
    badges: [
      { name: "Fast Learner", icon: "⚡", earned: true },
      { name: "Consistent", icon: "📚", earned: true },
      { name: "Expert", icon: "🎯", earned: false }
    ],
    recentActivities: [
      { course: "Advanced Python", progress: 85, lastAccessed: "2 hours ago" },
      { course: "Machine Learning Basics", progress: 60, lastAccessed: "1 day ago" },
      { course: "Data Science Fundamentals", progress: 100, lastAccessed: "3 days ago" }
    ]
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
                <p className="text-xs text-gray-600 -mt-1">Educational Institute</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-semibold text-blue-800">
                    {user?.firstName?.charAt(0) || user?.email?.charAt(0) || 'U'}
                  </span>
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {user?.firstName || user?.email?.split('@')[0] || 'Student'}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="hover:bg-red-50 hover:text-red-700 hover:border-red-200"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.firstName || 'Student'}!
          </h1>
          <p className="text-lg text-gray-600">
            Continue your learning journey and unlock your potential
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-blue-800">Courses Completed</CardTitle>
              <BookOpen className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900">{userProgress.completedCourses}</div>
              <p className="text-xs text-blue-600">out of {userProgress.totalCourses} enrolled</p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-amber-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-amber-800">Learning Streak</CardTitle>
              <Trophy className="h-4 w-4 text-amber-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-900">{userProgress.currentStreak} days</div>
              <p className="text-xs text-amber-600">Keep it up!</p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-green-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-green-800">Skill Level</CardTitle>
              <Target className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900">{userProgress.skillLevel}</div>
              <p className="text-xs text-green-600">Advancing steadily</p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-purple-800">Weekly Progress</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-900">
                {userProgress.completedThisWeek}/{userProgress.weeklyGoal}
              </div>
              <p className="text-xs text-purple-600">courses this week</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Progress Overview */}
          <div className="lg:col-span-2 space-y-6">
            {/* Welcome Section */}
            <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-2">
                  Welcome back, {user?.firstName || user?.email?.split('@')[0] || 'Student'}!
                </h2>
                <p className="text-blue-100 mb-4">
                  Ready to continue your learning journey? Let's see what's next.
                </p>
                <div className="flex gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold">Level {user?.level || 1}</div>
                    <div className="text-sm text-blue-200">Current Level</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user?.totalXp || 0}</div>
                    <div className="text-sm text-blue-200">Total XP</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user?.currentStreak || 0}</div>
                    <div className="text-sm text-blue-200">Day Streak</div>
                  </div>
                  <div className="text-center">
                    <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                      {user?.subscription || 'Freemium'}
                    </Badge>
                    <div className="text-sm text-blue-200 mt-1">Plan</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button 
                    onClick={() => window.location.href = '/learning-paths'}
                    className="h-20 flex flex-col gap-2"
                    variant="outline"
                  >
                    <BookOpen className="w-6 h-6" />
                    <span className="text-sm">Browse Courses</span>
                  </Button>
                  <Button 
                    onClick={() => window.location.href = '/challenges'}
                    className="h-20 flex flex-col gap-2"
                    variant="outline"
                  >
                    <Trophy className="w-6 h-6" />
                    <span className="text-sm">Take Challenge</span>
                  </Button>
                  <Button 
                    onClick={() => window.location.href = '/skill-gap-analysis'}
                    className="h-20 flex flex-col gap-2"
                    variant="outline"
                  >
                    <Target className="w-6 h-6" />
                    <span className="text-sm">Skill Analysis</span>
                  </Button>
                  <Button 
                    onClick={() => window.location.href = '/community'}
                    className="h-20 flex flex-col gap-2"
                    variant="outline"
                  >
                    <Users className="w-6 h-6" />
                    <span className="text-sm">Community</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Continue Learning */}
            <Card className="border-2 border-blue-100">
              <CardHeader>
                <CardTitle className="flex items-center text-blue-800">
                  <Brain className="w-5 h-5 mr-2" />
                  Continue Learning
                </CardTitle>
                <CardDescription>Pick up where you left off</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {userProgress.recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{activity.course}</h4>
                      <div className="flex items-center space-x-2 mt-2">
                        <Progress value={activity.progress} className="flex-1 h-2" />
                        <span className="text-sm text-gray-600">{activity.progress}%</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Last accessed {activity.lastAccessed}</p>
                    </div>
                    <Button size="sm" className="ml-4 bg-blue-600 hover:bg-blue-700">
                      Continue
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recommended Courses */}
            <Card className="border-2 border-green-100">
              <CardHeader>
                <CardTitle className="flex items-center text-green-800">
                  <Star className="w-5 h-5 mr-2" />
                  Recommended for You
                </CardTitle>
                <CardDescription>AI-curated based on your progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-gray-900 mb-2">Deep Learning Fundamentals</h4>
                    <p className="text-sm text-gray-600 mb-3">Build neural networks from scratch</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">Intermediate</Badge>
                      <Button size="sm" variant="outline">Enroll</Button>
                    </div>
                  </div>
                  <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-gray-900 mb-2">Advanced Statistics</h4>
                    <p className="text-sm text-gray-600 mb-3">Statistical analysis for data science</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">Advanced</Badge>
                      <Button size="sm" variant="outline">Enroll</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Weekly Goal */}
            <Card className="border-2 border-amber-100">
              <CardHeader>
                <CardTitle className="flex items-center text-amber-800">
                  <Calendar className="w-5 h-5 mr-2" />
                  Weekly Goal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-amber-900 mb-2">
                    {userProgress.completedThisWeek}/{userProgress.weeklyGoal}
                  </div>
                  <p className="text-sm text-gray-600 mb-4">courses completed</p>
                  <Progress 
                    value={(userProgress.completedThisWeek / userProgress.weeklyGoal) * 100} 
                    className="mb-4" 
                  />
                  <p className="text-xs text-gray-500">
                    {userProgress.weeklyGoal - userProgress.completedThisWeek} more to reach your goal
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card className="border-2 border-purple-100">
              <CardHeader>
                <CardTitle className="flex items-center text-purple-800">
                  <Award className="w-5 h-5 mr-2" />
                  Recent Achievements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {userProgress.badges.map((badge, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      badge.earned ? 'bg-yellow-100' : 'bg-gray-100'
                    }`}>
                      <span className={badge.earned ? 'text-lg' : 'text-lg grayscale'}>
                        {badge.icon}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${badge.earned ? 'text-gray-900' : 'text-gray-500'}`}>
                        {badge.name}
                      </p>
                      {badge.earned && <CheckCircle className="w-4 h-4 text-green-500 inline ml-2" />}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-2 border-indigo-100">
              <CardHeader>
                <CardTitle className="text-indigo-800">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-blue-600 hover:bg-blue-700" size="sm">
                  <Brain className="w-4 h-4 mr-2" />
                  Take Skill Assessment
                </Button>
                <Button className="w-full" variant="outline" size="sm">
                  <Users className="w-4 h-4 mr-2" />
                  Join Study Group
                </Button>
                <Button className="w-full" variant="outline" size="sm">
                  <Trophy className="w-4 h-4 mr-2" />
                  View Leaderboard
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}