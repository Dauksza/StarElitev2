import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, GraduationCap, Users, Trophy, Brain, Target, BookOpen, Award } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
                <p className="text-xs text-gray-600 -mt-1">Educational Institute</p>
              </div>
              <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                AI-Powered Learning
              </Badge>
            </div>
            <Button onClick={handleLogin} className="bg-blue-600 text-white hover:bg-blue-700 shadow-lg">
              Student Portal
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-800 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="h-full w-full bg-gradient-to-br from-white/5 to-transparent"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="mb-6">
              <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-4">
                <Star className="w-4 h-4 text-amber-300 mr-2" />
                <span className="text-sm font-medium">Premier AI Learning Institution</span>
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Welcome to{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-yellow-400">
                StarElite
              </span>
              <br />
              <span className="text-3xl md:text-4xl text-blue-100">Educational Institute</span>
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
              Transform your career with our comprehensive AI-powered learning platform. 
              Personalized curricula, expert instruction, and industry-recognized certifications.
            </p>
            <div className="flex items-center justify-center space-x-6 mb-8 text-sm">
              <div className="flex items-center">
                <BookOpen className="w-4 h-4 mr-2 text-amber-300" />
                <span>500+ Courses</span>
              </div>
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-2 text-amber-300" />
                <span>50K+ Students</span>
              </div>
              <div className="flex items-center">
                <Award className="w-4 h-4 mr-2 text-amber-300" />
                <span>Industry Certified</span>
              </div>
            </div>
            <Button 
              onClick={handleLogin}
              size="lg"
              className="bg-gradient-to-r from-amber-400 to-yellow-400 text-blue-900 hover:from-amber-500 hover:to-yellow-500 text-lg px-8 py-4 shadow-2xl font-semibold"
            >
              Begin Your Learning Journey
            </Button>
          </div>
        </div>
      </section>

      {/* Academic Programs Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Academic Excellence Through Innovation
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our AI-powered curriculum adapts to your learning style, providing personalized education 
              that accelerates your professional development and career advancement.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">AI-Powered Assessment</CardTitle>
                <CardDescription className="text-gray-600">
                  Comprehensive skill evaluation and personalized learning path recommendations 
                  based on your career objectives and current competencies.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">Adaptive Curriculum</CardTitle>
                <CardDescription className="text-gray-600">
                  Dynamic course content that evolves with your progress, ensuring optimal 
                  learning efficiency and knowledge retention.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Trophy className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">Certification Programs</CardTitle>
                <CardDescription className="text-gray-600">
                  Industry-recognized credentials and professional certifications that 
                  enhance your career prospects and validate your expertise.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-500 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">Expert Faculty</CardTitle>
                <CardDescription className="text-gray-600">
                  Learn from industry professionals and academic experts who bring 
                  real-world experience to comprehensive theoretical foundations.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-500 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">Student Community</CardTitle>
                <CardDescription className="text-gray-600">
                  Connect with peers, participate in collaborative projects, and 
                  build professional networks that last throughout your career.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 border-blue-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-blue-800">Career Services</CardTitle>
                <CardDescription className="text-gray-600">
                  Comprehensive career support including job placement assistance, 
                  interview preparation, and ongoing professional development.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-amber-300 mb-2">50,000+</div>
              <div className="text-blue-100">Active Students</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-300 mb-2">500+</div>
              <div className="text-blue-100">Expert Courses</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-300 mb-2">95%</div>
              <div className="text-blue-100">Success Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-300 mb-2">24/7</div>
              <div className="text-blue-100">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* Enrollment CTA */}
      <section className="bg-gradient-to-br from-amber-50 to-yellow-50 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Ready to Excel in Your Career?
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who have transformed their careers through 
              StarElite's comprehensive educational programs and AI-powered learning platform.
            </p>
            <Button 
              onClick={handleLogin}
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-700 hover:to-indigo-700 text-lg px-8 py-4 shadow-xl"
            >
              Enroll Today
            </Button>
            <p className="text-sm text-gray-500 mt-4">Start with our free assessment • No commitment required</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <span className="text-2xl font-bold">StarElite</span>
                  <p className="text-xs text-gray-400 -mt-1">Educational Institute</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4 max-w-md">
                Empowering professionals worldwide through innovative AI-powered education 
                and comprehensive career development programs.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase mb-4">
                Academic Programs
              </h3>
              <ul className="space-y-2">
                <li><span className="text-gray-300">Data Science</span></li>
                <li><span className="text-gray-300">AI & Machine Learning</span></li>
                <li><span className="text-gray-300">Software Engineering</span></li>
                <li><span className="text-gray-300">Business Analytics</span></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase mb-4">
                Student Services
              </h3>
              <ul className="space-y-2">
                <li><span className="text-gray-300">Academic Support</span></li>
                <li><span className="text-gray-300">Career Services</span></li>
                <li><span className="text-gray-300">Student Community</span></li>
                <li><span className="text-gray-300">Alumni Network</span></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              &copy; 2024 StarElite Educational Institute. Advancing careers through AI-powered learning.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}