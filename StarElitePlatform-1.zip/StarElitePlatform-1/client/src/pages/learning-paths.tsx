import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Clock, 
  Trophy, 
  Star,
  Users,
  ChevronRight,
  Play,
  CheckCircle,
  GraduationCap,
  Brain,
  Target,
  Zap
} from "lucide-react";
import { SkillAssessment } from "../components/SkillAssessment";
import { AdaptiveLearning } from "../components/AdaptiveLearning";

interface LearningModule {
  id: string;
  title: string;
  description: string;
  type: "lesson" | "quiz" | "challenge" | "project";
  duration: number;
  completed: boolean;
  score?: number;
}

interface LearningPath {
  id: string;
  title: string;
  description: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedHours: number;
  category: string;
  progress: number;
  modules: LearningModule[];
  skillsGained: string[];
  prerequisites: string[];
  enrolled: boolean;
  rating: number;
  studentsEnrolled: number;
  tags?: string[];
  moduleCount?: number;
}

export default function LearningPaths() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);
  const [currentMode, setCurrentMode] = useState<'overview' | 'assessment' | 'learning'>('overview');

  const categories = [
    { id: "all", label: "All Paths", count: 24 },
    { id: "data-science", label: "Data Science", count: 8 },
    { id: "software-engineering", label: "Software Engineering", count: 6 },
    { id: "ai-ml", label: "AI & Machine Learning", count: 5 },
    { id: "business", label: "Business Analytics", count: 3 },
    { id: "design", label: "Design & UX", count: 2 }
  ];

  const learningPaths: LearningPath[] = [
    {
      id: "python-data-science",
      title: "Python for Data Science Mastery",
      description: "Comprehensive pathway from Python basics to advanced data analysis, machine learning, and visualization techniques.",
      difficulty: "intermediate",
      estimatedHours: 120,
      category: "data-science",
      progress: 65,
      enrolled: true,
      rating: 4.8,
      studentsEnrolled: 15420,
      skillsGained: ["Python Programming", "Pandas", "NumPy", "Matplotlib", "Scikit-learn", "Statistical Analysis"],
      prerequisites: ["Basic Programming Concepts", "Mathematics Fundamentals"],
      modules: [
        {
          id: "python-basics",
          title: "Python Fundamentals",
          description: "Core Python concepts and syntax",
          type: "lesson",
          duration: 8,
          completed: true,
          score: 92
        },
        {
          id: "data-structures",
          title: "Data Structures & Algorithms",
          description: "Essential data structures for data science",
          type: "lesson",
          duration: 12,
          completed: true,
          score: 88
        },
        {
          id: "pandas-intro",
          title: "Introduction to Pandas",
          description: "Data manipulation with Pandas",
          type: "lesson",
          duration: 10,
          completed: true,
          score: 95
        },
        {
          id: "data-viz",
          title: "Data Visualization",
          description: "Creating compelling visualizations",
          type: "project",
          duration: 15,
          completed: false
        },
        {
          id: "ml-basics",
          title: "Machine Learning Fundamentals",
          description: "Introduction to ML algorithms",
          type: "lesson",
          duration: 20,
          completed: false
        }
      ],
      tags: ["python", "data analysis", "machine learning"],
      moduleCount: 5
    },
    {
      id: "full-stack-web",
      title: "Full-Stack Web Development",
      description: "Build modern web applications from frontend to backend using React, Node.js, and databases.",
      difficulty: "intermediate",
      estimatedHours: 180,
      category: "software-engineering",
      progress: 0,
      enrolled: false,
      rating: 4.9,
      studentsEnrolled: 12380,
      skillsGained: ["React", "Node.js", "Express", "MongoDB", "REST APIs", "Authentication"],
      prerequisites: ["HTML/CSS", "JavaScript Basics"],
      modules: [],
      tags: ["react", "node.js", "javascript"],
      moduleCount: 10
    },
    {
      id: "ai-fundamentals",
      title: "Artificial Intelligence Fundamentals",
      description: "Explore the foundations of AI, from neural networks to deep learning and practical applications.",
      difficulty: "advanced",
      estimatedHours: 200,
      category: "ai-ml",
      progress: 0,
      enrolled: false,
      rating: 4.7,
      studentsEnrolled: 8950,
      skillsGained: ["Neural Networks", "Deep Learning", "TensorFlow", "Computer Vision", "NLP"],
      prerequisites: ["Python Programming", "Linear Algebra", "Statistics"],
      modules: [],
      tags: ["neural networks", "deep learning", "tensorflow"],
      moduleCount: 8
    },
    {
      id: "business-analytics",
      title: "Business Intelligence & Analytics",
      description: "Transform data into actionable business insights using modern analytics tools and methodologies.",
      difficulty: "intermediate",
      estimatedHours: 90,
      category: "business",
      progress: 0,
      enrolled: false,
      rating: 4.6,
      studentsEnrolled: 6720,
      skillsGained: ["Power BI", "Tableau", "SQL", "Business Intelligence", "Data Modeling"],
      prerequisites: ["Basic Statistics", "Excel Proficiency"],
      modules: [],
      tags: ["power bi", "tableau", "sql"],
      moduleCount: 6
    }
  ];

  const filteredPaths = selectedCategory === "all" 
    ? learningPaths 
    : learningPaths.filter(path => path.category === selectedCategory);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800 border-green-200";
      case "intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "advanced": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getModuleIcon = (type: string) => {
    switch (type) {
      case "lesson": return <BookOpen className="w-4 h-4" />;
      case "quiz": return <Brain className="w-4 h-4" />;
      case "challenge": return <Target className="w-4 h-4" />;
      case "project": return <Zap className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
                <p className="text-xs text-gray-600 -mt-1">Learning Paths</p>
              </div>
            </div>
            <Button 
              onClick={() => window.location.href = "/"}
              variant="outline" 
              size="sm"
              className="border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Personalized Learning Paths
          </h1>
          <p className="text-lg text-gray-600">
            AI-curated learning journeys designed to accelerate your career growth
          </p>
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-8">
          <TabsList className="grid w-full grid-cols-6 bg-white border">
            {categories.map((category) => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800"
              >
                {category.label}
                <Badge variant="outline" className="ml-2">
                  {category.count}
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={selectedCategory} className="space-y-6">

        {currentMode === 'overview' && (
          <>
            <div className="mb-8 text-center">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                <Button 
                  onClick={() => setCurrentMode('assessment')}
                  className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
                >
                  <Brain className="w-5 h-5" />
                  <span>Take Skill Assessment</span>
                </Button>
                <Button 
                  onClick={() => setCurrentMode('learning')}
                  variant="outline"
                  className="flex items-center space-x-2"
                >
                  <Target className="w-5 h-5" />
                  <span>Start Adaptive Learning</span>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPaths.map((path) => (
                <Card key={path.id} className="hover:shadow-lg transition-shadow group">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                          {path.title}
                        </h3>
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{path.description}</p>
                      </div>
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <BookOpen className="w-6 h-6 text-blue-600" />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      <Badge 
                        variant={path.difficulty === 'Beginner' ? 'secondary' : 
                                path.difficulty === 'Intermediate' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {path.difficulty}
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1 text-xs">
                        <Clock className="w-3 h-3" />
                        {path.estimatedHours}
                      </Badge>
                    </div>

                    {/* Progress bar (mock) */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Progress</span>
                        <span>{Math.floor(Math.random() * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${Math.floor(Math.random() * 100)}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-sm text-gray-500 flex items-center gap-1">
                        <BookOpen className="w-4 h-4" />
                        {path.moduleCount || 0} modules
                      </div>
                      <Button size="sm" className="bg-blue-600 text-white hover:bg-blue-700">
                        Continue Learning
                      </Button>
                    </div>

                    {/* Tags */}
                    {path.tags && path.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-3">
                        {path.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                            {tag}
                          </span>
                        ))}
                        {path.tags.length > 3 && (
                          <span className="text-xs text-gray-500">+{path.tags.length - 3} more</span>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        {currentMode === 'assessment' && (
          <div className="space-y-6">
            <div className="text-center">
              <Button 
                onClick={() => setCurrentMode('overview')}
                variant="outline"
                className="mb-4"
              >
                ← Back to Overview
              </Button>
            </div>
            <SkillAssessment />
          </div>
        )}

        {currentMode === 'learning' && (
          <div className="space-y-6">
            <div className="text-center">
              <Button 
                onClick={() => setCurrentMode('overview')}
                variant="outline"
                className="mb-4"
              >
                ← Back to Overview
              </Button>
            </div>
            <AdaptiveLearning />
          </div>
        )}
          </TabsContent>
        </Tabs>

        {/* Detailed Path View Modal */}
        {selectedPath && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader className="border-b">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={getDifficultyColor(selectedPath.difficulty)}>
                        {selectedPath.difficulty.toUpperCase()}
                      </Badge>
                      {selectedPath.enrolled && (
                        <Badge variant="default" className="bg-blue-600">
                          ENROLLED
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-2xl">{selectedPath.title}</CardTitle>
                    <CardDescription className="text-lg mt-2">
                      {selectedPath.description}
                    </CardDescription>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedPath(null)}
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{selectedPath.estimatedHours}h</div>
                    <div className="text-sm text-gray-600">Total Duration</div>
                  </div>
                  <div className="text-center">
                    <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{selectedPath.studentsEnrolled.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Students Enrolled</div>
                  </div>
                  <div className="text-center">
                    <Star className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{selectedPath.rating}</div>
                    <div className="text-sm text-gray-600">Average Rating</div>
                  </div>
                </div>

                {selectedPath.enrolled && selectedPath.modules.length > 0 && (
                  <div className="mb-8">
                    <h3 className="text-lg font-semibold mb-4">Learning Modules</h3>
                    <div className="space-y-3">
                      {selectedPath.modules.map((module, index) => (
                        <div 
                          key={module.id} 
                          className={`flex items-center p-4 rounded-lg border ${
                            module.completed ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
                          }`}
                        >
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
                            module.completed ? "bg-green-600 text-white" : "bg-gray-400 text-white"
                          }`}>
                            {module.completed ? <CheckCircle className="w-5 h-5" /> : getModuleIcon(module.type)}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold">{module.title}</h4>
                            <p className="text-sm text-gray-600">{module.description}</p>
                            <div className="flex items-center mt-1 text-xs text-gray-500">
                              <Clock className="w-3 h-3 mr-1" />
                              {module.duration} hours
                              {module.completed && module.score && (
                                <span className="ml-4 text-green-600 font-medium">
                                  Score: {module.score}%
                                </span>
                              )}
                            </div>
                          </div>
                          <Button size="sm" variant={module.completed ? "outline" : "default"}>
                            {module.completed ? "Review" : "Start"}
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Skills You'll Gain</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedPath.skillsGained.map((skill, index) => (
                        <Badge key={index} variant="outline" className="bg-blue-50 text-blue-800">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Prerequisites</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedPath.prerequisites.map((prereq, index) => (
                        <Badge key={index} variant="outline" className="bg-amber-50 text-amber-800">
                          {prereq}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    size="lg" 
                    className={`flex-1 ${
                      selectedPath.enrolled 
                        ? "bg-blue-600 hover:bg-blue-700" 
                        : "bg-green-600 hover:bg-green-700"
                    }`}
                  >
                    {selectedPath.enrolled ? (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Continue Learning
                      </>
                    ) : (
                      <>
                        <BookOpen className="w-5 h-5 mr-2" />
                        Enroll in Path
                      </>
                    )}
                  </Button>
                  <Button variant="outline" size="lg">
                    <Trophy className="w-5 h-5 mr-2" />
                    View Certificate
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}