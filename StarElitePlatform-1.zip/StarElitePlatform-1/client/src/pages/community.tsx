import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  MessageSquare, 
  Heart,
  Share2,
  Send,
  Search,
  Filter,
  TrendingUp,
  GraduationCap,
  Calendar,
  MapPin,
  Award,
  BookOpen,
  Trophy
} from "lucide-react";

interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
    title: string;
    badge: string;
  };
  content: string;
  timestamp: Date;
  likes: number;
  comments: number;
  tags: string[];
  type: "discussion" | "achievement" | "question" | "resource";
}

interface Event {
  id: string;
  title: string;
  description: string;
  date: Date;
  type: "webinar" | "workshop" | "meetup" | "hackathon";
  attendees: number;
  maxAttendees: number;
  location: string;
  host: string;
}

interface StudyGroup {
  id: string;
  name: string;
  description: string;
  members: number;
  maxMembers: number;
  topic: string;
  level: "beginner" | "intermediate" | "advanced";
  nextMeeting: Date;
  tags: string[];
}

export default function Community() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("feed");
  const [newPost, setNewPost] = useState("");

  const posts: Post[] = [
    {
      id: "1",
      author: {
        name: "Sarah Chen",
        avatar: "/api/placeholder/40/40",
        title: "Data Scientist",
        badge: "AI Expert"
      },
      content: "Just completed the Advanced Machine Learning certification! The practical projects really helped solidify my understanding of neural networks. Highly recommend for anyone looking to level up their ML skills. #MachineLearning #Certification",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      likes: 24,
      comments: 8,
      tags: ["Machine Learning", "Certification"],
      type: "achievement"
    },
    {
      id: "2",
      author: {
        name: "Alex Rodriguez",
        avatar: "/api/placeholder/40/40",
        title: "Full-Stack Developer",
        badge: "Code Ninja"
      },
      content: "Quick question for the React developers out there: What's your preferred state management solution for large applications? I've been using Redux but considering Zustand for my next project. Would love to hear your experiences!",
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      likes: 15,
      comments: 12,
      tags: ["React", "State Management"],
      type: "question"
    },
    {
      id: "3",
      author: {
        name: "Emily Johnson",
        avatar: "/api/placeholder/40/40",
        title: "Product Manager",
        badge: "Strategy Master"
      },
      content: "Found this amazing resource for data visualization best practices. It covers everything from choosing the right chart type to color theory for accessibility. Link in comments! 📊 #DataViz #Resources",
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      likes: 31,
      comments: 5,
      tags: ["Data Visualization", "Resources"],
      type: "resource"
    }
  ];

  const events: Event[] = [
    {
      id: "1",
      title: "AI in Healthcare: Future Trends",
      description: "Join leading experts discussing how AI is transforming healthcare outcomes and patient care.",
      date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      type: "webinar",
      attendees: 247,
      maxAttendees: 500,
      location: "Virtual",
      host: "Dr. Maria Santos"
    },
    {
      id: "2",
      title: "Python for Data Science Workshop",
      description: "Hands-on workshop covering pandas, numpy, and visualization libraries.",
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      type: "workshop",
      attendees: 89,
      maxAttendees: 100,
      location: "Virtual Lab",
      host: "David Kim"
    },
    {
      id: "3",
      title: "Local Tech Meetup - Seattle",
      description: "Monthly gathering for tech professionals in the Seattle area.",
      date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
      type: "meetup",
      attendees: 34,
      maxAttendees: 50,
      location: "Seattle, WA",
      host: "Seattle Tech Community"
    }
  ];

  const studyGroups: StudyGroup[] = [
    {
      id: "1",
      name: "Machine Learning Study Circle",
      description: "Weekly discussions on ML algorithms, practical implementations, and paper reviews.",
      members: 28,
      maxMembers: 35,
      topic: "Machine Learning",
      level: "intermediate",
      nextMeeting: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      tags: ["Machine Learning", "Algorithms", "Papers"]
    },
    {
      id: "2",
      name: "React Beginners Bootcamp",
      description: "Learning React from scratch with hands-on projects and peer support.",
      members: 15,
      maxMembers: 20,
      topic: "React Development",
      level: "beginner",
      nextMeeting: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
      tags: ["React", "JavaScript", "Frontend"]
    },
    {
      id: "3",
      name: "Data Science Career Prep",
      description: "Preparing for data science interviews with mock sessions and portfolio reviews.",
      members: 22,
      maxMembers: 25,
      topic: "Career Development",
      level: "intermediate",
      nextMeeting: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000),
      tags: ["Career", "Interviews", "Portfolio"]
    }
  ];

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "webinar": return "bg-blue-100 text-blue-800 border-blue-200";
      case "workshop": return "bg-green-100 text-green-800 border-green-200";
      case "meetup": return "bg-purple-100 text-purple-800 border-purple-200";
      case "hackathon": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner": return "bg-green-100 text-green-800 border-green-200";
      case "intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "advanced": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case "achievement": return <Award className="w-4 h-4 text-yellow-600" />;
      case "question": return <MessageSquare className="w-4 h-4 text-blue-600" />;
      case "resource": return <BookOpen className="w-4 h-4 text-green-600" />;
      default: return <MessageSquare className="w-4 h-4 text-gray-600" />;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold text-blue-800">StarElite</span>
                <p className="text-xs text-gray-600 -mt-1">Learning Community</p>
              </div>
            </div>
            <Button 
              onClick={() => window.history.pushState({}, '', '/')}
              variant="outline" 
              size="sm"
              className="border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Learning Community
          </h1>
          <p className="text-lg text-gray-600">
            Connect, collaborate, and grow with fellow learners worldwide
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 bg-white border">
            <TabsTrigger value="feed">Community Feed</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
            <TabsTrigger value="groups">Study Groups</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          </TabsList>

          {/* Community Feed */}
          <TabsContent value="feed" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                {/* Create Post */}
                <Card className="border-2 border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-blue-800">Share with Community</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="What's on your mind? Share your learning journey, ask questions, or help others..."
                      value={newPost}
                      onChange={(e) => setNewPost(e.target.value)}
                      className="min-h-[100px]"
                    />
                    <div className="flex justify-between items-center">
                      <div className="flex gap-2">
                        <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                          #Question
                        </Badge>
                        <Badge variant="outline" className="cursor-pointer hover:bg-green-50">
                          #Achievement
                        </Badge>
                        <Badge variant="outline" className="cursor-pointer hover:bg-purple-50">
                          #Resource
                        </Badge>
                      </div>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <Send className="w-4 h-4 mr-2" />
                        Post
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Posts Feed */}
                <div className="space-y-4">
                  {posts.map((post) => (
                    <Card key={post.id} className="border-2 border-gray-100 hover:border-blue-200 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={post.author.avatar} alt={post.author.name} />
                            <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold text-gray-900">{post.author.name}</h4>
                              <Badge variant="outline" className="text-xs">
                                {post.author.badge}
                              </Badge>
                              <span className="text-sm text-gray-500">• {post.author.title}</span>
                              <span className="text-sm text-gray-400">• {formatTimeAgo(post.timestamp)}</span>
                            </div>
                            <div className="flex items-center gap-1 mb-3">
                              {getPostTypeIcon(post.type)}
                              <span className="text-sm text-gray-600 capitalize">{post.type}</span>
                            </div>
                            <p className="text-gray-800 mb-4">{post.content}</p>
                            <div className="flex flex-wrap gap-1 mb-4">
                              {post.tags.map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center gap-6 text-gray-500">
                              <button className="flex items-center gap-1 hover:text-red-500 transition-colors">
                                <Heart className="w-4 h-4" />
                                <span className="text-sm">{post.likes}</span>
                              </button>
                              <button className="flex items-center gap-1 hover:text-blue-500 transition-colors">
                                <MessageSquare className="w-4 h-4" />
                                <span className="text-sm">{post.comments}</span>
                              </button>
                              <button className="flex items-center gap-1 hover:text-green-500 transition-colors">
                                <Share2 className="w-4 h-4" />
                                <span className="text-sm">Share</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                <Card className="border-2 border-green-100">
                  <CardHeader>
                    <CardTitle className="text-green-800">Trending Topics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {["#MachineLearning", "#ReactJS", "#DataScience", "#Python", "#CareerAdvice"].map((topic, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">{topic}</span>
                        <div className="flex items-center">
                          <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
                          <span className="text-xs text-gray-500">{Math.floor(Math.random() * 100) + 50}</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-2 border-purple-100">
                  <CardHeader>
                    <CardTitle className="text-purple-800">Active Study Groups</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {studyGroups.slice(0, 3).map((group) => (
                      <div key={group.id} className="p-3 bg-purple-50 rounded-lg">
                        <h4 className="font-medium text-sm text-purple-900">{group.name}</h4>
                        <p className="text-xs text-purple-700 mt-1">{group.members} members</p>
                        <Badge className={`${getLevelColor(group.level)} text-xs mt-2`}>
                          {group.level}
                        </Badge>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Events */}
          <TabsContent value="events" className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input placeholder="Search events..." className="pl-10 w-64" />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
              <Button className="bg-green-600 hover:bg-green-700">
                Create Event
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <Card key={event.id} className="border-2 border-gray-100 hover:border-blue-200 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      <Badge className={getEventTypeColor(event.type)}>
                        {event.type.toUpperCase()}
                      </Badge>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">
                          {event.date.toLocaleDateString()}
                        </p>
                        <p className="text-xs text-gray-500">
                          {event.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{event.title}</CardTitle>
                    <CardDescription>{event.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center text-gray-600">
                        <MapPin className="w-4 h-4 mr-2" />
                        {event.location}
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Users className="w-4 h-4 mr-2" />
                        {event.attendees}/{event.maxAttendees} attendees
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Calendar className="w-4 h-4 mr-2" />
                        Hosted by {event.host}
                      </div>
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">
                      Register
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Study Groups */}
          <TabsContent value="groups" className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input placeholder="Search study groups..." className="pl-10 w-64" />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter by Level
                </Button>
              </div>
              <Button className="bg-purple-600 hover:bg-purple-700">
                Create Group
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {studyGroups.map((group) => (
                <Card key={group.id} className="border-2 border-gray-100 hover:border-purple-200 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      <Badge className={getLevelColor(group.level)}>
                        {group.level.toUpperCase()}
                      </Badge>
                      <span className="text-sm text-gray-500">
                        {group.members}/{group.maxMembers} members
                      </span>
                    </div>
                    <CardTitle className="text-lg">{group.name}</CardTitle>
                    <CardDescription>{group.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-1">
                      {group.tags.map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2" />
                        Next meeting: {group.nextMeeting.toLocaleDateString()}
                      </div>
                    </div>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700">
                      Join Group
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Leaderboard */}
          <TabsContent value="leaderboard" className="space-y-6">
            <Card className="border-2 border-amber-100">
              <CardHeader>
                <CardTitle className="text-amber-800">Community Champions</CardTitle>
                <CardDescription>Top contributors this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { rank: 1, name: "Alex Chen", contributions: 45, badge: "🏆" },
                    { rank: 2, name: "Sarah Johnson", contributions: 38, badge: "🥈" },
                    { rank: 3, name: "Mike Rodriguez", contributions: 31, badge: "🥉" },
                    { rank: 4, name: "Emily Davis", contributions: 28, badge: "⭐" },
                    { rank: 5, name: "David Kim", contributions: 24, badge: "⭐" }
                  ].map((entry) => (
                    <div key={entry.rank} className="flex items-center justify-between p-4 bg-amber-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="text-2xl">{entry.badge}</div>
                        <div>
                          <p className="font-semibold text-amber-900">#{entry.rank} {entry.name}</p>
                          <p className="text-sm text-amber-700">{entry.contributions} contributions</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        View Profile
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}