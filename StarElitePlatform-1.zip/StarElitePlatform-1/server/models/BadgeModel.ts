
import { db } from '../db';
import { achievements } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface Badge {
  id: string;
  name: string;
  description: string;
}

// Get all badges (using achievements)
export const getBadges = async () => {
  return await db.select().from(achievements);
};

// Add a new badge
export const addBadge = async (badge: Omit<Badge, 'id'>) => {
  const [newBadge] = await db
    .insert(achievements)
    .values({
      title: badge.name,
      description: badge.description,
      icon: 'trophy',
      type: 'milestone',
      criteria: badge.description
    })
    .returning();
  return newBadge;
};

// Remove a badge
export const removeBadge = async (id: string) => {
  await db.delete(achievements).where(eq(achievements.id, id));
};
