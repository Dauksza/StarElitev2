
import bcrypt from 'bcrypt';
import { db } from '../db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  subscription: 'Freemium' | 'Premium' | 'Pro' | 'Enterprise';
  isAdmin: boolean;
  progress: number;
  streak: number;
  courseProgress?: { [courseId: string]: number };
  stripeCustomerId?: string;
  subscriptionStatus?: 'active' | 'inactive' | 'trialing' | 'canceled';
  lessonsUsedToday?: number;
  lessonsLastUsedDate?: string;
  certsUsed?: number;
}

// Get all users
export const getUsers = async (): Promise<User[]> => {
  return await db.select().from(users);
};

// Add a new user
export const addUser = async (user: Omit<User, 'id' | 'passwordHash'> & { password: string }) => {
  const passwordHash = await bcrypt.hash(user.password, 10);
  const [newUser] = await db
    .insert(users)
    .values({
      email: user.email,
      passwordHash,
      displayName: user.email.split('@')[0],
      subscription: user.subscription || 'Freemium',
      isAdmin: user.isAdmin || false,
    })
    .returning();
  return newUser;
};

// Update user
export const updateUser = async (id: string, updates: Partial<Omit<User, 'id' | 'email' | 'passwordHash'>>) => {
  const [updatedUser] = await db
    .update(users)
    .set({
      ...updates,
      updatedAt: new Date()
    })
    .where(eq(users.id, id))
    .returning();
  return updatedUser;
};

// Reset user password
export const resetUserPassword = async (id: string, newPassword: string) => {
  const passwordHash = await bcrypt.hash(newPassword, 10);
  const [updatedUser] = await db
    .update(users)
    .set({
      passwordHash,
      updatedAt: new Date()
    })
    .where(eq(users.id, id))
    .returning();
  return updatedUser;
};

// Authenticate user
export const authenticateUser = async (email: string, password: string) => {
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  
  if (user && await bcrypt.compare(password, user.passwordHash)) {
    return user;
  }
  return null;
};
