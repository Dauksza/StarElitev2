
export interface ExamQuestion {
  id: string;
  lessonId: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
}

export interface Exam {
  id: string;
  courseId: string;
  questions: ExamQuestion[];
  version: number;
}

let exams: Exam[] = [];

// Get all exams
export const getExams = (): Exam[] => exams;

// Add a new exam
export const addExam = (exam: Exam) => {
  exams.push(exam);
};

// Get exam by course ID
export const getExamByCourseId = (courseId: string): Exam | undefined =>
  exams.find((e) => e.courseId === courseId);
