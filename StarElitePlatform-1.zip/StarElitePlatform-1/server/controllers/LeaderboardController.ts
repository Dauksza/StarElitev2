
import { Request, Response } from 'express';
import { db } from '../db';
import { users } from '@shared/schema';
import { desc } from 'drizzle-orm';

export const listLeaderboard = async (req: Request, res: Response) => {
  try {
    const leaderboard = await db
      .select({
        id: users.id,
        displayName: users.displayName,
        totalXp: users.totalXp,
        level: users.level,
        currentStreak: users.currentStreak
      })
      .from(users)
      .orderBy(desc(users.totalXp))
      .limit(50);
    
    res.json(leaderboard);
  } catch (error) {
    console.error('Error getting leaderboard:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const addLeaderboardEntry = async (req: Request, res: Response) => {
  try {
    const { userId, points } = req.body;
    
    // Update user's total XP
    await db
      .update(users)
      .set({ 
        totalXp: points,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
    
    res.status(201).json({ message: 'Leaderboard entry updated' });
  } catch (error) {
    console.error('Error updating leaderboard:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
