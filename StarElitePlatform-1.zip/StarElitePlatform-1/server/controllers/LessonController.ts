
import { Request, Response } from 'express';
import { db } from '../db';
import { modules } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const listLessons = async (req: Request, res: Response) => {
  try {
    const lessons = await db.select().from(modules);
    res.json(lessons);
  } catch (error) {
    console.error('Error listing lessons:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createLesson = async (req: Request, res: Response) => {
  try {
    const { courseId, title, description, content, estimatedDuration, order } = req.body;
    
    const [lesson] = await db
      .insert(modules)
      .values({
        learningPathId: courseId,
        title,
        description,
        content,
        estimatedDuration: estimatedDuration || '30 minutes',
        order: order || 1
      })
      .returning();
    
    res.status(201).json({ message: 'Lesson created', lesson });
  } catch (error) {
    console.error('Error creating lesson:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const listLessonsByCourse = async (req: Request, res: Response) => {
  try {
    const { courseId } = req.params;
    
    const lessons = await db
      .select()
      .from(modules)
      .where(eq(modules.learningPathId, courseId));
    
    res.json(lessons);
  } catch (error) {
    console.error('Error listing lessons by course:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
