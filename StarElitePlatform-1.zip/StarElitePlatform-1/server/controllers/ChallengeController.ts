
import { Request, Response } from 'express';
import { db } from '../db';
import { challenges } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const listChallenges = async (req: Request, res: Response) => {
  try {
    const allChallenges = await db.select().from(challenges);
    res.json(allChallenges);
  } catch (error) {
    console.error('Error listing challenges:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createChallenge = async (req: Request, res: Response) => {
  try {
    const { title, description, type, difficulty, estimatedTime, points } = req.body;
    
    const [challenge] = await db
      .insert(challenges)
      .values({
        title,
        description,
        type: type || 'individual',
        difficulty: difficulty || 'intermediate',
        estimatedTime: estimatedTime || '2 hours',
        points: points || 100
      })
      .returning();
    
    res.status(201).json({ message: 'Challenge created', challenge });
  } catch (error) {
    console.error('Error creating challenge:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteChallenge = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    await db.delete(challenges).where(eq(challenges.id, id));
    
    res.json({ message: `Challenge ${id} removed` });
  } catch (error) {
    console.error('Error deleting challenge:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
