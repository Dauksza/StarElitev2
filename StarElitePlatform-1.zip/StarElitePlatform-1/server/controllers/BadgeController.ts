
import { Request, Response } from 'express';
import { db } from '../db';
import { achievements } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const listBadges = async (req: Request, res: Response) => {
  try {
    const badges = await db.select().from(achievements);
    res.json(badges);
  } catch (error) {
    console.error('Error listing badges:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createBadge = async (req: Request, res: Response) => {
  try {
    const { name, description, icon, type, criteria } = req.body;
    
    const [badge] = await db
      .insert(achievements)
      .values({
        title: name,
        description,
        icon: icon || 'trophy',
        type: type || 'milestone',
        criteria: criteria || description
      })
      .returning();
    
    res.status(201).json({ message: 'Badge created', badge });
  } catch (error) {
    console.error('Error creating badge:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteBadge = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    await db.delete(achievements).where(eq(achievements.id, id));
    
    res.json({ message: `Badge ${id} removed` });
  } catch (error) {
    console.error('Error deleting badge:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
