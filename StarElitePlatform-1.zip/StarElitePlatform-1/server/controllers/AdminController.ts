
import { Request, Response } from 'express';
import { db } from '../db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';

export const listUsers = async (req: Request, res: Response) => {
  try {
    const allUsers = await db.select().from(users);
    res.json(allUsers);
  } catch (error) {
    console.error('Error listing users:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateUserSubscription = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { subscription } = req.body;
    
    const [updated] = await db
      .update(users)
      .set({ subscription, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    
    res.json(updated);
  } catch (error) {
    console.error('Error updating user subscription:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;
    
    const passwordHash = await bcrypt.hash(newPassword, 10);
    
    const [updated] = await db
      .update(users)
      .set({ passwordHash, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    
    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateUserProgress = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { currentStreak, totalXp, level } = req.body;
    
    const [updated] = await db
      .update(users)
      .set({ currentStreak, totalXp, level, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    
    res.json(updated);
  } catch (error) {
    console.error('Error updating user progress:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateStripeInfo = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { stripeCustomerId, subscriptionStatus } = req.body;
    
    const [updated] = await db
      .update(users)
      .set({ 
        stripeCustomerId, 
        subscriptionStatus,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    
    res.json(updated);
  } catch (error) {
    console.error('Error updating Stripe info:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateUserLimits = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { lessonsUsedToday, lessonsLastUsedDate, certsUsed } = req.body;
    
    const updates: any = { updatedAt: new Date() };
    if (lessonsUsedToday !== undefined) updates.lessonsUsedToday = lessonsUsedToday;
    if (lessonsLastUsedDate !== undefined) updates.lessonsLastUsedDate = lessonsLastUsedDate;
    if (certsUsed !== undefined) updates.certsUsed = certsUsed;
    
    const [updated] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    
    res.json(updated);
  } catch (error) {
    console.error('Error updating user limits:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
