import { storage } from "./storage";

export async function getAuthUser(req: any) {
  // For development, return a demo user
  const demoUserId = "demo-user-123";
  let demoUser = await storage.getUser(demoUserId);
  
  if (!demoUser) {
    try {
      demoUser = await storage.upsertUser({
        id: demoUserId,
        email: "demo@example.com",
        firstName: "Demo",
        lastName: "User",
        profileImageUrl: null,
        onboardingCompleted: true,
        currentLevel: 2,
        experiencePoints: 1250,
        currentStreak: 7,
        longestStreak: 15,
        lastActivityDate: new Date(),
        skillsMastered: 5,
        learningHours: "45.5",
        globalRank: 1234,
        totalXp: 1250,
        level: 2,
        displayName: "Demo User",
        avatar: null,
        bio: "Demo user for development",
        skills: ["JavaScript", "React", "Node.js", "Python"]
      });
    } catch (error) {
      // User might already exist, try to get it again
      demoUser = await storage.getUser(demoUserId);
    }
  }
  
  return demoUser;
}