import {
  users,
  learningPaths,
  modules,
  userLearningPathProgress,
  userModuleProgress,
  achievements,
  userAchievements,
  challenges,
  userChallenges,
  skillAssessments,
  discussions,
  discussionReplies,
  type User,
  type UpsertUser,
  type LearningPath,
  type Module,
  type UserLearningPathProgress,
  type UserModuleProgress,
  type Achievement,
  type UserAchievement,
  type Challenge,
  type UserChallenge,
  type SkillAssessment,
  type Discussion,
  type DiscussionReply,
  type InsertLearningPath,
  type InsertModule,
  type InsertDiscussion,
  type InsertChallenge,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, lte, isNull, or } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStats(userId: string, updates: Partial<User>): Promise<User | undefined>;
}

class Storage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    try {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, id))
        .limit(1);

      return user;
    } catch (error) {
      console.error("Error getting user:", error);
      return undefined;
    }
  }

  async upsertUser(user: UpsertUser): Promise<User> {
    try {
      const [upsertedUser] = await db
        .insert(users)
        .values({
          ...user,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: users.id,
          set: {
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            profileImageUrl: user.profileImageUrl,
            updatedAt: new Date(),
          },
        })
        .returning();

      return upsertedUser;
    } catch (error) {
      console.error("Error upserting user:", error);
      throw error;
    }
  }

  async updateUserStats(userId: string, updates: Partial<User>): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          ...updates,
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .returning();

      return updatedUser;
    } catch (error) {
      console.error("Error updating user stats:", error);
      return undefined;
    }
  }

  // Learning Paths
  async createLearningPath(path: InsertLearningPath): Promise<LearningPath> {
    const [newPath] = await db
      .insert(learningPaths)
      .values(path)
      .returning();
    return newPath;
  }

  async getLearningPaths(): Promise<LearningPath[]> {
    return await db.select().from(learningPaths);
  }

  async getLearningPath(id: string): Promise<LearningPath | undefined> {
    const [path] = await db
      .select()
      .from(learningPaths)
      .where(eq(learningPaths.id, id))
      .limit(1);
    return path;
  }

  // Modules
  async createModule(module: InsertModule): Promise<Module> {
    const [newModule] = await db
      .insert(modules)
      .values(module)
      .returning();
    return newModule;
  }

  async getModulesByPath(pathId: string): Promise<Module[]> {
    return await db
      .select()
      .from(modules)
      .where(eq(modules.learningPathId, pathId));
  }

  // User Progress
  async updateUserProgress(userId: string, moduleId: string, progress: number): Promise<void> {
    await db
      .insert(userModuleProgress)
      .values({
        userId,
        moduleId,
        progress,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [userModuleProgress.userId, userModuleProgress.moduleId],
        set: {
          progress,
          updatedAt: new Date(),
        },
      });
  }

  async getUserProgress(userId: string): Promise<UserModuleProgress[]> {
    return await db
      .select()
      .from(userModuleProgress)
      .where(eq(userModuleProgress.userId, userId));
  }

  // Skill Assessments
  async saveSkillAssessment(assessment: Omit<SkillAssessment, 'id' | 'createdAt'>): Promise<SkillAssessment> {
    const [newAssessment] = await db
      .insert(skillAssessments)
      .values(assessment)
      .returning();
    return newAssessment;
  }

  async getUserAssessments(userId: string): Promise<SkillAssessment[]> {
    return await db
      .select()
      .from(skillAssessments)
      .where(eq(skillAssessments.userId, userId))
      .orderBy(desc(skillAssessments.createdAt));
  }

  // Challenges
  async getChallenges(): Promise<Challenge[]> {
    return await db.select().from(challenges);
  }

  async joinChallenge(userId: string, challengeId: string): Promise<void> {
    await db
      .insert(userChallenges)
      .values({
        userId,
        challengeId,
        joinedAt: new Date(),
      })
      .onConflictDoNothing();
  }

  // Discussions
  async createDiscussion(discussion: InsertDiscussion): Promise<Discussion> {
    const [newDiscussion] = await db
      .insert(discussions)
      .values(discussion)
      .returning();
    return newDiscussion;
  }

  async getDiscussions(category?: string): Promise<Discussion[]> {
    let query = db.select().from(discussions);

    if (category) {
      query = query.where(eq(discussions.category, category));
    }

    return await query.orderBy(desc(discussions.createdAt));
  }
}

export const storage = new Storage();