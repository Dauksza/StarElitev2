
// Mistral AI Service for StarElite
export class MistralService {
  private apiKey: string;
  private baseUrl: string = 'https://api.mistral.ai';

  constructor() {
    this.apiKey = process.env.MISTRAL_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Mistral API key not found. AI features will use mock data.');
    }
  }

  async generateLearningPath(userProfile: any): Promise<any> {
    if (!this.apiKey) {
      return this.mockLearningPath(userProfile);
    }

    try {
      const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'mistral-medium',
          messages: [
            {
              role: 'system',
              content: `You are StarForce AI, an expert learning path generator. Create personalized learning paths based on user profiles. Return structured JSON with modules, assessments, and timeline.`
            },
            {
              role: 'user',
              content: `Create a learning path for: ${JSON.stringify(userProfile)}`
            }
          ],
          temperature: 0.7,
          max_tokens: 2000
        })
      });

      const data = await response.json();
      return JSON.parse(data.choices[0].message.content);
    } catch (error) {
      console.error('Mistral API error:', error);
      return this.mockLearningPath(userProfile);
    }
  }

  async generateSkillGapAnalysis(currentSkills: string[], targetRole: string): Promise<any> {
    if (!this.apiKey) {
      return this.mockSkillGapAnalysis();
    }

    try {
      const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'mistral-medium',
          messages: [
            {
              role: 'system',
              content: `You are StarForce AI, an expert skill analyst. Analyze skill gaps between current skills and target role requirements. Return structured JSON with gaps, priorities, and recommendations.`
            },
            {
              role: 'user',
              content: `Current skills: ${currentSkills.join(', ')}. Target role: ${targetRole}. Analyze gaps.`
            }
          ],
          temperature: 0.5,
          max_tokens: 1500
        })
      });

      const data = await response.json();
      return JSON.parse(data.choices[0].message.content);
    } catch (error) {
      console.error('Mistral API error:', error);
      return this.mockSkillGapAnalysis();
    }
  }

  async generateQuiz(topic: string, difficulty: string): Promise<any> {
    if (!this.apiKey) {
      return this.mockQuiz(topic);
    }

    try {
      const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'mistral-medium',
          messages: [
            {
              role: 'system',
              content: `You are StarForce AI, an expert quiz generator. Create engaging, practical quizzes that test real-world application. Return structured JSON with questions, options, and explanations.`
            },
            {
              role: 'user',
              content: `Create a ${difficulty} level quiz on ${topic} with 5 questions.`
            }
          ],
          temperature: 0.6,
          max_tokens: 2000
        })
      });

      const data = await response.json();
      return JSON.parse(data.choices[0].message.content);
    } catch (error) {
      console.error('Mistral API error:', error);
      return this.mockQuiz(topic);
    }
  }

  async generateFeedback(performance: any): Promise<string> {
    if (!this.apiKey) {
      return this.mockFeedback(performance);
    }

    try {
      const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'mistral-medium',
          messages: [
            {
              role: 'system',
              content: `You are StarForce AI, providing personalized learning feedback. Be encouraging but precise, offering specific actionable advice.`
            },
            {
              role: 'user',
              content: `Provide feedback for this performance data: ${JSON.stringify(performance)}`
            }
          ],
          temperature: 0.8,
          max_tokens: 800
        })
      });

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Mistral API error:', error);
      return this.mockFeedback(performance);
    }
  }

  // Mock implementations for development
  private mockLearningPath(userProfile: any) {
    return {
      title: `Personalized ${userProfile.targetRole || 'Professional'} Learning Path`,
      description: `AI-curated journey tailored to your ${userProfile.currentLevel || 'current'} level`,
      estimatedDuration: '8-12 weeks',
      modules: [
        {
          title: 'Foundation Skills',
          duration: '2 weeks',
          topics: ['Core concepts', 'Best practices', 'Industry standards']
        },
        {
          title: 'Intermediate Applications',
          duration: '3 weeks',
          topics: ['Advanced techniques', 'Real-world projects', 'Problem solving']
        },
        {
          title: 'Expert Mastery',
          duration: '3 weeks',
          topics: ['Complex scenarios', 'Leadership skills', 'Innovation']
        }
      ],
      priority: 'High'
    };
  }

  private mockSkillGapAnalysis() {
    return {
      skillGaps: [
        { skill: 'Advanced JavaScript', currentLevel: 6, targetLevel: 9, priority: 'High' },
        { skill: 'React Performance', currentLevel: 4, targetLevel: 8, priority: 'High' },
        { skill: 'System Design', currentLevel: 3, targetLevel: 7, priority: 'Medium' }
      ],
      recommendations: [
        {
          title: 'JavaScript Mastery',
          description: 'Focus on async programming and advanced concepts',
          estimatedTime: '4 weeks'
        }
      ],
      overallReadiness: 72
    };
  }

  private mockQuiz(topic: string) {
    return {
      title: `${topic} Assessment`,
      questions: [
        {
          id: 1,
          question: `What is a key principle in ${topic}?`,
          options: ['Option A', 'Option B', 'Option C', 'Option D'],
          correct: 1,
          explanation: 'This is the correct answer because...'
        }
      ]
    };
  }

  private mockFeedback(performance: any) {
    const score = performance.score || 75;
    if (score >= 90) {
      return '🌟 Exceptional performance! You\'re mastering these concepts. Consider advancing to more challenging material.';
    } else if (score >= 80) {
      return '👏 Great work! You\'re on the right track. Focus on the areas where you missed points for even better results.';
    } else if (score >= 70) {
      return '📈 Good effort! You understand the basics well. Review the challenging topics and practice more examples.';
    } else {
      return '💪 Keep pushing forward! This is a learning opportunity. Review the fundamentals and don\'t hesitate to ask for help.';
    }
  }
}

export const mistralService = new MistralService();
